# Suddenly a President

Game strategi pixel-art: kamu mendadak menjadi presiden dan harus memimpin Nusantara
selama **10 hari**. Bagikan anggaran, kelola hasil bumi, hadapi bencana dan tawaran suap,
lalu lihat bagaimana sejarah mencatat kepemimpinanmu.

## Cara menjalankan

Butuh **Python 3.8+**.

```bash
pip install -r requirements.txt
python main.py
```

## Kontrol

| Input | Fungsi |
|---|---|
| Mouse | klik tombol, pulau, dan petak minigame |
| `SPASI` / `ENTER` | lanjut (intro, transisi hari, cutscene) |
| `ESC` | jeda / kembali |
| `F11` | layar penuh |
| Panah / `WASD` | minigame Snake |
| Klik kiri / klik kanan atau `F` | minigame Mines: gali / bendera |
| `1`-`4` atau `A`-`D` | minigame Kuis |

## Cara bermain singkat

- Tiap hari, **hafalkan** angka kemakmuran pulau sebelum kabut turun.
- **Bagikan dana** ke pulau yang paling tertinggal. Pulau miskin lebih terbantu.
- **Produksi** hasil bumi lewat minigame tiap pulau, lalu jual lewat **Jawa**.
- Main **Negosiasi (kuis)** untuk buff harga jual selama satu minggu.
- Di hari 3, 6, dan 9 ada **cutscene** yang menampilkan kondisi nyata permainanmu.
- Waspadai **eksploitasi** pulau yang sama berhari-hari dan **tawaran suap**.
- Menang bila minimal 3 pulau makmur, tidak ada yang berpisah, dan rakyat tidak terlalu marah.

## Struktur folder

```
main.py                  game (satu file)
requirements.txt
asset/
  audio/bgm.mp3          musik latar, diulang di seluruh game
  image/                 opsional: logo.png (ikon jendela)
piala.json               dibuat otomatis saat bermain (tidak ikut repo)
```

Tanpa file aset pun game tetap berjalan: gambar dan efek suara dibuat dari kode, dan
tanpa `bgm.mp3` game memakai musik chiptune bawaan.

## Kustomisasi

- **Musik:** timpa `asset/audio/bgm.mp3` (juga bisa `.ogg` / `.wav`).
- **Cutscene:** dibuat otomatis dari permainanmu (hari 3: pulau paling tertinggal, hari 6: suasana
  rakyat, hari 9: jejak uang/ekspor) dan diputar ulang di credit roll. Hari tampilnya diatur lewat
  `CUTSCENE_DAYS` pada `main.py`.

## Kredit

| Peran | Nama |
|---|---|
| Director, Scenario | Jesslyn Fiorencia |
| Character Design | Jeverline Emerald, Angela Claresta |
| Background Art | Cherise Angelina |
| Programming, Sound Director | Meyliana Lie |
| Special Thanks | Our Teacher, Maria Karla Christie, S.Kom. |

**Musik:** "Gameboy" oleh Walen, dari [freetouse.com](https://freetouse.com). Musik ini memiliki
lisensi sendiri dari penciptanya (bukan MIT); ikuti ketentuan pemakaian di situs tersebut.

## Lisensi

Kode dirilis dengan [lisensi MIT](LICENSE).
