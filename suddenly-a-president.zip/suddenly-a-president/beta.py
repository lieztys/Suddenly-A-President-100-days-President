#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SUDDENLY A PRESIDENT   (proyek "beta" - versi gabungan, 1 file)
Tampilan: RPG-strategy pixel UI (v1.0.16)
================================================================
Intro sinematik + game inti dalam satu file Python.

Aset : TIDAK ADA file eksternal yang wajib. Semua gambar, font pixel dan suara
       dibuat langsung dari kode. (Opsional: logo ikon di asset/image/logo.png)

Musik: backsound sementara dibuat otomatis (chiptune). Untuk memakai lagu sendiri,
       taruh file di folder  asset/audio/  (format .ogg / .mp3 / .wav):
         menu.ogg    -> intro, menu, pengaturan
         game.ogg    -> permainan & minigame
         ending.ogg  -> ending / credit
         bgm.ogg     -> cadangan untuk SEMUA lagu yang file khususnya tidak ada
       File akan otomatis menggantikan backsound bawaan, tanpa ubah kode.

Kontrol umum
  Mouse            : klik tombol / pulau / petak minigame
  SPASI / ENTER    : lanjut (intro, transisi hari, lewati fase pengamatan)
  ESC              : jeda / kembali          F11 : layar penuh
  Minigame Snake   : panah atau WASD
  Minigame Mines   : klik kiri = gali, klik kanan / tombol F = bendera
  Minigame Quiz    : klik jawaban atau tekan 1-4 / A-D

Butuh: Python 3.8+ dan pygame 2.x   ->   pip install pygame
"""
from __future__ import annotations

import json
import math
import os
import random
import sys
import threading
import time
from array import array

import pygame

# ======================================================================
# 1. KONSTANTA & PALET (diambil dari gaya intro)
# ======================================================================
TITLE = "Suddenly a President"
CW, CH = 640, 360                      # resolusi logis pixel-art (16:9)
BASE = os.path.dirname(os.path.abspath(__file__))

# ======================================================================
# PENGATURAN EFEK KETIK  (ubah angka/nama di bawah ini sesuka Anda)
# ======================================================================
# Ganti suara ketik: taruh file suara pendek di folder  asset/audio/
# lalu isi nama filenya di bawah (boleh tanpa ekstensi: .wav .ogg .mp3).
# Jika file tidak ditemukan, otomatis dipakai bunyi "tik" sintetis bawaan.
TYPING_SOUND_FILE = "ketik"        # contoh: "ketik" -> asset/audio/ketik.wav
TYPING_VOLUME = 0.6                # volume suara ketik, 0.0 - 1.0
TYPING_SPEED_INTRO = 0.045         # detik per huruf di cutscene (kecil = cepat)
TYPING_SPEED_OTHER = 0.010         # detik per huruf di bagian game lain
TYPING_SOUND_EVERY = 2             # bunyi tiap N huruf (1 = setiap huruf)
TYPING_SOUND_STATES = ("intro",)   # di mana suara ketik aktif; tambah "ending" dll jika mau
TYPING_SKIP_FIRST = True           # klik/SPASI saat mengetik = tampilkan teks penuh dulu
# Bunyi cadangan bila tidak ada file: frekuensi dasar, variasi acak, durasi, gelombang, volume
TYPING_FALLBACK = (1200, 300, 0.02, "square", 0.015)

PAGE_BG = (9, 9, 11)
NIGHT = (9, 10, 15)
GOLD = (255, 215, 0)
GOLD2 = (212, 175, 55)
GOLD_D = (138, 109, 59)
AMBER = (243, 156, 18)
AMBER_200 = (253, 230, 138)
BRONZE = (138, 109, 59)
CREAMT = (224, 208, 176)
PARCH = (244, 232, 193)
PARCH2 = (229, 211, 158)
INK = (44, 34, 30)
INK2 = (74, 59, 50)
WINE = (59, 17, 25)
SHADOW = (59, 0, 0)
DKPANEL = (26, 21, 0)
BTNBG = (44, 36, 22)
RED = (179, 36, 0)
RED2 = (192, 57, 43)
GREEN = (46, 160, 90)
YELLOW = (235, 195, 45)
WHITE = (236, 240, 241)
HUDBG = (14, 12, 8)

# --- Palet & ikon jendela bergaya RPG (dipakai semua panel) ---
WIN_TOP = (30, 42, 92)
WIN_BOT = (12, 16, 46)
WIN_HI = (104, 128, 214)
WIN_EDGE = (6, 6, 18)
TXT = (252, 246, 226)
TXT_DIM = (156, 166, 206)
TXT_GOLD = (255, 214, 72)
OK_C = (104, 228, 124)
WARN_C = (255, 202, 70)
BAD_C = (255, 100, 88)

ICON_PAL = {
    'k': (24, 16, 28),
    'w': (255, 255, 255),
    'y': (255, 216, 72),
    'Y': (200, 140, 32),
    'o': (240, 140, 40),
    'r': (226, 64, 56),
    'R': (140, 28, 40),
    'p': (255, 160, 170),
    'g': (96, 204, 96),
    'G': (40, 124, 60),
    'b': (80, 150, 230),
    'B': (36, 70, 150),
    'c': (170, 226, 255),
    'n': (170, 110, 60),
    'N': (106, 64, 36),
    't': (222, 178, 112),
    's': (196, 202, 216),
    'S': (112, 118, 142),
    'e': (240, 234, 216),
    'd': (60, 66, 100),
}

ICON_ART = {
    'coin': [
        '..kkkk..',
        '.kyyyyk.',
        'kyywwyYk',
        'kywyyyYk',
        'kywyyyYk',
        'kyyyyYYk',
        '.kYYYYk.',
        '..kkkk..',
    ],
    'heart': [
        '.kk..kk.',
        'krpkkrrk',
        'krprrrRk',
        'krrrrrRk',
        '.krrrRk.',
        '..krRk..',
        '...kk...',
        '........',
    ],
    'calendar': [
        '.k....k.',
        'kkkkkkkk',
        'krrrrrrk',
        'keeeeeek',
        'kebebebk',
        'keeeeeek',
        'kebebebk',
        'kkkkkkkk',
    ],
    'crate': [
        'kkkkkkkk',
        'kttttttk',
        'kNNttNNk',
        'knnnnnnk',
        'kNNttNNk',
        'kttttttk',
        'knnnnnnk',
        'kkkkkkkk',
    ],
    'cloud': [
        '........',
        '...kkk..',
        '..keeekk',
        '.keeeeek',
        'keeeeeek',
        'kesssssk',
        '.kkkkkk.',
        '........',
    ],
    'chart': [
        '........',
        '.....kk.',
        '.....gk.',
        '...kkgk.',
        '...gkgk.',
        '.kkgkgk.',
        '.kgkgkgk',
        'kkkkkkkk',
    ],
    'wheat': [
        '....yy..',
        '...yyY..',
        '..yyY.y.',
        '.yyY.yY.',
        '..Y.yY..',
        '...yY...',
        '...gk...',
        '...g....',
    ],
    'fish': [
        '........',
        '...kk..k',
        '.kkbbkkb',
        'kbwkbbbk',
        'kbbbbbbk',
        '.kkbbkkb',
        '...kk..k',
        '........',
    ],
    'log': [
        '..kkkkk.',
        '.ktttnnk',
        'kttNNtnk',
        'ktNttNnk',
        'kttNNtnk',
        '.ktttnnk',
        '..kkkkk.',
        '........',
    ],
    'ore': [
        '........',
        '..kkkk..',
        '.kSsssk.',
        'kSsweSSk',
        'kSSsSSSk',
        'kSSSSsSk',
        '.kkkkkk.',
        '........',
    ],
    'ship': [
        '...k....',
        '..kwk...',
        '..kwwk..',
        '.kwwwk..',
        '.kwwwwk.',
        'kkkkkkkk',
        '.kNNNNk.',
        '..kkkk..',
    ],
    'check': [
        '........',
        '.......g',
        '......gg',
        'g....gg.',
        'gg..gg..',
        '.gggg...',
        '..gg....',
        '........',
    ],
    'box': [
        'kkkkkkkk',
        'kddddddk',
        'kddddddk',
        'kddddddk',
        'kddddddk',
        'kddddddk',
        'kddddddk',
        'kkkkkkkk',
    ],
    'cross': [
        '........',
        '.rr..rr.',
        '..rrrr..',
        '...rr...',
        '..rrrr..',
        '.rr..rr.',
        '........',
        '........',
    ],
    'hourglass': [
        '.kkkkkk.',
        '.keeeek.',
        '..kyyk..',
        '...kk...',
        '...kk...',
        '..kyyk..',
        '.kyyyyk.',
        '.kkkkkk.',
    ],
    'star': [
        '...kk...',
        '...yk...',
        'kkkyykkk',
        '.kyyyyk.',
        '..kyyk..',
        '..kyyk..',
        '.kyk.yk.',
        '.k....k.',
    ],
    'cursor': [
        'kk......',
        'kyk.....',
        'kyyk....',
        'kyyyk...',
        'kyyyyk..',
        'kyyyk...',
        'kyyk....',
        'kyk.....',
        'kk......',
    ],
    'down': [
        'kkkkkkk',
        'kyyyyyk',
        '.kyyyk.',
        '..kyk..',
        '...k...',
    ],
    'warn': [
        '...kk...',
        '..kyyk..',
        '..kyyk..',
        '.kyykyk.',
        '.kyykyk.',
        'kyyyyyyk',
        'kyyykyyk',
        'kkkkkkkk',
    ],
    'adviser': [
        '...kkkkkk...',
        '..kkkkkkkk..',
        '..kkkkkkkk..',
        '.kttttttttk.',
        '.ktkttttktk.',
        '.kttttttttk.',
        '.kttttkkttk.',
        '..kttttttk..',
        '..kkeeeekk..',
        '.kBBeerreBBk',
        '.kBBBerBBBBk',
        '.kBBBBBBBBk.',
    ],
}



def rgba(r, g, b, a):
    """Seperti CSS rgba(r,g,b,a) dengan a 0..1."""
    return (r, g, b, round(a * 255))


# ======================================================================
# 2. FONT PIXEL BAWAAN (tanpa file .ttf) - 5x7, proporsional, huruf kecil
# ======================================================================
GLYPH_SRC = {
    "A": ".###./#...#/#...#/#####/#...#/#...#/#...#",
    "B": "####./#...#/#...#/####./#...#/#...#/####.",
    "C": ".###./#...#/#..../#..../#..../#...#/.###.",
    "D": "####./#...#/#...#/#...#/#...#/#...#/####.",
    "E": "#####/#..../#..../####./#..../#..../#####",
    "F": "#####/#..../#..../####./#..../#..../#....",
    "G": ".###./#...#/#..../#.###/#...#/#...#/.###.",
    "H": "#...#/#...#/#...#/#####/#...#/#...#/#...#",
    "I": "###/.#./.#./.#./.#./.#./###",
    "J": "..###/....#/....#/....#/....#/#...#/.###.",
    "K": "#...#/#..#./#.#../##.../#.#../#..#./#...#",
    "L": "#..../#..../#..../#..../#..../#..../#####",
    "M": "#...#/##.##/#.#.#/#.#.#/#...#/#...#/#...#",
    "N": "#...#/##..#/#.#.#/#..##/#...#/#...#/#...#",
    "O": ".###./#...#/#...#/#...#/#...#/#...#/.###.",
    "P": "####./#...#/#...#/####./#..../#..../#....",
    "Q": ".###./#...#/#...#/#...#/#.#.#/#..#./.##.#",
    "R": "####./#...#/#...#/####./#.#../#..#./#...#",
    "S": ".####/#..../#..../.###./....#/....#/####.",
    "T": "#####/..#../..#../..#../..#../..#../..#..",
    "U": "#...#/#...#/#...#/#...#/#...#/#...#/.###.",
    "V": "#...#/#...#/#...#/#...#/#...#/.#.#./..#..",
    "W": "#...#/#...#/#...#/#.#.#/#.#.#/##.##/#...#",
    "X": "#...#/#...#/.#.#./..#../.#.#./#...#/#...#",
    "Y": "#...#/#...#/.#.#./..#../..#../..#../..#..",
    "Z": "#####/....#/...#./..#../.#.../#..../#####",
    "0": ".###./#...#/#..##/#.#.#/##..#/#...#/.###.",
    "1": "..#../.##../..#../..#../..#../..#../.###.",
    "2": ".###./#...#/....#/...#./..#../.#.../#####",
    "3": "####./....#/....#/.###./....#/....#/####.",
    "4": "...#./..##./.#.#./#..#./#####/...#./...#.",
    "5": "#####/#..../####./....#/....#/#...#/.###.",
    "6": ".###./#..../#..../####./#...#/#...#/.###.",
    "7": "#####/....#/...#./..#../.#.../.#.../.#...",
    "8": ".###./#...#/#...#/.###./#...#/#...#/.###.",
    "9": ".###./#...#/#...#/.####/....#/....#/.###.",
    "a": "//.###./....#/.####/#...#/.####",
    "b": "#..../#..../####./#...#/#...#/#...#/####.",
    "c": "//.###./#...#/#..../#...#/.###.",
    "d": "....#/....#/.####/#...#/#...#/#...#/.####",
    "e": "//.###./#...#/#####/#..../.###.",
    "f": "..##/.#../###./.#../.#../.#../.#..",
    "g": "//.####/#...#/#...#/#...#/.####/....#/.###.",
    "h": "#..../#..../####./#...#/#...#/#...#/#...#",
    "i": ".#./.../##./.#./.#./.#./###",
    "j": "...#/..../..##/...#/...#/...#/...#/#..#/.##.",
    "k": "#..../#..../#..#./#.#../##.../#.#../#..#.",
    "l": "##./.#./.#./.#./.#./.#./###",
    "m": "//##.#./#.#.#/#.#.#/#...#/#...#",
    "n": "//####./#...#/#...#/#...#/#...#",
    "o": "//.###./#...#/#...#/#...#/.###.",
    "p": "//####./#...#/#...#/#...#/####./#..../#....",
    "q": "//.####/#...#/#...#/#...#/.####/....#/....#",
    "r": "//#.##./##..#/#..../#..../#....",
    "s": "//.####/#..../.###./....#/####.",
    "t": ".#../.#../###./.#../.#../.#../..##",
    "u": "//#...#/#...#/#...#/#..##/.##.#",
    "v": "//#...#/#...#/#...#/.#.#./..#..",
    "w": "//#...#/#...#/#.#.#/#.#.#/.#.#.",
    "x": "//#...#/.#.#./..#../.#.#./#...#",
    "y": "//#...#/#...#/#...#/.####/....#/....#/.###.",
    "z": "//#####/...#./..#../.#.../#####",
    " ": "...",
    ".": "//////#",
    ",": "/////.#/.#/#.",
    "!": "#/#/#/#/#//#",
    "?": ".###./#...#/....#/...#./..#../...../..#..",
    ":": "///#//#",
    ";": "///#//#/#",
    "-": "///###",
    "_": "///////#####",
    "+": "//..#../..#../#####/..#../..#..",
    "=": "///#####//#####",
    "/": "....#/....#/...#./..#../.#.../#..../#....",
    "\\": "#..../#..../.#.../..#../...#./....#/....#",
    "%": "##..#/##..#/...#./..#../.#.../#..##/#..##",
    "(": "..#/.#./#../#../#../.#./..#",
    ")": "#../.#./..#/..#/..#/.#./#..",
    "[": "###/#../#../#../#../#../###",
    "]": "###/..#/..#/..#/..#/..#/###",
    "<": "...#./..#../.#.../#..../.#.../..#../...#.",
    ">": ".#.../..#../...#./....#/...#./..#../.#...",
    "'": "#/#",
    '"': "#.#/#.#",
    "*": "//#.#/.#./###/.#./#.#",
    "#": ".#.#./.#.#./#####/.#.#./#####/.#.#./.#.#.",
    "&": ".##../#..#./#.#../.#.../#.#.#/#..#./.##.#",
    "@": ".###./#...#/#.###/#.#.#/#.##./#..../.####",
    "|": "#/#/#/#/#/#/#/#/#",
    "~": "///.##.#/#.##.",
    "^": "..#../.#.#./#...#",
    "$": "..#../.####/#.#../.###./..#.#/####./..#..",
    "\u2605": "..#../.###./#####/.###./.#.#./#...#",
    "\u2713": "//....#/...#./#.#../.#...",
    "\u2717": "//#...#/.#.#./..#../.#.#./#...#",
}


class PixelFont:
    """Font bitmap proporsional. Semua teks di game dirender lewat kelas ini."""

    def __init__(self):
        self.glyphs = {}
        for ch, spec in GLYPH_SRC.items():
            rows = spec.split("/")
            w = max(1, max(len(r) for r in rows))
            rows = [r.ljust(w, ".") for r in rows]
            rows += ["." * w] * (9 - len(rows))
            self.glyphs[ch] = (w, rows[:9])
        self._gc = {}
        self._sc = {}

    def _g(self, ch):
        return self.glyphs.get(ch) or self.glyphs["?"]

    def width(self, s, scale=1):
        if not s:
            return 0
        return (sum(self._g(ch)[0] + 1 for ch in s) - 1) * scale

    def _glyph(self, ch, scale, color):
        key = (ch, scale, color)
        surf = self._gc.get(key)
        if surf is None:
            w, rows = self._g(ch)
            surf = pygame.Surface((w * scale, 9 * scale), pygame.SRCALPHA)
            for y, row in enumerate(rows):
                for x, c in enumerate(row):
                    if c == "#":
                        surf.fill(color, (x * scale, y * scale, scale, scale))
            self._gc[key] = surf
        return surf

    def render(self, s, scale, color):
        color = tuple(int(c) for c in color[:3])
        key = (s, scale, color)
        surf = self._sc.get(key)
        if surf is None:
            if len(self._sc) > 900:
                self._sc.clear()
            surf = pygame.Surface((max(1, self.width(s, scale)), 9 * scale), pygame.SRCALPHA)
            x = 0
            for ch in s:
                gs = self._glyph(ch, scale, color)
                surf.blit(gs, (x, 0))
                x += gs.get_width() + scale
            self._sc[key] = surf
        return surf

    def wrap(self, s, scale, maxw):
        lines, cur = [], ""
        for word in s.split():
            t = (cur + " " + word).strip()
            if self.width(t, scale) <= maxw:
                cur = t
            else:
                if cur:
                    lines.append(cur)
                cur = word
        if cur:
            lines.append(cur)
        return lines


# ======================================================================
# 3. AUDIO (chiptune sintetis, tanpa file suara)
# ======================================================================
SFX = {
    "click": [(0, 800, .05, "square", .08)],
    "hover": [(0, 400, .03, "triangle", .04)],
    "type": [(0, 1300, .02, "square", .012)],
    "coin": [(0, 988, .06, "square", .06), (.06, 1319, .14, "square", .06)],
    "good": [(0, 660, .07, "square", .06), (.07, 880, .12, "square", .06)],
    "bad": [(0, 200, .16, "sawtooth", .08), (.1, 150, .25, "sawtooth", .08)],
    "pop": [(0, 520, .05, "square", .07)],
    "flip": [(0, 700, .04, "triangle", .06)],
    "match": [(0, 784, .07, "square", .06), (.07, 1047, .12, "square", .06)],
    "boom": [(0, 90, .45, "sawtooth", .14), (.05, 60, .5, "sawtooth", .14)],
    "dig": [(0, 260, .05, "triangle", .07)],
    "eat": [(0, 900, .05, "square", .06)],
    "dramatic": [(0, 150, .4, "sawtooth", .1), (.2, 110, .6, "sawtooth", .12)],
    "fanfare": [(0, 523, .1, "square", .06), (.1, 659, .1, "square", .06),
                (.2, 784, .1, "square", .06), (.3, 1047, .28, "square", .07)],
    "fog": [(0, 120, .5, "triangle", .08)],
    "page": [(0, 1, .35, "noise", .05), (.25, 1, .2, "noise", .03)],
}


class AudioSystem:
    def __init__(self):
        self.enabled = False
        self.muted = False
        self.rate = 22050
        self.channels = 1
        self._cache = {}
        self._pending = []
        try:
            pygame.mixer.init()
            info = pygame.mixer.get_init()
            if info is not None:
                self.rate, _fmt, self.channels = info
                self.enabled = True
        except pygame.error:
            self.enabled = False

    def _make_tone(self, freq, duration, wave, vol):
        n = int(self.rate * duration)
        decay = math.log(0.0001 / vol)
        samples = array("h")
        for i in range(n):
            phase = (freq * i / self.rate) % 1.0
            if wave == "square":
                s = 1.0 if phase < 0.5 else -1.0
            elif wave == "triangle":
                s = 4.0 * abs(phase - 0.5) - 1.0
            elif wave == "sawtooth":
                s = 2.0 * phase - 1.0
            elif wave == "noise":
                s = random.uniform(-1.0, 1.0)
            else:
                s = math.sin(math.tau * phase)
            value = int(32767 * s * vol * math.exp(decay * i / n))
            samples.extend([value] * self.channels)
        return pygame.mixer.Sound(buffer=samples.tobytes())

    def beep(self, freq, duration, wave="square", vol=0.05):
        if not self.enabled or self.muted:
            return
        key = (round(freq), duration, wave, vol)
        try:
            sound = self._cache.get(key)
            if sound is None:
                sound = self._cache[key] = self._make_tone(*key)
            sound.play()
        except pygame.error:
            pass

    # --- suara ketik (bisa diganti file sendiri, lihat TYPING_SOUND_FILE) ---
    def load_typing_sound(self):
        self.typing_snd = None
        if not self.enabled or not TYPING_SOUND_FILE:
            return
        base, ext = os.path.splitext(TYPING_SOUND_FILE)
        names = [TYPING_SOUND_FILE] if ext else [base + e for e in (".wav", ".ogg", ".mp3")]
        for n in names:
            path = n if os.path.isabs(n) else os.path.join(MUSIC_DIR, n)
            if os.path.isfile(path):
                try:
                    self.typing_snd = pygame.mixer.Sound(path)
                    self.typing_snd.set_volume(max(0.0, min(1.0, TYPING_VOLUME)))
                    return
                except pygame.error:
                    pass

    def play_typing(self):
        if not self.enabled or self.muted:
            return
        if getattr(self, "typing_snd", None) is not None:
            self.typing_snd.play()
        else:
            f, var, d, w, v = TYPING_FALLBACK
            self.beep(f + random.random() * var, d, w, v)

    def later(self, seconds, fn):
        self._pending.append((pygame.time.get_ticks() + int(seconds * 1000), fn))

    def update(self):
        if not self._pending:
            return
        now = pygame.time.get_ticks()
        due = [p for p in self._pending if p[0] <= now]
        self._pending = [p for p in self._pending if p[0] > now]
        for _, fn in due:
            fn()

    def play(self, name):
        for delay, f, d, w, v in SFX[name]:
            if delay <= 0:
                self.beep(f, d, w, v)
            else:
                self.later(delay, lambda f=f, d=d, w=w, v=v: self.beep(f, d, w, v))


# ======================================================================
# 3b. MUSIK LATAR / BACKSOUND (sementara, sintetis - bisa diganti file sendiri)
# ======================================================================
MUSIC_DIR = os.path.join(BASE, "asset", "audio")
MUSIC_EXT = (".ogg", ".mp3", ".wav")


def midi_hz(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


# chords: (nada bass MIDI, interval triad). mel: per birama, (langkah 1/16, nada MIDI, panjang)
TRACKS = {
    # intro / menu: A minor, megah dan dramatis
    "menu": {
        "bpm": 78, "lead": "square", "drums": False,
        "chords": [(45, (0, 3, 7)), (41, (0, 4, 7)), (48, (0, 4, 7)), (40, (0, 4, 7))],
        "mel": [[(0, 69, 4), (4, 72, 4), (8, 76, 6), (14, 74, 2)],
                [(0, 72, 4), (4, 69, 4), (8, 77, 6), (14, 76, 2)],
                [(0, 76, 4), (4, 72, 4), (8, 79, 6), (14, 76, 2)],
                [(0, 74, 4), (4, 71, 4), (8, 68, 8)]],
    },
    # permainan: C major, ceria dan bertenaga
    "game": {
        "bpm": 108, "lead": "square", "drums": True,
        "chords": [(48, (0, 4, 7)), (45, (0, 3, 7)), (41, (0, 4, 7)), (43, (0, 4, 7))],
        "mel": [[(0, 72, 2), (2, 76, 2), (4, 79, 4), (8, 76, 2), (10, 74, 2), (12, 72, 4)],
                [(0, 69, 2), (2, 72, 2), (4, 76, 4), (8, 72, 2), (10, 71, 2), (12, 69, 4)],
                [(0, 72, 2), (2, 77, 2), (4, 81, 4), (8, 77, 2), (10, 76, 2), (12, 72, 4)],
                [(0, 74, 2), (2, 71, 2), (4, 67, 4), (8, 71, 2), (10, 74, 2), (12, 79, 4)]],
    },
    # ending / credit: F major, hangat dan penuh harapan
    "ending": {
        "bpm": 66, "lead": "triangle", "drums": False,
        "chords": [(41, (0, 4, 7)), (48, (0, 4, 7)), (43, (0, 4, 7)), (45, (0, 3, 7))],
        "mel": [[(0, 72, 8), (8, 69, 4), (12, 72, 4)],
                [(0, 76, 8), (8, 72, 4), (12, 67, 4)],
                [(0, 74, 8), (8, 71, 4), (12, 74, 4)],
                [(0, 72, 6), (6, 69, 2), (8, 69, 8)]],
    },
}


def render_track(name, rate, channels):
    """Buat satu loop musik (bytes PCM 16-bit). Dipanggil di thread latar."""
    spec = TRACKS[name]
    step = 60.0 / spec["bpm"] / 4.0
    bars = len(spec["chords"])
    passes = 2
    n = int(bars * 16 * passes * step * rate)
    buf = [0.0] * n
    tau = math.tau

    def add(start, freq, dur, wave, vol, decay=0.0):
        cnt = int(dur * rate)
        s0 = int(start * rate)
        att = max(1, int(0.008 * rate))
        rel = max(1, int(0.05 * rate))
        for i in range(cnt):
            ph = (freq * i / rate) % 1.0
            if wave == "square":
                w = 1.0 if ph < 0.5 else -1.0
            elif wave == "triangle":
                w = 4.0 * abs(ph - 0.5) - 1.0
            else:
                w = 2.0 * ph - 1.0
            e = min(1.0, i / att, (cnt - i) / rel)
            if decay:
                e *= math.exp(-decay * i / rate)
            buf[(s0 + i) % n] += w * e * vol
        time.sleep(0.001)

    def noise(start, dur, vol, decay):
        cnt = int(dur * rate)
        s0 = int(start * rate)
        for i in range(cnt):
            buf[(s0 + i) % n] += random.uniform(-1, 1) * vol * math.exp(-decay * i / rate)

    def kick(start):
        cnt = int(0.18 * rate)
        s0 = int(start * rate)
        ph = 0.0
        for i in range(cnt):
            t = i / rate
            ph += (45 + 95 * math.exp(-t * 28)) / rate
            buf[(s0 + i) % n] += math.sin(tau * ph) * math.exp(-t * 15) * 0.38

    for p in range(passes):
        for b in range(bars):
            base = (p * bars + b) * 16
            t0 = base * step
            root, iv = spec["chords"][b]
            # pad lembut (root + kuint)
            for k in (iv[0], iv[2]):
                add(t0, midi_hz(root + 24 + k), 16 * step, "triangle", 0.09)
            # bass
            if spec["drums"]:
                for q in range(8):
                    note = root if q % 2 == 0 else root + 12
                    add(t0 + q * 2 * step, midi_hz(note), 1.7 * step, "triangle", 0.26, 2.5)
            else:
                for q in range(4):
                    add(t0 + q * 4 * step, midi_hz(root), 3.4 * step, "triangle", 0.26, 1.5)
            # arpeggio tipis di putaran kedua
            if p == 1:
                for k in range(0, 16, 2):
                    note = root + 36 + iv[(k // 2) % 3]
                    add(t0 + k * step, midi_hz(note), 1.6 * step, "square", 0.035, 4.0)
            # melodi
            for st, m, ln in spec["mel"][b]:
                add(t0 + st * step, midi_hz(m), ln * step * 0.95, spec["lead"], 0.11, 0.5)
            # drum
            if spec["drums"]:
                for st in (0, 8) + ((10,) if p == 1 else ()):
                    kick(t0 + st * step)
                for st in (4, 12):
                    noise(t0 + st * step, 0.12, 0.16, 28)
                for st in range(0, 16, 2):
                    noise(t0 + st * step, 0.03, 0.05, 90)
                time.sleep(0.001)

    peak = max(max(buf), -min(buf)) or 1.0
    k = 0.8 * 32767 / peak
    out = array("h")
    for v in buf:
        out.extend([int(v * k)] * channels)
    return out.tobytes()


class MusicSystem:
    """Backsound. Memakai file di asset/audio/ bila ada, selain itu musik sintetis bawaan."""

    def __init__(self, audio):
        self.audio = audio
        self.enabled = audio.enabled
        self.on = True
        self.volume = 0.35
        self.want = None
        self.cur = None
        self.mode = None            # "file" / "synth"
        self.ready = {}
        self.chan = None
        self._vol = -1.0
        if self.enabled:
            try:
                pygame.mixer.set_reserved(1)
                self.chan = pygame.mixer.Channel(0)
            except pygame.error:
                self.enabled = False
        if self.enabled:
            todo = [n for n in TRACKS if not self.find_file(n)]
            if todo:
                threading.Thread(target=self._worker, args=(todo,), daemon=True).start()

    @staticmethod
    def find_file(name):
        for base in (name, "bgm"):
            for ext in MUSIC_EXT:
                path = os.path.join(MUSIC_DIR, base + ext)
                if os.path.isfile(path):
                    return path
        return None

    def _worker(self, names):
        for n in names:
            try:
                self.ready[n] = render_track(n, self.audio.rate, self.audio.channels)
            except Exception:
                pass

    def set_track(self, name):
        self.want = name

    def _apply_volume(self, vol):
        try:
            pygame.mixer.music.set_volume(vol)
            self.chan.set_volume(vol)
        except pygame.error:
            pass

    def update(self):
        if not self.enabled:
            return
        vol = 0.0 if not self.on else self.volume      # hanya tombol MUSIK yang mematikan musik
        if vol != self._vol:
            self._vol = vol
            self._apply_volume(vol)
        if self.want is None or self.want == self.cur:
            return
        try:
            path = self.find_file(self.want)
            if path:
                self.chan.stop()
                pygame.mixer.music.load(path)
                pygame.mixer.music.play(-1, fade_ms=800)
                self.mode = "file"
            else:
                data = self.ready.get(self.want)
                if data is None:
                    return                      # masih dibuat di thread latar
                if self.mode == "file":
                    pygame.mixer.music.stop()
                snd = pygame.mixer.Sound(buffer=data)
                self.chan.play(snd, loops=-1, fade_ms=800)
                self.mode = "synth"
            self.cur = self.want
            self._apply_volume(self._vol)
        except pygame.error:
            self.cur = self.want


# ======================================================================
# 4. DATA GAME: wilayah, komoditas, harga
# ======================================================================
REGIONS = ["Sumatera", "Jawa", "Kalimantan", "Sulawesi", "Papua"]
# (komoditas, julukan wilayah)
ROLE = {
    "Sumatera": ("Ikan", "MARITIM"),
    "Jawa": (None, "KOTA EKSPOR"),
    "Kalimantan": ("Kayu", "HUTAN"),
    "Sulawesi": ("Padi", "PERTANIAN"),
    "Papua": ("Besi", "PERTAMBANGAN"),
}
MINI_OF = {"Sumatera": "snake", "Kalimantan": "memory", "Papua": "mines",
           "Sulawesi": "whack", "Jawa": "quiz"}
MINI_TITLE = {"snake": "PERAHU JARING", "memory": "COCOK KAYU", "mines": "TAMBANG BESI",
              "whack": "USIR HAMA SAWAH", "quiz": "NEGOSIASI EKSPOR"}
MINI_GENRE = {"snake": "Snake", "memory": "Match Tiles", "mines": "Minesweeper",
              "whack": "Whack-a-Mole", "quiz": "Kuis 5 soal"}
PRICE = {"Padi": 1.0, "Ikan": 1.5, "Kayu": 2.0, "Besi": 3.0}
COMMS = ["Padi", "Ikan", "Kayu", "Besi"]
TIER_NAMES = ["Kritis", "Berkembang", "Maju", "Metropolitan"]

OFFERS = [
    "Pengusaha tambang menawarkan Rp{x} juta agar izin tambang baru dipercepat tanpa AMDAL.",
    "Kontraktor megaproyek jalan menawarkan Rp{x} juta sebagai 'uang terima kasih'.",
    "Eksportir besar menawarkan Rp{x} juta agar kuota ekspor komoditasnya diprioritaskan.",
    "Seorang pejabat daerah menawarkan Rp{x} juta untuk 'pembagian jatah' anggaran DAK.",
]

QUOTES = {
    1: "Selamat bertugas, Presiden! Jaga kemakmuran semua pulau.",
    2: "Kemakmuran pulau mulai diuji. Ingat angkanya sebelum kabut turun!",
    3: "Ekonomi bergerak. Hasil bumi laku di pasar luar negeri.",
    4: "Pulau yang kurang diperhatikan mulai bersuara.",
    5: "Fase krisis! Waktu pengamatan kini hanya 5 detik.",
    6: "Rakyat menuntut lebih. Jaga kas tetap cukup.",
    7: "Godaan suap makin sering. Tetaplah jujur!",
    8: "Kabut makin tebal. Satu pulau bisa tertutup 2 hari berturut-turut!",
    9: "Hampir selesai. Bisakah semua pulau sejahtera?",
    10: "Hari terakhir! Semua keputusanmu akan dimuat di koran.",
}


def tier_of(v):
    return 0 if v < 30 else 1 if v < 55 else 2 if v < 75 else 3


def exploit_mult(n):
    """Pengali penyusutan kemakmuran akibat eksploitasi.
    n = jumlah hari berturut-turut minigame produksi dimainkan di satu pulau.
      1 hari -> 1.0x | 2 -> 1.1x | 3 -> 1.2x | 4 -> 1.3x | 5 -> 1.4x | 6+ -> 2.0x (lompat)"""
    if n <= 1:
        return 1.0
    if n >= 6:
        return 2.0
    return round(1.0 + 0.1 * (n - 1), 1)


# ======================================================================
# BENCANA ACAK & RAK PIALA
# ======================================================================
DISASTER_CHANCE = 0.45      # peluang ada bencana tiap malam (hari 1-9)
DISASTER_DOUBLE = 0.12      # peluang bencana kedua pada malam yang sama
DEMO_MAX = 5                # demo (kecil + besar) paling banyak terjadi 5 kali per permainan
DEMO_MIN_DISSAT = 45        # demo baru bisa terjadi jika ketidakpuasan rakyat >= 45%
EXPLOIT_PRONE = ("banjir", "longsor", "kebakaran", "kekeringan")   # lebih sering di pulau yang dieksploitasi

# w = bobot jenis, reg = bobot per pulau (default 1, 0 = tidak mungkin), dmg = kerugian kemakmuran,
# stock = bagian stok hasil pulau yang rusak, dissat = tambahan ketidakpuasan rakyat
# Event rakyat: dipicu oleh persentase ketidakpuasan (bukan bencana alam)
PEOPLE = {
    "demo": dict(name="DEMO RAKYAT", bad=True, color=(204, 98, 40),
                 text="Ratusan warga turun ke jalan di {r} membawa poster tuntutan. Lalu lintas lumpuh dan "
                      "para pedagang menutup toko."),
    "demo_besar": dict(name="DEMO BESAR-BESARAN", bad=True, color=(190, 40, 40),
                       text="Ribuan warga memenuhi jalanan {r} menuntut presiden turun tangan. Fasilitas umum "
                            "rusak dan pasar tutup."),
    "apresiasi": dict(name="APRESIASI RAKYAT", bad=False, color=(46, 160, 90),
                      text="Warga {r} menggelar syukuran dan mengumpulkan sumbangan sebagai tanda terima kasih "
                           "atas kepemimpinanmu."),
    "pesta": dict(name="PESTA RAKYAT", bad=False, color=(222, 160, 34),
                  text="Warga {r} berpesta di jalanan! Spanduk terima kasih terbentang di mana-mana dan "
                       "relawan ramai membantu pembangunan."),
}


DISASTERS = {
    "panas": dict(name="MUSIM PANAS TERIK", trophy="Penyintas Terik", hint="Alami musim panas terik.",
                  text="Gelombang panas menyengat {r}. Sawah retak, sungai menyusut, dan warga berlindung di rumah.",
                  w=1.0, reg={}, dmg=(5, 9), stock=0.20, dissat=2, shake=0.0, color=(214, 138, 30)),
    "banjir": dict(name="BANJIR BANDANG", trophy="Penyintas Banjir", hint="Alami banjir bandang.",
                   text="Hujan deras berhari-hari membuat sungai di {r} meluap. Permukiman dan lahan terendam.",
                   w=1.0, reg={"Kalimantan": 1.5, "Sumatera": 1.5}, dmg=(6, 12), stock=0.25, dissat=3, shake=0.0,
                   color=(50, 110, 200)),
    "gunung": dict(name="GUNUNG MELETUS", trophy="Penyintas Letusan", hint="Alami letusan gunung berapi.",
                   text="Gunung berapi di {r} meletus! Abu vulkanik menutup langit dan ribuan warga mengungsi.",
                   w=0.8, reg={"Kalimantan": 0, "Jawa": 2, "Sumatera": 2, "Sulawesi": 1.5, "Papua": 0.5},
                   dmg=(10, 16), stock=0.30, dissat=4, shake=1.0, color=(196, 60, 30)),
    "kekeringan": dict(name="KEKERINGAN PANJANG", trophy="Penyintas Kemarau", hint="Alami kekeringan panjang.",
                       text="Hujan tak turun berminggu-minggu di {r}. Sumur kering dan hasil bumi gagal panen.",
                       w=1.0, reg={"Jawa": 1.5, "Papua": 0.5}, dmg=(6, 11), stock=0.30, dissat=3, shake=0.0,
                       color=(166, 116, 48)),
    "gempa": dict(name="GEMPA BUMI", trophy="Penyintas Gempa", hint="Alami gempa bumi.",
                  text="Gempa kuat mengguncang {r}. Bangunan retak dan warga berhamburan ke lapangan terbuka.",
                  w=1.0, reg={"Kalimantan": 0.3, "Sumatera": 2, "Jawa": 2, "Sulawesi": 2, "Papua": 1.5},
                  dmg=(8, 14), stock=0.0, dissat=4, shake=1.2, color=(150, 56, 56)),
    "longsor": dict(name="TANAH LONGSOR", trophy="Penyintas Longsor", hint="Alami tanah longsor.",
                    text="Lereng bukit di {r} runtuh setelah hujan lebat. Jalan terputus dan sebuah desa tertimbun.",
                    w=1.0, reg={"Kalimantan": 0.7, "Sumatera": 1.5, "Jawa": 1.5, "Papua": 1.5, "Sulawesi": 1.5},
                    dmg=(5, 10), stock=0.10, dissat=2, shake=0.6, color=(120, 88, 56)),
    "tsunami": dict(name="TSUNAMI", trophy="Penyintas Tsunami", hint="Alami tsunami (jarang terjadi).",
                    text="Gelombang raksasa menghantam pesisir {r}. Pelabuhan dan kampung nelayan porak-poranda.",
                    w=0.45, reg={"Kalimantan": 0.2, "Sumatera": 1.5, "Sulawesi": 1.5}, dmg=(12, 18), stock=0.30,
                    dissat=5, shake=1.0, color=(30, 88, 168)),
    "kebakaran": dict(name="KEBAKARAN HUTAN", trophy="Penyintas Karhutla", hint="Alami kebakaran hutan dan lahan.",
                      text="Api melalap hutan di {r}. Kabut asap pekat menyelimuti pulau dan mengganggu warga.",
                      w=1.0, reg={"Kalimantan": 2, "Sumatera": 2, "Papua": 1, "Sulawesi": 0.5, "Jawa": 0.2},
                      dmg=(6, 11), stock=0.20, dissat=3, shake=0.0, color=(216, 86, 20)),
    "badai": dict(name="BADAI TROPIS", trophy="Penyintas Badai", hint="Alami badai tropis dan angin puting beliung.",
                  text="Badai dan angin puting beliung menyapu {r}. Atap beterbangan dan perahu terbalik.",
                  w=1.0, reg={}, dmg=(5, 9), stock=0.10, dissat=2, shake=0.5, color=(86, 98, 140)),
}

# (id, nama piala, petunjuk) - 3 piala rating akhir + 1 piala per jenis bencana
TROPHIES = [
    ("r_berhasil", "Presiden Berhasil", "Akhiri jabatan dengan rata-rata kemakmuran pulau di atas 65%."),
    ("r_biasa", "Presiden Biasa Saja", "Akhiri jabatan dengan rata-rata kemakmuran pulau 40% - 65%."),
    ("r_gagal", "Presiden Gagal", "Akhiri jabatan dengan rata-rata kemakmuran pulau di bawah 40%."),
] + [(k, d["trophy"], d["hint"]) for k, d in DISASTERS.items()]
TROPHY_BY_ID = {t[0]: t for t in TROPHIES}

TROPHY_FILE = os.path.join(BASE, "piala.json")


TUTORIAL_PERSIST = True     # True: counter tombol START disimpan di file (tutorial benar-benar hanya sekali)


def _read_save():
    try:
        with open(TROPHY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _write_save(**kw):
    d = _read_save()
    d.update(kw)
    try:
        with open(TROPHY_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=1)
    except OSError:
        pass


def load_trophies():
    return {k: int(v) for k, v in _read_save().get("piala", {}).items() if k in TROPHY_BY_ID}


def save_trophies(t):
    _write_save(piala=t)


def load_start_count():
    try:
        return max(0, int(_read_save().get("start_count", 0)))
    except (TypeError, ValueError):
        return 0


def save_start_count(n):
    _write_save(start_count=n)


def rating_of(avg):
    """Rating akhir dari rata-rata kemakmuran 5 pulau: >65 berhasil, 40-65 biasa saja, <40 gagal."""
    return "berhasil" if avg > 65 else "biasa" if avg >= 40 else "gagal"


def bar_color(v):
    return GREEN if v >= 60 else YELLOW if v >= 35 else RED2


# ======================================================================
# 5. PETA: bentuk pulau (koordinat lokal peta 416x326)
# ======================================================================
MAP = pygame.Rect(6, 28, 416, 326)
POLY = {
    "Sumatera": [(8, 30), (34, 12), (64, 24), (96, 58), (124, 96), (150, 136), (160, 172),
                 (138, 180), (104, 150), (70, 118), (36, 84), (10, 56)],
    "Kalimantan": [(180, 36), (214, 14), (256, 20), (286, 52), (290, 96), (270, 138), (232, 156),
                   (194, 146), (170, 112), (168, 68)],
    "Sulawesi": [(306, 30), (344, 16), (384, 34), (378, 62), (348, 70), (352, 104), (382, 126),
                 (376, 170), (350, 184), (334, 160), (326, 116), (306, 92), (300, 56)],
    "Jawa": [(40, 226), (96, 200), (170, 208), (240, 198), (292, 214), (298, 254), (240, 276),
             (170, 270), (100, 282), (48, 266)],
    "Papua": [(322, 240), (352, 226), (392, 234), (408, 262), (402, 300), (374, 320), (338, 314),
              (316, 288), (314, 258)],
}
LABEL_POS = {"Sumatera": (46, 166), "Kalimantan": (230, 178), "Sulawesi": (346, 204),
             "Jawa": (132, 304), "Papua": (262, 306)}
CENTER = {r: (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))
          for r, pts in POLY.items()}
GROUND = {  # rumput, rumput2, pasir, tebing
    "Sumatera": ((62, 128, 100), (78, 148, 116), (214, 190, 128), (62, 38, 34)),
    "Kalimantan": ((34, 92, 56), (44, 112, 66), (150, 128, 84), (62, 38, 34)),
    "Sulawesi": ((118, 160, 64), (140, 180, 76), (210, 184, 110), (62, 38, 34)),
    "Jawa": ((84, 92, 106), (100, 108, 122), (150, 150, 162), (48, 44, 56)),
    "Papua": ((120, 92, 72), (138, 106, 82), (180, 150, 110), (58, 36, 30)),
}


def point_in_poly(pos, pts):
    x, y = pos
    inside = False
    j = len(pts) - 1
    for i in range(len(pts)):
        xi, yi = pts[i]
        xj, yj = pts[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


# Bangunan tiap pulau: (jenis, tingkat kesejahteraan minimum agar muncul)
SPECS = {
    "Sumatera": [("fishery", 0), ("stilt", 0), ("stilt", 0), ("fhouse", 1), ("fhouse", 1),
                 ("port", 1), ("market", 2), ("lighthouse", 2), ("cannery", 3)],
    "Kalimantan": [("sawmill", 0), ("treehut", 0), ("treehut", 0), ("cabin", 1), ("cabin", 1),
                   ("port", 1), ("clinic", 2), ("plywood", 2), ("longhouse", 3)],
    "Sulawesi": [("paddy", 0), ("farmhut", 0), ("farmhut", 0), ("farmhouse", 1), ("farmhouse", 1),
                 ("port", 1), ("paddy", 1), ("clinic", 2), ("ricemill", 2), ("paddy", 2),
                 ("silo", 3)],
    "Jawa": [("exportport", 0), ("kampung", 0), ("kampung", 0), ("kampung", 0), ("shop", 1),
             ("shop", 1), ("clinic", 1), ("factory", 2), ("city", 2), ("city", 3),
             ("monas", 3), ("airport", 3)],
    "Papua": [("ironmine", 0), ("minehut", 0), ("minehut", 0), ("house", 1), ("port", 1),
              ("clinic", 2), ("smelter", 2), ("airport", 3), ("ironmine", 3)],
}
DECOR = {"Sumatera": ("palm", 9), "Kalimantan": ("jungle", 26), "Sulawesi": ("palm", 4),
         "Jawa": ("tree", 4), "Papua": ("rocks", 8)}
DECOR_KINDS = {"palm", "jungle", "rocks", "tree"}
COASTAL = {"port", "exportport"}
RAD = {"fishery": 18, "stilt": 8, "fhouse": 10, "port": 15, "market": 12, "lighthouse": 8,
       "cannery": 15, "palm": 5, "sawmill": 17, "treehut": 9, "cabin": 10, "clinic": 11,
       "plywood": 15, "longhouse": 17, "jungle": 7, "paddy": 15, "farmhut": 8, "farmhouse": 10,
       "ricemill": 13, "silo": 9, "exportport": 20, "kampung": 8, "shop": 11, "factory": 16,
       "city": 20, "monas": 8, "airport": 22, "ironmine": 18, "minehut": 8, "smelter": 15,
       "rocks": 6, "house": 10, "tree": 6}


def build_layout(region):
    poly = POLY[region]
    rng = random.Random(REGIONS.index(region) * 97 + 13)
    xs, ys = [p[0] for p in poly], [p[1] for p in poly]
    cx, cy = CENTER[region]
    placed, out = [], []

    def ok(x, y, r, m, spacing):
        pts = ((0, 0), (m, 0), (-m, 0), (0, m), (0, -m))
        if not all(point_in_poly((x + dx, y + dy), poly) for dx, dy in pts):
            return False
        return all((x - px) ** 2 + (y - py) ** 2 >= ((r + pr) * spacing) ** 2
                   for px, py, pr in placed)

    dkind, dcount = DECOR[region]
    items = [(k, t) for k, t in SPECS[region]] + [(dkind, 0)] * dcount
    for idx, (kind, tier) in enumerate(items):
        r = RAD[kind]
        coastal = kind in COASTAL
        spot = None
        for mf, spacing in ((0.7, 0.85), (0.35, 0.7), (0.1, 0.5)):
            cands = []
            for _ in range(250):
                if idx == 0 and not coastal:
                    x, y = cx + rng.uniform(-35, 35), cy + rng.uniform(-25, 25)
                else:
                    x, y = rng.uniform(min(xs), max(xs)), rng.uniform(min(ys), max(ys))
                x, y = int(x), int(y)
                m = 5 if coastal else r * mf
                if ok(x, y, r, m, spacing):
                    cands.append((x, y))
                    if not coastal:
                        break
            if cands:
                spot = max(cands, key=lambda c: c[1]) if coastal else cands[0]
                break
        if spot:
            placed.append((spot[0], spot[1], r))
            out.append((kind, spot[0], spot[1], tier))
    return out


LAYOUT = {r: build_layout(r) for r in REGIONS}

# ======================================================================
# 6. SPRITE BANGUNAN (flat pixel-art seperti gaya intro)
# ======================================================================
_T = None
_OX = _OY = 0
_GR = False


def use_target(surf, ox=0, oy=0, gray=False):
    global _T, _OX, _OY, _GR
    _T, _OX, _OY, _GR = surf, ox, oy, gray


def C(c):
    if not _GR:
        return c
    v = int((0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]) * 0.8 + 40)
    return (v, v, v)


def R(c, x, y, w, h):
    if w > 0 and h > 0:
        _T.fill(C(c), (int(x - _OX), int(y - _OY), int(w), int(h)))


def P(c, pts):
    pygame.draw.polygon(_T, C(c), [(int(x - _OX), int(y - _OY)) for x, y in pts])


def CI(c, x, y, r):
    pygame.draw.circle(_T, C(c), (int(x - _OX), int(y - _OY)), r)


def LN(c, a, b, w=1):
    pygame.draw.line(_T, C(c), (int(a[0] - _OX), int(a[1] - _OY)),
                     (int(b[0] - _OX), int(b[1] - _OY)), w)


WOOD = (120, 78, 44)
WOOD2 = (176, 128, 74)
WOOD_D = (78, 50, 30)
WALL = (236, 226, 200)
ROOF = (176, 56, 48)
LIGHT = (255, 226, 140)


def s_tree(x, y):
    R((84, 58, 36), x - 1, y - 6, 3, 7)
    R((58, 38, 26), x + 1, y - 6, 1, 7)
    CI((30, 92, 56), x + 1, y - 9, 6)
    CI((46, 122, 72), x - 1, y - 11, 5)
    CI((76, 164, 98), x - 2, y - 13, 3)
    R((140, 204, 132), x - 4, y - 14, 2, 1)


def s_palm(x, y):
    R((150, 108, 62), x - 1, y - 13, 2, 13)
    for k in range(0, 12, 3):
        R((112, 78, 44), x - 1, y - 12 + k, 2, 1)
    top = (x, y - 14)
    for dx, dy, c in ((-9, -8, (34, 118, 64)), (9, -8, (34, 118, 64)), (-7, -15, (58, 156, 84)),
                      (7, -15, (58, 156, 84)), (0, -19, (96, 196, 112))):
        LN(c, top, (x + dx, y + dy), 2)
    LN((30, 104, 58), (x - 9, y - 8), (x - 11, y - 4), 1)
    LN((30, 104, 58), (x + 9, y - 8), (x + 11, y - 4), 1)
    CI((106, 70, 38), x - 1, y - 12, 1)
    CI((106, 70, 38), x + 2, y - 12, 1)


def s_jungle(x, y):
    R((70, 48, 30), x - 1, y - 6, 3, 7)
    CI((14, 56, 38), x + 1, y - 8, 8)
    CI((24, 80, 48), x, y - 10, 7)
    CI((38, 104, 60), x - 2, y - 13, 5)
    CI((62, 138, 80), x - 3, y - 15, 3)
    R((118, 186, 112), x - 5, y - 16, 2, 1)


def s_rocks(x, y):
    R((70, 56, 52), x - 7, y, 14, 1)
    P((132, 114, 106), [(x - 6, y), (x - 3, y - 7), (x + 2, y - 6), (x + 5, y)])
    P((166, 148, 134), [(x - 3, y - 7), (x + 2, y - 6), (x, y - 3), (x - 4, y - 3)])
    P((92, 78, 74), [(x + 1, y - 5), (x + 5, y), (x + 1, y)])
    P((150, 130, 118), [(x - 9, y + 1), (x - 7, y - 3), (x - 4, y + 1)])


def s_stilt(x, y):
    R(WOOD_D, x - 6, y - 6, 2, 7)
    R(WOOD_D, x + 4, y - 6, 2, 7)
    R(WOOD, x - 7, y - 1, 14, 1)
    R((206, 166, 108), x - 7, y - 12, 14, 6)
    R((172, 132, 82), x + 3, y - 12, 4, 6)
    P((150, 100, 50), [(x - 9, y - 12), (x, y - 19), (x + 9, y - 12)])
    P((190, 132, 70), [(x - 9, y - 12), (x, y - 19), (x, y - 12)])
    R((60, 40, 28), x - 1, y - 9, 3, 3)
    R(LIGHT, x + 4, y - 10, 2, 2)


def s_fhouse(x, y):
    R(WALL, x - 8, y - 10, 16, 10)
    R((206, 196, 170), x + 4, y - 10, 4, 10)
    P((50, 130, 150), [(x - 10, y - 10), (x, y - 20), (x + 10, y - 10)])
    P((74, 162, 182), [(x - 10, y - 10), (x, y - 20), (x, y - 10)])
    R((60, 40, 28), x - 2, y - 6, 4, 6)
    R((90, 70, 60), x + 3, y - 9, 4, 4)
    R(LIGHT, x + 4, y - 8, 2, 2)


def s_house(x, y):
    R(WALL, x - 8, y - 10, 16, 10)
    R((206, 196, 170), x + 4, y - 10, 4, 10)
    P(ROOF, [(x - 10, y - 10), (x, y - 20), (x + 10, y - 10)])
    P((212, 88, 72), [(x - 10, y - 10), (x, y - 20), (x, y - 10)])
    R((120, 85, 55), x - 2, y - 6, 4, 6)
    R((90, 70, 60), x + 3, y - 9, 4, 4)
    R((150, 200, 240), x + 4, y - 8, 2, 2)


def s_clinic(x, y):
    R((250, 250, 250), x - 9, y - 14, 18, 14)
    R((214, 214, 224), x + 4, y - 14, 5, 14)
    R((180, 180, 190), x - 9, y - 3, 18, 3)
    R((196, 72, 72), x - 9, y - 15, 18, 2)
    R((200, 60, 60), x - 1, y - 12, 3, 9)
    R((200, 60, 60), x - 4, y - 9, 9, 3)


def s_fishery(x, y):
    R(WOOD, x - 18, y - 2, 36, 4)
    for i in range(-16, 18, 8):
        R(WOOD_D, x + i, y + 2, 3, 6)
    R((200, 160, 105), x - 14, y - 14, 14, 12)
    P(ROOF, [(x - 16, y - 14), (x - 7, y - 22), (x + 2, y - 14)])
    R((60, 40, 28), x - 9, y - 8, 4, 6)
    R(WOOD_D, x + 8, y - 24, 2, 22)
    P((90, 190, 220), [(x + 3, y - 22), (x + 11, y - 27), (x + 19, y - 22), (x + 11, y - 17)])
    P((90, 190, 220), [(x + 18, y - 22), (x + 23, y - 27), (x + 23, y - 17)])
    R((20, 24, 40), x + 6, y - 23, 2, 2)
    P((150, 52, 44), [(x - 14, y + 4), (x + 8, y + 4), (x + 4, y + 10), (x - 10, y + 10)])
    R((230, 230, 235), x - 3, y - 4, 2, 8)


def s_market(x, y):
    R(WOOD, x - 10, y - 8, 20, 8)
    for i in range(5):
        R(ROOF if i % 2 == 0 else WALL, x - 10 + i * 4, y - 17, 4, 6)
    R(WOOD_D, x - 10, y - 11, 2, 11)
    R(WOOD_D, x + 8, y - 11, 2, 11)
    R((150, 210, 230), x - 6, y - 10, 5, 2)
    R((250, 160, 90), x + 1, y - 10, 5, 2)


def s_lighthouse(x, y):
    P(WALL, [(x - 4, y), (x + 4, y), (x + 3, y - 26), (x - 3, y - 26)])
    R(ROOF, x - 4, y - 10, 8, 4)
    R(ROOF, x - 3, y - 20, 6, 4)
    R((255, 226, 100), x - 3, y - 31, 6, 5)
    P((60, 60, 70), [(x - 5, y - 31), (x, y - 37), (x + 5, y - 31)])


def s_factory(x, y, wall=(160, 160, 170), roof=(125, 125, 140)):
    R(wall, x - 14, y - 13, 28, 13)
    P(roof, [(x - 14, y - 13), (x - 7, y - 20), (x, y - 13), (x + 7, y - 20), (x + 14, y - 13)])
    R((175, 95, 75), x + 8, y - 30, 5, 17)
    CI((236, 236, 240), x + 10, y - 34, 4)
    CI((222, 222, 228), x + 15, y - 39, 3)
    R(LIGHT, x - 10, y - 8, 4, 4)
    R(LIGHT, x - 3, y - 8, 4, 4)


def s_cannery(x, y):
    s_factory(x, y, (150, 180, 200), (80, 120, 150))
    P((90, 190, 220), [(x - 12, y - 18), (x - 6, y - 22), (x, y - 18), (x - 6, y - 14)])


def s_plywood(x, y):
    s_factory(x, y, (176, 128, 74), (110, 74, 40))
    for k in range(3):
        R((210, 168, 108), x - 14, y + 1 + k * 2, 18, 2)


def s_sawmill(x, y):
    R(WOOD2, x - 16, y - 12, 20, 12)
    P(WOOD, [(x - 18, y - 12), (x - 6, y - 21), (x + 6, y - 12)])
    CI((205, 210, 220), x + 11, y - 8, 6)
    CI((70, 72, 84), x + 11, y - 8, 2)
    for k in range(3):
        CI((150, 100, 56), x - 12 + k * 6, y + 2, 3)
        CI((206, 164, 104), x - 12 + k * 6, y + 2, 1)


def s_treehut(x, y):
    R((100, 70, 40), x - 1, y - 16, 3, 16)
    CI((34, 110, 60), x, y - 22, 8)
    R((200, 160, 105), x - 5, y - 19, 10, 6)
    P((150, 100, 50), [(x - 7, y - 19), (x, y - 26), (x + 7, y - 19)])


def s_cabin(x, y):
    R((150, 100, 56), x - 8, y - 10, 16, 10)
    for k in (7, 4, 1):
        R(WOOD, x - 8, y - k, 16, 1)
    P((90, 60, 36), [(x - 10, y - 10), (x, y - 19), (x + 10, y - 10)])
    R((60, 40, 28), x - 2, y - 6, 4, 6)


def s_longhouse(x, y):
    for i in range(-14, 15, 7):
        R(WOOD_D, x + i, y - 6, 2, 7)
    R((190, 140, 80), x - 16, y - 14, 32, 8)
    P((130, 70, 40), [(x - 18, y - 14), (x - 12, y - 22), (x + 12, y - 22), (x + 18, y - 14)])
    for i in range(-12, 13, 6):
        R(LIGHT, x + i, y - 12, 3, 3)
    R(ROOF, x + 19, y - 20, 3, 14)
    R(GOLD2, x + 19, y - 22, 3, 3)


def s_paddy(x, y):
    for k in range(3):
        yy = y - k * 5
        col = (126, 186, 70) if k % 2 == 0 else (198, 182, 72)
        P(col, [(x - 18, yy), (x - 13, yy - 5), (x + 17, yy - 5), (x + 12, yy)])
        R((60, 100, 50), x - 14 + k * 2, yy - 3, 1, 2)
        R((60, 100, 50), x + 2 + k, yy - 3, 1, 2)
    R((120, 190, 220), x - 4, y - 1, 6, 1)


def s_farmhut(x, y):
    R((170, 130, 70), x - 6, y - 6, 12, 6)
    P((205, 175, 95), [(x - 9, y - 6), (x, y - 17), (x + 9, y - 6)])
    R((60, 40, 28), x - 1, y - 4, 3, 4)


def s_farmhouse(x, y):
    R(WALL, x - 8, y - 9, 16, 9)
    P((140, 70, 44), [(x - 12, y - 9), (x - 6, y - 15), (x + 6, y - 15), (x + 12, y - 9)])
    P((176, 90, 56), [(x - 8, y - 15), (x, y - 21), (x + 8, y - 15)])
    R((60, 40, 28), x - 2, y - 6, 4, 6)
    R(LIGHT, x + 3, y - 7, 3, 3)


def s_ricemill(x, y):
    R((190, 170, 130), x - 12, y - 12, 24, 12)
    P((120, 70, 44), [(x - 14, y - 12), (x, y - 20), (x + 14, y - 12)])
    R((90, 90, 100), x + 6, y - 26, 4, 12)
    CI((226, 226, 232), x + 8, y - 29, 3)
    for k in range(3):
        R((236, 226, 180), x - 10 + k * 6, y - 4, 5, 4)


def s_silo(x, y):
    R((190, 196, 205), x - 6, y - 22, 12, 22)
    R((150, 156, 168), x + 2, y - 22, 4, 22)
    CI((160, 166, 178), x, y - 22, 6)
    R((120, 126, 138), x - 6, y - 14, 12, 1)
    R((120, 126, 138), x - 6, y - 7, 12, 1)


def s_port(x, y):
    R(WOOD2, x - 14, y - 3, 30, 5)
    R(WOOD, x - 12, y + 2, 3, 6)
    R(WOOD, x + 11, y + 2, 3, 6)
    R((230, 160, 50), x - 10, y - 24, 3, 22)
    R((230, 160, 50), x - 10, y - 24, 16, 3)
    LN((60, 60, 60), (x + 5, y - 21), (x + 5, y - 11), 1)
    R((205, 70, 60), x + 1, y - 9, 8, 6)
    R((60, 120, 190), x - 8, y - 9, 8, 6)
    P((55, 70, 115), [(x + 16, y + 7), (x + 36, y + 7), (x + 32, y + 13), (x + 20, y + 13)])
    R((240, 240, 240), x + 22, y + 1, 7, 6)
    R((200, 60, 60), x + 25, y - 3, 2, 4)


def s_exportport(x, y):
    R((96, 96, 108), x - 22, y - 2, 46, 5)
    R((70, 70, 82), x - 22, y + 3, 46, 2)
    R((205, 60, 50), x - 16, y - 28, 3, 26)
    R((205, 60, 50), x - 16, y - 28, 24, 3)
    R((205, 60, 50), x + 5, y - 28, 3, 9)
    LN((40, 40, 40), (x + 6, y - 20), (x + 6, y - 12), 1)
    R((205, 70, 60), x - 10, y - 9, 8, 6)
    R((60, 120, 190), x - 1, y - 9, 8, 6)
    R((230, 170, 50), x - 6, y - 15, 8, 6)
    R((60, 160, 110), x + 8, y - 9, 8, 6)
    P((55, 70, 115), [(x + 16, y + 6), (x + 44, y + 6), (x + 39, y + 15), (x + 21, y + 15)])
    R((205, 70, 60), x + 22, y - 1, 7, 7)
    R((236, 236, 240), x + 30, y - 1, 7, 7)
    R((230, 170, 50), x + 26, y - 8, 7, 7)
    R((200, 60, 60), x + 36, y - 6, 2, 5)


def s_kampung(x, y):
    R((226, 200, 150), x - 10, y - 6, 9, 6)
    P((214, 110, 60), [(x - 12, y - 6), (x - 6, y - 12), (x, y - 6)])
    P((238, 140, 84), [(x - 12, y - 6), (x - 6, y - 12), (x - 6, y - 6)])
    R((236, 226, 200), x + 1, y - 8, 9, 8)
    R((210, 198, 170), x + 7, y - 8, 3, 8)
    P((176, 56, 48), [(x - 1, y - 8), (x + 5, y - 15), (x + 11, y - 8)])
    P((206, 84, 70), [(x - 1, y - 8), (x + 5, y - 15), (x + 5, y - 8)])
    R(LIGHT, x + 4, y - 5, 2, 2)


def s_shop(x, y):
    R((226, 200, 150), x - 9, y - 16, 18, 16)
    R((200, 174, 126), x + 4, y - 16, 5, 16)
    R(ROOF, x - 10, y - 9, 20, 3)
    for k in range(0, 20, 4):
        R((240, 236, 226), x - 10 + k, y - 9, 2, 3)
    R(LIGHT, x - 6, y - 14, 4, 3)
    R(LIGHT, x + 2, y - 14, 4, 3)
    R((60, 40, 28), x - 2, y - 5, 4, 5)


def s_tower(x, y, h, col):
    R(col, x - 7, y - h, 14, h)
    R((50, 75, 125), x - 7, y - h, 14, 3)
    for wy in range(y - h + 6, y - 3, 6):
        R(LIGHT, x - 4, wy, 3, 3)
        R(LIGHT, x + 1, wy, 3, 3)


def s_city(x, y):
    s_tower(x - 13, y, 22, (120, 160, 205))
    s_tower(x + 13, y, 18, (150, 150, 210))
    s_tower(x, y + 3, 32, (95, 135, 190))


def s_monas(x, y):
    R((236, 226, 200), x - 9, y - 4, 18, 4)
    R((220, 210, 184), x - 6, y - 8, 12, 4)
    R((236, 226, 200), x - 2, y - 36, 4, 28)
    R((200, 190, 164), x + 1, y - 36, 2, 28)
    R((236, 226, 200), x - 4, y - 12, 8, 3)
    CI(GOLD, x, y - 39, 3)
    R(GOLD2, x - 1, y - 36, 2, 3)


def s_airport(x, y):
    P((95, 95, 102), [(x - 24, y), (x - 15, y - 9), (x + 24, y - 9), (x + 15, y)])
    LN((240, 240, 240), (x - 8, y - 5), (x + 8, y - 5), 1)
    R((205, 205, 215), x - 14, y - 20, 9, 11)
    R((110, 150, 205), x - 14, y - 24, 9, 4)
    P((250, 250, 250), [(x + 8, y - 12), (x + 16, y - 14), (x + 12, y - 10)])


def _mine(x, y, rock, dark, acc):
    P(rock, [(x - 22, y), (x - 7, y - 24), (x + 3, y - 15), (x + 13, y - 29), (x + 25, y)])
    P(dark, [(x + 13, y - 29), (x + 25, y), (x + 8, y)])
    R((45, 35, 25), x - 5, y - 9, 9, 9)
    R((130, 90, 50), x - 7, y - 11, 13, 2)
    for ax, ay in ((x - 16, y + 2), (x + 16, y + 3), (x + 4, y + 4)):
        P(acc, [(ax, ay - 4), (ax + 3, ay), (ax, ay + 3), (ax - 3, ay)])


def s_ironmine(x, y):
    _mine(x, y, (122, 86, 72), (84, 56, 48), (226, 112, 70))
    R((60, 60, 70), x + 15, y - 14, 2, 14)
    R((60, 60, 70), x + 10, y - 16, 12, 2)
    LN((50, 50, 58), (x - 20, y + 6), (x + 22, y + 6), 1)


def s_minehut(x, y):
    R((120, 100, 80), x - 7, y - 6, 14, 6)
    P((150, 160, 172), [(x - 9, y - 6), (x - 5, y - 12), (x + 5, y - 12), (x + 9, y - 6)])
    R((60, 40, 28), x - 1, y - 4, 3, 4)


def s_smelter(x, y):
    R((110, 110, 122), x - 14, y - 12, 28, 12)
    R((90, 60, 50), x - 10, y - 26, 6, 14)
    R((90, 60, 50), x + 3, y - 22, 6, 10)
    R((255, 140, 40), x - 8, y - 8, 8, 6)
    R((255, 200, 80), x - 6, y - 7, 4, 3)
    CI((120, 110, 112), x - 7, y - 30, 4)
    CI((98, 92, 96), x - 3, y - 35, 3)


BUILD = {
    "tree": s_tree, "palm": s_palm, "jungle": s_jungle, "rocks": s_rocks, "stilt": s_stilt,
    "fhouse": s_fhouse, "house": s_house, "clinic": s_clinic, "fishery": s_fishery,
    "market": s_market, "lighthouse": s_lighthouse, "factory": s_factory, "cannery": s_cannery,
    "plywood": s_plywood, "sawmill": s_sawmill, "treehut": s_treehut, "cabin": s_cabin,
    "longhouse": s_longhouse, "paddy": s_paddy, "farmhut": s_farmhut, "farmhouse": s_farmhouse,
    "ricemill": s_ricemill, "silo": s_silo, "port": s_port, "exportport": s_exportport,
    "kampung": s_kampung, "shop": s_shop, "city": s_city, "monas": s_monas,
    "airport": s_airport, "ironmine": s_ironmine, "minehut": s_minehut, "smelter": s_smelter,
}


# ======================================================================
# 7. RENDER PULAU, KABUT, LAUT, AWAN, PERAHU
# ======================================================================
CACHE = {}
FOG = {}


def island_box(region):
    xs, ys = [p[0] for p in POLY[region]], [p[1] for p in POLY[region]]
    ox, oy = int(min(xs)) - 45, int(min(ys)) - 50
    return ox, oy, int(max(xs) - min(xs)) + 90, int(max(ys) - min(ys)) + 100


def shrink(poly, cx, cy, k):
    return [(cx + (x - cx) * k, cy + (y - cy) * k) for x, y in poly]


OUTLINE = (30, 22, 36)


def _mix(c, t, k):
    return tuple(int(c[i] + (t[i] - c[i]) * k) for i in range(3))


def PA(rgba, pts, width=0):
    """Poligon RGBA (alpha ditulis langsung) pada target aktif; width>0 = garis tepi."""
    pygame.draw.polygon(_T, C(rgba[:3]) + (rgba[3],), [(int(x - _OX), int(y - _OY)) for x, y in pts], width)


def _put_sprite(surf, kind, x, y, ox, oy, gray):
    """Gambar sprite pada kanvas kecil, beri kontur gelap 1px (gaya pixel-art RPG), tempel ke pulau."""
    ax, ay = int(x) - 75, int(y) - 92
    tmp = pygame.Surface((150, 120), pygame.SRCALPHA)
    use_target(tmp, ax, ay, gray)
    BUILD[kind](x, y)
    use_target(surf, ox, oy, gray)
    sil = pygame.mask.from_surface(tmp, 40).to_surface(setcolor=OUTLINE + (255,), unsetcolor=(0, 0, 0, 0))
    bx, by = ax - ox, ay - oy
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        surf.blit(sil, (bx + dx, by + dy))
    surf.blit(tmp, (bx, by))


def render_island(region, level, gray):
    poly = POLY[region]
    ox, oy, w, h = island_box(region)
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    use_target(surf, ox, oy, gray)
    grass, grass2, sand, cliff = GROUND[region]
    cx, cy = CENTER[region]
    rng = random.Random(REGIONS.index(region) + 50)
    WHITE_ = (255, 255, 255)
    BLACK_ = (0, 0, 0)

    def sh(k, dx=0, dy=0):
        return [(x + dx, y + dy) for x, y in shrink(poly, cx, cy, k)]

    # --- bayangan di laut, perairan dangkal, buih pantai
    PA((6, 14, 30, 70), [(x + 4, y + 13) for x, y in poly])
    PA((70, 150, 172, 70), sh(1.17, 0, 3))
    PA((104, 182, 196, 90), sh(1.11, 0, 2))
    PA((160, 220, 220, 120), sh(1.055, 0, 1))
    PA((236, 250, 248, 170), sh(1.03, 0, 1), 1)

    # --- tebing berlapis
    P(_mix(cliff, BLACK_, .38), [(x, y + 9) for x, y in poly])
    P(cliff, [(x, y + 7) for x, y in poly])
    P(_mix(cliff, WHITE_, .10), [(x, y + 4) for x, y in poly])

    # --- pasir basah, pasir kering, rumput
    P(_mix(sand, (70, 110, 130), .22), poly)
    P(sand, sh(0.975))
    P(_mix(sand, WHITE_, .18), sh(0.945))
    inner = sh(0.9)
    P(_mix(grass, BLACK_, .28), [(x, y + 2) for x, y in inner])
    P(grass, inner)

    # guratan batu pada dinding tebing
    for _ in range(260):
        x, y = rng.randint(ox, ox + w), rng.randint(oy, oy + h)
        if point_in_poly((x, y - 7), poly) and not point_in_poly((x, y), poly):
            R(_mix(cliff, BLACK_, .35 if rng.random() < .6 else .0), x, y, 1, rng.randint(2, 4))

    # --- tekstur rumput
    for _ in range(46):
        x, y = rng.randint(ox, ox + w), rng.randint(oy, oy + h)
        if point_in_poly((x, y), inner):
            CI(grass2, x, y, rng.randint(3, 7))
    for _ in range(26):
        x, y = rng.randint(ox, ox + w), rng.randint(oy, oy + h)
        if point_in_poly((x, y), inner):
            CI(_mix(grass, BLACK_, .12), x, y, rng.randint(2, 5))
    for _ in range(190):
        x, y = rng.randint(ox, ox + w), rng.randint(oy, oy + h)
        if point_in_poly((x, y), inner):
            R(_mix(grass2, WHITE_, .24), x, y - 2, 1, 2)
            R(_mix(grass, BLACK_, .22), x + 1, y - 1, 1, 2)
    if region in ("Sumatera", "Kalimantan", "Sulawesi"):
        for _ in range(130):
            x, y = rng.randint(ox, ox + w), rng.randint(oy, oy + h)
            if point_in_poly((x, y), inner):
                R(rng.choice(((255, 236, 140), (250, 250, 250), (242, 150, 184))), x, y, 1, 1)
    if region == "Papua":
        for _ in range(60):
            x, y = rng.randint(ox, ox + w), rng.randint(oy, oy + h)
            if point_in_poly((x, y), inner):
                R(_mix(sand, BLACK_, .3), x, y, 2, 1)
                R(_mix(sand, WHITE_, .2), x, y - 1, 1, 1)
    if region == "Jawa":  # petak jalan kota
        road = (72, 78, 94)
        for gx in range(70, 290, 38):
            for yy in range(204, 280, 2):
                if point_in_poly((gx, yy), inner):
                    R(road, gx, yy, 3, 2)
                    R((236, 220, 120), gx + 1, yy, 1, 1 if yy % 8 else 0)
        for gy in (228, 252):
            for xx in range(44, 296, 2):
                if point_in_poly((xx, gy), inner):
                    R(road, xx, gy, 2, 3)

    # --- kontur pulau
    PA(OUTLINE + (255,), [(x, y + 9) for x, y in poly], 1)
    PA(_mix(sand, BLACK_, .55) + (255,), poly, 1)

    # --- jalan, bayangan, lalu sprite berurutan dari belakang ke depan
    items = [b for b in LAYOUT[region] if b[3] <= level]
    hub = LAYOUT[region][0]
    road = (110, 100, 94) if level >= 2 else (190, 168, 120)
    links = [b for b in items if b is not hub and b[0] not in DECOR_KINDS]
    for b in links:
        LN(_mix(road, BLACK_, .35), (hub[1], hub[2] + 2), (b[1], b[2] + 2), 5)
    for b in links:
        LN(road, (hub[1], hub[2] + 2), (b[1], b[2] + 2), 3)
        LN(_mix(road, WHITE_, .22), (hub[1], hub[2] + 1), (b[1], b[2] + 1), 1)
    for kind, x, y, _t in items:
        r = RAD[kind]
        wd = r * 2 if kind in DECOR_KINDS else r * 2 + 4
        ht = max(4, int(r * .7))
        pygame.draw.ellipse(surf, (8, 14, 28, 70), (int(x - wd / 2 - ox + 2), int(y - ht / 2 - oy + 1), wd, ht))
    for kind, x, y, _t in sorted(items, key=lambda b: b[2]):
        _put_sprite(surf, kind, x, y, ox, oy, gray)

    use_target(None)
    return surf, (ox, oy)


def build_fog(region):
    poly = POLY[region]
    ox, oy, w, h = island_box(region)
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    rng = random.Random(REGIONS.index(region) + 7)
    xs, ys = [p[0] for p in poly], [p[1] for p in poly]
    n = 0
    for _ in range(200):
        if n >= 9:
            break
        x, y = rng.uniform(min(xs), max(xs)), rng.uniform(min(ys), max(ys))
        if point_in_poly((x, y), poly):
            ew, eh = rng.randint(46, 84), rng.randint(26, 40)
            pygame.draw.ellipse(surf, (190, 196, 212, 170),
                                (x - ox - ew / 2, y - oy - eh / 2, ew, eh))
            n += 1
    return surf, (ox, oy)


def make_sea(width, height):
    s = pygame.Surface((width, height)).convert()
    top, bot = (12, 26, 46), (24, 64, 92)
    for y in range(0, height, 2):
        t = y / max(1, height)
        col = tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3))
        s.fill(col, (0, y, width, 2))
    rng = random.Random(5)
    for _ in range(int(width * height / 800)):
        x, y = rng.randint(0, width), rng.randint(0, height)
        s.fill((40, 92, 120), (x, y, rng.randint(4, 8), 1))
    return s


def make_cloud():
    s = pygame.Surface((110, 40), pygame.SRCALPHA)
    for e in ((0, 14, 56, 22), (24, 2, 50, 28), (54, 12, 50, 22)):
        pygame.draw.ellipse(s, (170, 150, 200, 38), e)
    return s


_rg = random.Random(21)
GLINTS = [(_rg.randint(4, MAP.w - 12), _rg.randint(4, MAP.h - 6), _rg.random() * 6.28)
          for _ in range(70)]
CLOUDS = [(30, 0, 9), (150, 200, 7), (250, 90, 8)]
BOATS = [(186, 16, 40), (258, -12, 300), (72, 14, 500)]


def draw_boat(surf, x, y, flip):
    d = -1 if flip else 1
    x, y = int(x), int(y)
    pygame.draw.polygon(surf, (150, 60, 50), [(x - 10, y), (x + 10, y), (x + 7, y + 6), (x - 7, y + 6)])
    pygame.draw.line(surf, (90, 60, 40), (x, y), (x, y - 13), 1)
    pygame.draw.polygon(surf, (240, 232, 210),
                        [(x + d * 2, y - 12), (x + d * 10, y - 2), (x + d * 2, y - 2)])
    pygame.draw.line(surf, (110, 160, 190), (x - d * 11, y + 7), (x - d * 22, y + 8), 1)


# ======================================================================
# 8. LOGIKA MINIGAME (murni, tanpa gambar)
# ======================================================================
class SnakeGame:
    """Snake klasik: perahu menyeret jaring, makan ikan."""
    GW, GH = 32, 22
    TIME = 45.0

    def __init__(self):
        self.body = [(10, 11), (9, 11), (8, 11)]      # kepala di indeks 0
        self.dir = (1, 0)
        self.next = (1, 0)
        self.fish = []                                  # [x, y, nilai, ttl]
        self.score = 0
        self.eaten = 0
        self.acc = 0.0
        self.time_left = self.TIME
        self.alive = True
        self.pops = []                                  # efek teks [txt,x,y,age]
        self._spawn()
        self._spawn()

    def turn(self, d):
        if (d[0] + self.dir[0], d[1] + self.dir[1]) != (0, 0):
            self.next = d

    def _free(self):
        taken = set(self.body) | {(f[0], f[1]) for f in self.fish}
        for _ in range(200):
            c = (random.randrange(self.GW), random.randrange(self.GH))
            if c not in taken:
                return c
        return None

    def _spawn(self):
        c = self._free()
        if c is None:
            return
        gold = random.random() < 0.16
        self.fish.append([c[0], c[1], 3 if gold else 1, 6.0 if gold else 99.0])

    def interval(self):
        return max(0.07, 0.125 - 0.0018 * self.score)

    def update(self, dt):
        if not self.alive:
            return
        self.time_left -= dt
        if self.time_left <= 0:
            self.time_left = 0
            self.alive = False
            return
        for f in self.fish:
            f[3] -= dt
        self.fish = [f for f in self.fish if f[3] > 0]
        while len(self.fish) < 2:
            self._spawn()
        for p in self.pops:
            p[3] += dt
        self.pops = [p for p in self.pops if p[3] < 0.8]
        self.acc += dt
        iv = self.interval()
        while self.acc >= iv and self.alive:
            self.acc -= iv
            self.step()

    def step(self):
        self.dir = self.next
        hx, hy = self.body[0]
        nx, ny = hx + self.dir[0], hy + self.dir[1]
        grow = False
        hit = None
        for f in self.fish:
            if f[0] == nx and f[1] == ny:
                hit = f
        if hit:
            grow = True
        tail_free = self.body[:-1] if not grow else self.body
        if not (0 <= nx < self.GW and 0 <= ny < self.GH) or (nx, ny) in tail_free:
            self.alive = False
            return None
        self.body.insert(0, (nx, ny))
        if not grow:
            self.body.pop()
        else:
            self.fish.remove(hit)
            self.score += hit[2]
            self.eaten += 1
            self.pops.append(["+%d" % hit[2], nx, ny, 0.0])
            self._spawn()
            return "eat"
        return None


# (nama kayu, nama biologi/latin) - 8 jenis kayu Nusantara
WOODS = [("Jati", "Tectona grandis"), ("Meranti", "Shorea leprosula"),
         ("Ulin", "Eusideroxylon zwageri"), ("Mahoni", "Swietenia macrophylla"),
         ("Sengon", "Falcataria moluccana"), ("Merbau", "Intsia bijuga"),
         ("Pinus", "Pinus merkusii"), ("Eboni", "Diospyros celebica")]


class MemoryGame:
    """Match tiles: 8 pasang kartu - nama jenis kayu dengan nama biologinya (latin)."""
    TIME = 60.0
    N = 8

    def __init__(self):
        cards = [(i, 0) for i in range(self.N)] + [(i, 1) for i in range(self.N)]   # (pasangan, 0=nama kayu 1=latin)
        random.shuffle(cards)
        self.icon = [c[0] for c in cards]
        self.kind = [c[1] for c in cards]
        self.state = [0] * 16          # 0 tertutup, 1 terbuka, 2 cocok
        self.first = None
        self.pending = None
        self.lock = 0.0
        self.pairs = 0
        self.moves = 0
        self.time_left = self.TIME
        self.over = False

    def click(self, i):
        if self.over or self.lock > 0 or self.state[i] != 0:
            return None
        self.state[i] = 1
        if self.first is None:
            self.first = i
            return "flip"
        a, b = self.first, i
        self.first = None
        self.moves += 1
        if self.icon[a] == self.icon[b]:
            self.state[a] = self.state[b] = 2
            self.pairs += 1
            if self.pairs == self.N:
                self.over = True
            return "match"
        self.pending = (a, b)
        self.lock = 0.7
        return "miss"

    def update(self, dt):
        if self.over:
            return
        self.time_left -= dt
        if self.time_left <= 0:
            self.time_left = 0
            self.over = True
        if self.lock > 0:
            self.lock -= dt
            if self.lock <= 0 and self.pending:
                a, b = self.pending
                self.state[a] = self.state[b] = 0
                self.pending = None


class MineGame:
    """Minesweeper 9x9 dengan 10 kantong gas (ranjau)."""
    N = 9
    M = 10
    TIME = 90.0

    def __init__(self):
        n = self.N
        self.mines = None
        self.opened = [[False] * n for _ in range(n)]
        self.flag = [[False] * n for _ in range(n)]
        self.state = "play"             # play / won / lost
        self.time_left = self.TIME
        self.flag_mode = False
        self.boom = None

    def _place(self, sx, sy):
        n = self.N
        banned = {(sx + dx, sy + dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1)}
        cells = [(x, y) for x in range(n) for y in range(n) if (x, y) not in banned]
        random.shuffle(cells)
        self.mines = set(cells[:self.M])

    def count(self, x, y):
        return sum((x + dx, y + dy) in self.mines
                   for dx in (-1, 0, 1) for dy in (-1, 0, 1) if dx or dy)

    def n_open(self):
        return sum(c for row in self.opened for c in row)

    def n_flags(self):
        return sum(c for row in self.flag for c in row)

    def toggle_flag(self, x, y):
        if self.state != "play" or self.opened[x][y]:
            return
        self.flag[x][y] = not self.flag[x][y]

    def reveal(self, x, y):
        """Kembalikan 'boom' / 'dig' / None."""
        if self.state != "play" or self.flag[x][y] or self.opened[x][y]:
            return None
        if self.mines is None:
            self._place(x, y)
        if (x, y) in self.mines:
            self.state = "lost"
            self.boom = (x, y)
            return "boom"
        stack = [(x, y)]
        n = self.N
        while stack:
            cx, cy = stack.pop()
            if self.opened[cx][cy]:
                continue
            self.opened[cx][cy] = True
            self.flag[cx][cy] = False
            if self.count(cx, cy) == 0:
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        nx, ny = cx + dx, cy + dy
                        if 0 <= nx < n and 0 <= ny < n and not self.opened[nx][ny]:
                            stack.append((nx, ny))
        if self.n_open() == n * n - self.M:
            self.state = "won"
        return "dig"

    def update(self, dt):
        if self.state == "play":
            self.time_left -= dt
            if self.time_left <= 0:
                self.time_left = 0
                self.state = "lost"

    def reward(self):
        base = self.n_open() // 6
        if self.state == "won":
            return base + 5
        return base // 2


class WhackGame:
    """Whack-a-mole: usir tikus dan wereng, jangan pukul bebek."""
    TIME = 30.0

    def __init__(self):
        self.holes = [None] * 9
        self.score = 0
        self.hits = 0
        self.time_left = self.TIME
        self.spawn_t = 0.4
        self.pops = []
        self.over = False

    def update(self, dt):
        if self.over:
            return
        self.time_left -= dt
        if self.time_left <= 0:
            self.time_left = 0
            self.over = True
            return
        prog = 1 - self.time_left / self.TIME
        for i, h in enumerate(self.holes):
            if h is None:
                continue
            h["age"] += dt
            if h["hit"]:
                h["hit_t"] += dt
                if h["hit_t"] > 0.25:
                    self.holes[i] = None
            elif h["age"] > h["life"]:
                self.holes[i] = None
        for p in self.pops:
            p[3] += dt
        self.pops = [p for p in self.pops if p[3] < 0.7]
        self.spawn_t -= dt
        if self.spawn_t <= 0:
            self.spawn_t = max(0.28, 0.75 - 0.45 * prog)
            free = [i for i, h in enumerate(self.holes) if h is None]
            if free and sum(h is not None for h in self.holes) < 3:
                roll = random.random()
                kind = "duck" if roll < 0.2 else "gold" if roll < 0.3 else "rat"
                life = max(0.6, 1.15 - 0.5 * prog)
                self.holes[random.choice(free)] = {"kind": kind, "age": 0.0, "life": life,
                                                   "hit": False, "hit_t": 0.0}

    def click(self, i):
        h = self.holes[i]
        if h is None or h["hit"] or h["age"] < 0.08:
            return None
        h["hit"] = True
        if h["kind"] == "duck":
            self.score -= 2
            self.pops.append(["-2", i, 0, 0.0])
            return "bad"
        val = 3 if h["kind"] == "gold" else 1
        self.score += val
        self.hits += 1
        self.pops.append(["+%d" % val, i, 0, 0.0])
        return "pop"


QUIZ_BANK = [
    ("Siapa yang membacakan teks Proklamasi Kemerdekaan Indonesia?",
     ["Ir. Soekarno", "Sutan Sjahrir", "Jenderal Sudirman", "Ki Hajar Dewantara"], 0,
     "Soekarno membacakan Proklamasi, didampingi Moh. Hatta."),
    ("Kapan Indonesia memproklamasikan kemerdekaannya?",
     ["28 Oktober 1928", "17 Agustus 1945", "1 Juni 1945", "20 Mei 1908"], 1,
     "Proklamasi dibacakan pada 17 Agustus 1945."),
    ("Sila pertama Pancasila berbunyi?",
     ["Kemanusiaan yang adil dan beradab", "Persatuan Indonesia",
      "Ketuhanan Yang Maha Esa", "Keadilan sosial"], 2,
     "Sila pertama: Ketuhanan Yang Maha Esa."),
    ("Selat yang memisahkan Pulau Sumatera dan Pulau Jawa adalah?",
     ["Selat Sunda", "Selat Bali", "Selat Makassar", "Selat Malaka"], 0,
     "Selat Sunda berada di antara Sumatera dan Jawa."),
    ("Pulau terluas yang seluruhnya berada di wilayah Indonesia adalah?",
     ["Jawa", "Sulawesi", "Sumatera", "Halmahera"], 2,
     "Sumatera, dengan luas sekitar 470 ribu km2."),
    ("Puncak Jaya, puncak tertinggi di Indonesia, terletak di?",
     ["Papua", "Sumatera", "Kalimantan", "Sulawesi"], 0,
     "Puncak Jaya ada di Pegunungan Jayawijaya, Papua."),
    ("Candi Borobudur berada di provinsi?",
     ["Jawa Timur", "Bali", "Jawa Barat", "Jawa Tengah"], 3,
     "Borobudur terletak di Magelang, Jawa Tengah."),
    ("Indonesia adalah salah satu produsen terbesar dunia untuk?",
     ["Anggur", "Minyak kelapa sawit", "Gandum", "Kapas"], 1,
     "Indonesia produsen minyak sawit terbesar dunia."),
    ("Sistem irigasi sawah tradisional Bali yang diakui UNESCO disebut?",
     ["Subak", "Tumpek", "Ngaben", "Nyepi"], 0,
     "Subak adalah sistem pengairan sawah khas Bali."),
    ("Satuan mata uang Indonesia adalah?",
     ["Ringgit", "Baht", "Rupiah", "Peso"], 2,
     "Mata uang Indonesia adalah Rupiah."),
    ("Semboyan 'Bhinneka Tunggal Ika' memiliki arti?",
     ["Maju tak gentar", "Merdeka atau mati",
      "Berbeda-beda tetapi tetap satu", "Bersatu kita teguh"], 2,
     "Bhinneka Tunggal Ika: berbeda-beda tetapi tetap satu."),
    ("Sumpah Pemuda diikrarkan pada tahun?",
     ["1908", "1928", "1945", "1966"], 1,
     "Sumpah Pemuda lahir pada 28 Oktober 1928."),
    ("Danau vulkanik besar di Sumatera Utara bernama?",
     ["Danau Toba", "Danau Poso", "Danau Singkarak", "Danau Maninjau"], 0,
     "Danau Toba terbentuk dari letusan supervulkan."),
    ("Hewan khas Kalimantan yang terancam punah adalah?",
     ["Komodo", "Orangutan", "Anoa", "Cenderawasih"], 1,
     "Orangutan Kalimantan terancam punah akibat hilangnya hutan."),
    ("Burung cenderawasih adalah satwa khas dari?",
     ["Papua", "Bali", "Jawa", "Nusa Tenggara"], 0,
     "Cenderawasih dikenal sebagai burung surga dari Papua."),
    ("Rumah adat suku Toraja di Sulawesi disebut?",
     ["Joglo", "Gadang", "Tongkonan", "Honai"], 2,
     "Tongkonan adalah rumah adat Toraja."),
    ("Ikan yang menjadi komoditas ekspor perikanan utama Indonesia adalah?",
     ["Salmon", "Tuna", "Cod", "Haring"], 1,
     "Tuna adalah salah satu ekspor perikanan terbesar Indonesia."),
    ("Pelabuhan peti kemas tersibuk di Indonesia berada di?",
     ["Tanjung Priok", "Belawan", "Makassar", "Bitung"], 0,
     "Tanjung Priok di Jakarta adalah pelabuhan tersibuk Indonesia."),
    ("Selat yang memisahkan Kalimantan dan Sulawesi adalah?",
     ["Selat Sunda", "Selat Lombok", "Selat Makassar", "Selat Karimata"], 2,
     "Selat Makassar memisahkan Kalimantan dan Sulawesi."),
    ("Bijih besi dilebur dan diolah menjadi?",
     ["Aluminium", "Baja", "Kaca", "Emas"], 1,
     "Besi dilebur menjadi baja untuk bahan bangunan dan mesin."),
    ("Lagu kebangsaan Indonesia adalah?",
     ["Garuda Pancasila", "Halo-Halo Bandung", "Indonesia Raya", "Maju Tak Gentar"], 2,
     "Indonesia Raya adalah lagu kebangsaan negeri ini."),
    ("Bentuk Pulau Sulawesi sering dibandingkan dengan huruf?",
     ["S", "K", "O", "T"], 1,
     "Sulawesi berbentuk menyerupai huruf K."),
]


class QuizGame:
    PER_Q = 15.0
    N = 5

    def __init__(self):
        self.items = []
        for q, opts, ans, exp in random.sample(QUIZ_BANK, self.N):
            order = list(range(4))
            random.shuffle(order)
            self.items.append((q, [opts[i] for i in order], order.index(ans), exp))
        self.i = 0
        self.correct = 0
        self.answered = None
        self.t = self.PER_Q
        self.over = False

    def answer(self, k):
        if self.answered is not None or self.over:
            return None
        self.answered = k
        ok = k == self.items[self.i][2]
        if ok:
            self.correct += 1
        return ok

    def update(self, dt):
        if self.over or self.answered is not None:
            return False
        self.t -= dt
        if self.t <= 0:
            self.t = 0
            self.answered = -1
            return True
        return False

    def next(self):
        self.i += 1
        if self.i >= self.N:
            self.over = True
        else:
            self.answered = None
            self.t = self.PER_Q


def new_state():
    return {
        "day": 1, "budget": 100.0, "dissat": 20,
        "welfare": {r: float(random.randint(35, 65)) for r in REGIONS},
        "stock": {c: 0 for c in COMMS},
        "corrupt": 0, "personal": 0,
        "corrupt_days": random.sample(range(2, 10), 4),
        "offer": None, "sel": 0,
        "hidden": set(), "pending_hidden": set(),
        "streak": {r: 0 for r in REGIONS},
        "demos": 0,                             # berapa kali demo sudah terjadi (maks. DEMO_MAX)
        "marks": {},                            # pulau -> jenis bencana yang baru menimpa
        "pending_events": [],                   # bencana yang menunggu ditampilkan
        "exploit": {r: 0 for r in REGIONS},     # hari berturut-turut pulau dieksploitasi (s.d. kemarin)
        "played": set(),                        # pulau yang minigame-nya dimainkan hari ini
        "banner": ["", 0.0],
        "mini_done": False, "exported": False, "export_total": 0.0,
        "flash": (-1, 0.0),
        "observing": False, "obs_left": 10.0, "obs_total": 10.0,
        "end": None,
        "seceded": set(),                       # pulau yang berpisah dari Indonesia
        "thr": random.randint(50, 75),          # ambang "makmur", acak tiap permainan
    }


SCENES = (
    ("A Normal Day", 6.5, "Senin, 08:00 WIB - Hari yang awalnya terlihat biasa saja..."),
    ("Breaking News", 6.5, "Namun, sesuatu yang tidak terduga terjadi di televisi..."),
    ("Official Decree", 6.5, "PENGUMUMAN RESMI: Anda telah ditetapkan sebagai Presiden Republik!"),
    ("The Oval Office", 6.5, "Mulai hari ini, seluruh keputusan negara berada di tangan Anda."),
)
MENU_CAPTION = "Pilih tindakan Anda."


def build_credits():
    """Susun baris credit roll gaya ending anime: (teks, skala, warna, offset_y), tinggi total."""
    blocks = [("DIRECTOR", ["Nama Placeholder"]),
              ("SCENARIO", ["Nama Placeholder", "Nama Placeholder"]),
              ("CHARACTER DESIGN", ["Nama Placeholder"]),
              ("BACKGROUND ART", ["Nama Placeholder", "Nama Placeholder"]),
              ("PROGRAMMING", ["Nama Placeholder"]),
              ("SOUND DIRECTOR", ["Nama Placeholder"]),
              ("QUALITY ASSURANCE", ["Nama Placeholder", "Nama Placeholder"]),
              ("PRODUCTION", ["Studio Placeholder"]),
              ("SPECIAL THANKS", ["Nama Placeholder", "Nama Placeholder", "Nama Placeholder"])]
    out, y = [], 0
    out.append(("SUDDENLY A PRESIDENT", 2, GOLD, y))
    y += 22
    out.append(("EPISODE FINAL: SEPULUH HARI", 1, AMBER, y))
    y += 40
    out.append(("ENDING THEME", 1, AMBER, y))
    y += 16
    out.append(("Judul Lagu Placeholder", 2, CREAMT, y))
    y += 20
    out.append(("Artis Placeholder", 1, (170, 160, 140), y))
    y += 46
    for head, names in blocks:
        out.append((head, 1, AMBER, y))
        y += 15
        for n in names:
            out.append((n, 2, CREAMT, y))
            y += 19
        y += 26
    y += 10
    out.append(("TERIMA KASIH", 2, GOLD, y))
    y += 20
    out.append(("TELAH BERMAIN", 2, GOLD, y))
    y += 30
    out.append(("Indonesia menunggumu kembali.", 1, CREAMT, y))
    return out, y


class Game:
    def __init__(self):
        pygame.mixer.pre_init(22050, -16, 1, 512)
        pygame.init()
        pygame.display.set_caption(TITLE)
        try:
            pygame.display.set_icon(pygame.image.load(os.path.join(BASE, "asset", "image", "logo.png")))
        except Exception:
            pass
        try:
            dw, dh = pygame.display.get_desktop_sizes()[0]
        except Exception:
            dw, dh = 1366, 768
        ww = max(640, min(1280, int(dw * 0.94)))
        wh = max(420, min(760, int(dh * 0.90)))
        self.screen = pygame.display.set_mode((ww, wh), pygame.RESIZABLE)
        self.clock = pygame.time.Clock()
        self.font = PixelFont()
        self.audio = AudioSystem()
        self.music = MusicSystem(self.audio)

        self.cv = pygame.Surface((CW, CH)).convert()
        self.sea = make_sea(MAP.w, MAP.h)
        self.cloud = make_cloud()
        for r in REGIONS:
            FOG[r] = build_fog(r)
        self.glow = self._build_glow()
        self._overlay = None
        self._overlay_key = None
        self._tv_scan = None
        self._ic = {}
        self._decree_hit = False
        self._mn = None                    # cache latar menu (istana)
        self.trophies = load_trophies()    # {id piala: berapa kali diraih}
        self.start_count = load_start_count() if TUTORIAL_PERSIST else 0   # berapa kali START diklik
        self.tut = None
        self.cur_event = None
        self.last_trophy = None            # piala rating yang baru diraih di akhir permainan
        self.last_trophy_new = False
        self._emb = {}

        self.running = True
        self.state = "intro"
        self.scene = 0
        self.scene_time = 0.0
        self.t = 0.0
        self.shake = 0.0
        self.crt = False                   # CRT mati secara bawaan agar teks tajam; bisa dinyalakan di Pengaturan
        self.settings_from = "menu"        # pengaturan dibuka dari "menu" atau "pause"
        self.pause_from = "main"           # state yang dilanjutkan saat keluar dari jeda
        self.particles = []
        self.msg_full = ""
        self.msg_idx = 0
        self.msg_timer = 0.0

        self.s = new_state()
        self.mini = None
        self.trans = None
        self.end_stage = "room"
        self.end_t = 0.0
        self.page_front = self.page_stats = None
        self.slides = []
        self.cred_total = 60.0
        self.cred_speed = 20.0
        self._desk = self._front_view = self._cvig = self._cgrad = None
        self.secede_name = ""
        self.credits_preview = False       # True = credit dibuka dari menu (tanpa bermain)
        self.credits, self.credits_h = build_credits()
        self.ui = []
        self.mpos = (-999, -999)
        self._hov_now = None
        self._hov_prev = None
        self._cursor_hand = False
        self.view = pygame.Rect(0, 0, 640, 360)
        self.banner = pygame.Rect(0, 0, 640, 40)
        self.bs = 2

    # ------------------------------------------------------------------
    # Primitif gambar
    # ------------------------------------------------------------------
    def rectf(self, color, x, y, w, h, surf=None):
        surf = self.cv if surf is None else surf
        r = pygame.Rect(int(x), int(y), int(w), int(h))
        if r.w <= 0 or r.h <= 0:
            return
        if len(color) == 4 and color[3] < 255:
            tmp = pygame.Surface(r.size, pygame.SRCALPHA)
            tmp.fill(color)
            surf.blit(tmp, r)
        else:
            surf.fill(color[:3], r)

    def frame(self, color, rect, lw=1):
        x, y, w, h = rect
        self.rectf(color, x, y, w, lw)
        self.rectf(color, x, y + h - lw, w, lw)
        self.rectf(color, x, y, lw, h)
        self.rectf(color, x + w - lw, y, lw, h)

    def circle(self, color, cx, cy, r, width=0):
        if len(color) == 4 and color[3] < 255:
            tmp = pygame.Surface((2 * r + 2, 2 * r + 2), pygame.SRCALPHA)
            pygame.draw.circle(tmp, color, (r + 1, r + 1), r, width)
            self.cv.blit(tmp, (round(cx) - r - 1, round(cy) - r - 1))
        else:
            pygame.draw.circle(self.cv, color[:3], (round(cx), round(cy)), r, width)

    def polygon(self, color, points):
        if len(color) == 3 or color[3] == 255:
            pygame.draw.polygon(self.cv, color[:3], points)
            return
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]
        x0, y0 = int(min(xs)), int(min(ys))
        w, h = int(max(xs)) - x0 + 1, int(max(ys)) - y0 + 1
        tmp = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.polygon(tmp, color, [(px - x0, py - y0) for px, py in points])
        self.cv.blit(tmp, (x0, y0))

    def T(self, s, x, y, color=CREAMT, scale=1, align="left", shadow=None, surf=None):
        """Gambar teks pixel. y = sisi atas huruf kapital."""
        surf = self.cv if surf is None else surf
        w = self.font.width(s, scale)
        if align == "center":
            x -= w // 2
        elif align == "right":
            x -= w
        x, y = int(x), int(y)
        if shadow is not None:
            surf.blit(self.font.render(s, scale, shadow), (x + scale, y + scale))
        surf.blit(self.font.render(s, scale, color), (x, y))

    def say(self, text):
        if text != self.msg_full:
            self.msg_full = text
            self.msg_idx = 0
            self.msg_timer = 0.0

    def button(self, bid, rect, label, enabled=True, scale=1, style="normal", icon=None):
        """Tombol perintah gaya RPG: bevel, bayangan, kursor panah saat disorot."""
        rect = pygame.Rect(rect)
        hover = enabled and rect.collidepoint(self.mpos)
        pal = {"normal": ((70, 90, 170), (34, 44, 104), (150, 172, 240), TXT),
               "primary": ((190, 130, 36), (116, 66, 18), (255, 226, 130), (255, 246, 206)),
               "go": ((52, 150, 90), (24, 82, 52), (140, 232, 160), (226, 255, 232)),
               "danger": ((176, 56, 52), (98, 24, 30), (255, 150, 120), (255, 232, 220))}
        top, bot, edge, fg = pal.get(style, pal["normal"])
        if not enabled:
            top, bot, edge, fg = (62, 64, 78), (40, 42, 54), (92, 94, 112), (126, 130, 150)
        elif hover:
            top = self._mix(top, (255, 255, 255), .22)
            bot = self._mix(bot, (255, 255, 255), .16)
            edge, fg = GOLD, (255, 255, 232)
            self._hov_now = bid
        x, y, w, h = rect.x, rect.y, rect.w, rect.h
        R = self.rectf
        R((0, 0, 0, 100), x + 1, y + 2, w, h)
        R(WIN_EDGE, x + 1, y, w - 2, h)
        R(WIN_EDGE, x, y + 1, w, h - 2)
        R(edge, x + 1, y + 1, w - 2, h - 2)
        half = (h - 4) // 2
        R(top, x + 2, y + 2, w - 4, half)
        R(bot, x + 2, y + 2 + half, w - 4, h - 4 - half)
        R(self._mix(top, (255, 255, 255), .35), x + 2, y + 2, w - 4, 1)
        R(self._mix(bot, (0, 0, 0), .4), x + 2, y + h - 3, w - 4, 1)
        tw = self.font.width(label, scale)
        ty = y + (h - 7 * scale) // 2
        cx = rect.centerx
        if icon:
            self.pic(icon, x + 6, y + (h - 8) // 2)
            cx += 6
        elif hover and tw + 30 <= w:
            self.pic("cursor", x + 4 + int(self.t * 6) % 2, y + (h - 9) // 2)
        if enabled:
            self.OT(label, cx, ty, fg, scale, "center", self._mix(bot, (0, 0, 0), .65))
        else:
            self.T(label, cx, ty, fg, scale, "center")
        self.ui.append((bid, rect, enabled))

    # ------------------------------------------------------------------
    # Partikel debu emas (dari intro)
    # ------------------------------------------------------------------
    def init_particles(self):
        self.particles = [
            [random.random() * CW, random.random() * CH, (random.random() - .5) * .2,
             (random.random() - .5) * .2, random.random() * 1.5 + .5, random.random() * .6 + .2]
            for _ in range(40)]

    def update_particles(self, dt):
        k = dt * 60
        for p in self.particles:
            p[0] += p[2] * k
            p[1] += p[3] * k
            if p[0] < 0:
                p[0] = CW - 1
            if p[0] >= CW:
                p[0] = 0
            if p[1] < 0:
                p[1] = CH - 1
            if p[1] >= CH:
                p[1] = 0

    def draw_particles(self, rgb=(255, 215, 0)):
        for p in self.particles:
            if int(p[4]) < 1:
                continue
            x, y = int(p[0]), int(p[1])
            if 0 <= x < CW and 0 <= y < CH:
                bg = self.cv.get_at((x, y))
                a = p[5]
                self.cv.set_at((x, y), (round(bg[0] * (1 - a) + rgb[0] * a),
                                        round(bg[1] * (1 - a) + rgb[1] * a),
                                        round(bg[2] * (1 - a) + rgb[2] * a)))

    # ------------------------------------------------------------------
    # INTRO (4 adegan sinematik, gaya pixel-art game strategi indie)
    # ------------------------------------------------------------------
    # Judul bab yang muncul di pojok kiri-atas tiap adegan (mudah diganti).
    INTRO_CHAPTERS = (("BAB I", "PAGI YANG BIASA"),
                      ("BAB II", "BERITA TERKINI"),
                      ("BAB III", "KEPUTUSAN RESMI"),
                      ("BAB IV", "ISTANA NEGARA"))
    INTRO_BAR = 24            # tinggi bar sinematik (letterbox) atas & bawah

    @staticmethod
    def _mix(a, b, k):
        return (int(a[0] + (b[0] - a[0]) * k), int(a[1] + (b[1] - a[1]) * k),
                int(a[2] + (b[2] - a[2]) * k))

    def _layer(self, key, fn):
        """Adegan statis digambar sekali lalu disimpan, supaya ringan tiap frame."""
        if not hasattr(self, "_ic"):
            self._ic = {}
        s = self._ic.get(key)
        if s is None:
            s = self._ic[key] = self.render_to(fn)
        return s

    def _glow(self, r, rgb, amax):
        """Cahaya bulat lembut (cache)."""
        key = ("glow", r, rgb, amax)
        if not hasattr(self, "_ic"):
            self._ic = {}
        s = self._ic.get(key)
        if s is None:
            s = pygame.Surface((2 * r, 2 * r), pygame.SRCALPHA)
            for rr in range(r, 0, -2):
                pygame.draw.circle(s, (*rgb, int(amax * (1 - rr / r) ** 1.6)), (r, r), rr)
            self._ic[key] = s
        return s

    def _grad(self, x, y, w, h, c0, c1, steps=8):
        """Gradien vertikal berpita dengan dither, khas pixel-art."""
        cv = self.cv
        cols = [self._mix(c0, c1, (i + .5) / steps) for i in range(steps)]
        ys = [y + round(i * h / steps) for i in range(steps + 1)]
        for i in range(steps):
            cv.fill(cols[i], (x, ys[i], w, ys[i + 1] - ys[i]))
        for i in range(1, steps):
            yb = ys[i]
            for row, col, dens in ((yb - 2, cols[i], 4), (yb - 1, cols[i], 2),
                                   (yb, cols[i - 1], 2), (yb + 1, cols[i - 1], 4)):
                if row < 0 or row >= cv.get_height():
                    continue
                for xx in range(x, x + w):
                    if dens == 2:
                        hit = (xx + row) % 2 == 0
                    else:
                        hit = (xx + 2 * (row % 2)) % 4 == 0
                    if hit:
                        cv.set_at((xx, row), col)

    def _blk(self, c, x, y, w, h, ol=None):
        if ol:
            self.rectf(ol, x - 1, y - 1, w + 2, h + 2)
        self.rectf(c, x, y, w, h)

    def _mote(self, i, t, x0, y0, w, h, rgb=(255, 238, 190)):
        """Debu melayang di dalam berkas cahaya."""
        x = x0 + (i * 53 + t * (4 + i % 5) + 9 * math.sin(t * .6 + i)) % w
        y = y0 + (i * 71 + t * (2 + i % 3) * .8 + 6 * math.sin(t * .8 + i * 2)) % h
        a = 70 + int(70 * (0.5 + 0.5 * math.sin(t * 1.3 + i * 1.7)))
        self.rectf((*rgb, a), x, y, 2 if i % 3 == 0 else 1, 2 if i % 3 == 0 else 1)

    # ------------------------------------------------------------------
    # Efek sinematik bersama: vinyet, grain, bar, judul bab, fade
    # ------------------------------------------------------------------
    def _intro_post(self):
        cv, t = self.cv, self.scene_time
        dur = SCENES[self.scene][1]
        if not hasattr(self, "_ic"):
            self._ic = {}
        vig = self._ic.get("vig")
        if vig is None:
            vig = pygame.Surface((CW, CH), pygame.SRCALPHA)
            for d in range(0, 80, 2):
                pygame.draw.rect(vig, (0, 0, 0, int(120 * (1 - d / 80) ** 2)),
                                 (d, d, CW - 2 * d, CH - 2 * d), 2)
            self._ic["vig"] = vig
        cv.blit(vig, (0, 0))
        for _ in range(36):                       # grain film halus
            gx, gy = random.randrange(CW), random.randrange(CH)
            p = cv.get_at((gx, gy))
            cv.set_at((gx, gy), (min(255, p[0] + 18), min(255, p[1] + 18), min(255, p[2] + 18)))
        bh = self.INTRO_BAR
        cv.fill((6, 6, 9), (0, 0, CW, bh))
        cv.fill((6, 6, 9), (0, CH - bh, CW, bh))
        cv.fill(GOLD_D, (0, bh - 1, CW, 1))
        cv.fill(GOLD_D, (0, CH - bh, CW, 1))
        # judul bab: meluncur masuk, tahan, lalu keluar
        if 0.5 < t < 4.4:
            ein = min(1.0, (t - 0.5) / 0.5)
            eout = max(0.0, min(1.0, (t - 3.8) / 0.5))
            off = 230 * ((1 - ein) ** 2 + eout ** 2)
            tag, title = self.INTRO_CHAPTERS[self.scene]
            tw = max(self.font.width(title, 2), self.font.width(tag, 1)) + 16
            x = int(14 - off)
            self.rectf((0, 0, 0, 120), x - 6, bh + 6, tw + 6, 40)
            self.rectf(GOLD2, x - 6, bh + 6, 2, 40)
            self.T(tag, x + 2, bh + 11, GOLD, 1, "left", SHADOW)
            self.T(title, x + 2, bh + 24, CREAMT, 2, "left", (20, 10, 10))
        a = 0
        if t < 0.7:
            a = 255 * (1 - t / 0.7)
        if dur - t < 0.7:
            a = max(a, 255 * (1 - (dur - t) / 0.7))
        self.fade(a)

    # ------------------------------------------------------------------
    # ADEGAN 1 - Ruang tamu, pagi hari
    # ------------------------------------------------------------------
    def _bg_room(self):
        f, cv = self.rectf, self.cv
        rnd = random.Random(11)
        # dinding hangat + wallpaper bergaris + panel kayu
        self._grad(0, 0, CW, 236, (122, 88, 104), (224, 172, 124), 12)
        for x in range(0, CW, 20):
            f((255, 255, 255, 7), x, 0, 10, 236)
        f((98, 60, 50), 0, 206, CW, 30)
        f((156, 110, 80), 0, 204, CW, 2)
        for x in range(10, CW - 40, 68):
            self.frame((78, 46, 40), (x, 212, 54, 16), 1)
        f((64, 38, 32), 0, 232, CW, 6)
        # lantai kayu
        y, r = 238, 0
        while y < CH:
            f((158, 102, 62) if r % 2 == 0 else (146, 92, 56), 0, y, CW, 9)
            f((104, 64, 40), 0, y + 9, CW, 1)
            off = (r * 53) % 80
            for x in range(-off, CW, 80):
                f((112, 70, 44), x, y, 1, 9)
            y += 10
            r += 1
        f((0, 0, 0, 46), 0, 238, CW, 6)
        # ---- jendela dengan matahari terbit di atas kota
        x0, y0, w0, h0 = 64, 54, 186, 148
        f((70, 44, 38), x0 - 8, y0 - 8, w0 + 16, h0 + 16)
        cv.set_clip(pygame.Rect(x0, y0, w0, h0))
        self._grad(x0, y0, w0, h0, (30, 44, 98), (252, 176, 96), 16)
        for (cx, cy, w) in ((x0 + 22, y0 + 52, 56), (x0 + 112, y0 + 36, 46), (x0 + 70, y0 + 74, 66)):
            f((250, 150, 134), cx, cy, w, 2)
            f((250, 150, 134), cx + 8, cy - 2, w - 16, 2)
            f((255, 190, 150), cx + 14, cy - 4, w - 30, 2)
        sx, sy = x0 + 122, y0 + h0 - 34
        cv.blit(self._glow(78, (255, 210, 120), 170), (sx - 78, sy - 78))
        self.circle((255, 232, 164), sx, sy, 12)
        far, near = (118, 88, 130), (56, 42, 74)
        x = x0
        while x < x0 + w0:
            bw, bh = rnd.randint(8, 18), rnd.randint(18, 44)
            f(far, x, y0 + h0 - bh, bw, bh)
            x += bw
        x = x0 - 4
        while x < x0 + w0:
            bw, bh = rnd.randint(10, 22), rnd.randint(10, 36)
            bt = y0 + h0 - bh
            f(near, x, bt, bw, bh)
            for wy in range(bt + 3, y0 + h0 - 3, 5):
                for wx in range(x + 2, x + bw - 2, 4):
                    if rnd.random() < .3:
                        f((255, 214, 130), wx, wy, 2, 2)
            x += bw + rnd.randint(0, 2)
        mx = x0 + 52                                   # monumen kota
        f(near, mx, y0 + h0 - 98, 5, 98)
        f(near, mx - 3, y0 + h0 - 30, 11, 30)
        f((255, 205, 90), mx + 1, y0 + h0 - 106, 3, 8)
        for bx, by in ((x0 + 30, y0 + 30), (x0 + 40, y0 + 36), (x0 + 150, y0 + 22)):
            pygame.draw.line(cv, (50, 36, 60), (bx, by), (bx + 3, by + 2), 1)
            pygame.draw.line(cv, (50, 36, 60), (bx + 3, by + 2), (bx + 6, by), 1)
        cv.set_clip(None)
        f((74, 46, 38), x0 + w0 // 2 - 2, y0, 4, h0)           # kusen
        f((74, 46, 38), x0, y0 + 62, w0, 4)
        f((130, 88, 64), x0 + w0 // 2 - 2, y0, 1, h0)
        f((196, 150, 108), x0 - 12, y0 + h0 + 6, w0 + 24, 7)   # ambang jendela
        f((120, 84, 60), x0 - 12, y0 + h0 + 12, w0 + 24, 2)
        f((0, 0, 0, 40), x0 - 12, y0 + h0 + 14, w0 + 24, 5)
        # tirai
        for (cx0, sd) in ((x0 - 36, 0), (x0 + w0 + 8, 1)):
            for i in range(0, 28, 4):
                f((172, 60, 72) if (i // 4) % 2 == 0 else (124, 34, 48), cx0 + i, 48, 4, 158)
            f((0, 0, 0, 50), cx0, 190, 28, 16)
            f(GOLD2, cx0 - 1, 150, 30, 3)
        f(GOLD2, x0 - 46, 44, w0 + 92, 3)
        self.circle(GOLD, x0 - 46, 45, 4)
        self.circle(GOLD, x0 + w0 + 46, 45, 4)
        # ---- potret presiden lama di dinding
        px, py = 304, 62
        f(GOLD2, px - 4, py - 4, 48, 60)
        f((214, 176, 70), px - 2, py - 2, 44, 56)
        f((38, 58, 96), px, py, 40, 52)
        f((58, 80, 120), px, py + 34, 40, 18)
        self.circle((228, 178, 134), px + 20, py + 20, 9)
        f((30, 24, 28), px + 11, py + 10, 18, 7)
        self.polygon((32, 36, 64), [(px + 4, py + 52), (px + 8, py + 36), (px + 20, py + 31), (px + 32, py + 36), (px + 36, py + 52)])
        self.polygon((240, 240, 244), [(px + 16, py + 32), (px + 24, py + 32), (px + 20, py + 42)])
        f(RED2, px + 19, py + 36, 2, 10)
        f(GOLD2, px + 8, py + 58, 24, 6)
        # ---- jam dinding (jarum digambar dinamis)
        cx, cy = 524, 84
        self.circle((90, 58, 40), cx, cy, 27)
        self.circle((126, 86, 54), cx, cy, 25)
        self.circle((244, 236, 212), cx, cy, 22)
        for k in range(12):
            a = math.radians(k * 30)
            pygame.draw.line(cv, (60, 44, 40), (cx + math.sin(a) * 18, cy - math.cos(a) * 18),
                             (cx + math.sin(a) * 21, cy - math.cos(a) * 21), 1)
        # ---- TV (mati) di atas kabinet
        f((0, 0, 0, 56), 436, 270, 164, 8)
        f((86, 54, 40), 444, 238, 148, 28)
        f((126, 84, 58), 444, 238, 148, 3)
        f((58, 34, 28), 452, 266, 8, 12)
        f((58, 34, 28), 576, 266, 8, 12)
        f((34, 34, 40), 456, 152, 124, 88)
        f((60, 60, 70), 456, 152, 124, 2)
        f((16, 20, 28), 464, 160, 98, 68)
        self.polygon((255, 255, 255, 18), [(470, 162), (500, 162), (472, 226), (466, 226)])
        f((200, 200, 210), 568, 160, 6, 2)
        f((200, 200, 210), 568, 166, 6, 2)
        # ---- karpet, sofa, meja
        f((0, 0, 0, 52), 214, 262, 224, 12)
        self.polygon((190, 142, 68), [(214, 270), (438, 270), (466, 334), (186, 334)])
        self.polygon((136, 40, 54), [(222, 276), (430, 276), (454, 328), (198, 328)])
        self.polygon((158, 62, 72), [(236, 284), (416, 284), (434, 320), (218, 320)])
        for i in range(7):
            f((190, 142, 68), 232 + i * 28, 296, 6, 6)
        sofa_c, sofa_d, sofa_l = (82, 126, 138), (56, 92, 104), (112, 158, 168)
        f(sofa_d, 228, 186, 204, 50)
        f(sofa_l, 228, 186, 204, 3)
        for sx_ in (279, 330, 381):
            f((46, 78, 90), sx_, 190, 2, 44)
        f(sofa_c, 244, 232, 172, 30)
        f(sofa_l, 244, 232, 172, 2)
        f((46, 78, 90), 330, 234, 2, 28)
        f((36, 62, 72), 244, 258, 172, 4)
        f((62, 98, 110), 222, 204, 24, 58)
        f((62, 98, 110), 414, 204, 24, 58)
        f(sofa_l, 222, 204, 24, 3)
        f(sofa_l, 414, 204, 24, 3)
        f((40, 28, 24), 230, 262, 6, 6)
        f((40, 28, 24), 424, 262, 6, 6)
        self._blk((224, 142, 62), 250, 214, 24, 22, (120, 70, 40))
        f((244, 176, 92), 252, 216, 20, 3)
        # meja kopi
        f((0, 0, 0, 56), 250, 310, 164, 6)
        self.polygon((178, 120, 74), [(262, 282), (398, 282), (408, 294), (252, 294)])
        f((118, 74, 46), 252, 294, 156, 6)
        f((78, 48, 32), 262, 300, 5, 14)
        f((78, 48, 32), 394, 300, 5, 14)
        f((238, 234, 224), 294, 285, 36, 6)           # koran
        f((120, 120, 130), 297, 287, 30, 1)
        f((120, 120, 130), 297, 289, 22, 1)
        # tanaman
        f((0, 0, 0, 50), 14, 330, 50, 6)
        self.polygon((156, 82, 58), [(22, 296), (58, 296), (54, 334), (26, 334)])
        f((190, 112, 78), 20, 292, 40, 6)
        for ang, ln, col in ((-60, 34, (46, 140, 76)), (-30, 44, (60, 164, 90)), (0, 50, (40, 128, 70)),
                             (30, 44, (60, 164, 90)), (60, 34, (46, 140, 76)), (-80, 26, (80, 176, 100)),
                             (80, 26, (80, 176, 100))):
            a = math.radians(ang)
            tx, ty = 40 + math.sin(a) * ln, 294 - math.cos(a) * ln
            self.polygon(col, [(40, 294), (tx - 5 * math.cos(a), ty - 5 * math.sin(a)),
                               (tx, ty - 6), (tx + 5 * math.cos(a), ty + 5 * math.sin(a))])

    def _person(self, cx, sy, bob):
        f = self.rectf
        OL = (24, 18, 26)
        skin, skin2 = (232, 182, 138), (200, 146, 108)
        shirt, shirt2 = (238, 234, 224), (190, 186, 196)
        pants = (58, 70, 112)
        y = sy - bob
        self._blk(pants, cx - 13, y - 2, 26, 22, OL)
        f((40, 50, 86), cx - 1, y - 2, 2, 22)
        f((236, 236, 240), cx - 13, y + 19, 11, 4)
        f((236, 236, 240), cx + 2, y + 19, 11, 4)
        self._blk(shirt, cx - 12, y - 36, 24, 36, OL)
        f(shirt2, cx + 6, y - 36, 6, 36)
        f(skin, cx - 3, y - 37, 6, 3)
        self._blk(shirt, cx - 17, y - 32, 6, 24, OL)
        f(skin, cx - 17, y - 10, 6, 5)
        self._blk(shirt, cx + 11, y - 30, 6, 12, OL)
        self._blk(skin, cx + 10, y - 21, 8, 5, OL)
        self._blk((216, 84, 70), cx + 12, y - 29, 8, 9, OL)
        f((252, 140, 120), cx + 13, y - 28, 2, 7)
        self._blk(skin, cx - 8, y - 54, 16, 17, OL)
        f(skin2, cx + 4, y - 54, 4, 17)
        f((34, 26, 32), cx - 9, y - 57, 18, 7)
        f((34, 26, 32), cx - 9, y - 57, 3, 14)
        f((255, 255, 255), cx - 5, y - 47, 3, 3)
        f((255, 255, 255), cx + 2, y - 47, 3, 3)
        f((20, 18, 26), cx - 3, y - 46, 2, 2)
        f((20, 18, 26), cx + 4, y - 46, 2, 2)
        f((160, 80, 78), cx - 2, y - 41, 5, 1)

    def draw_scene1(self):
        cv, t = self.cv, self.t
        cv.blit(self._layer("s1", self._bg_room), (0, 0))
        # jarum jam: 08:00, jarum detik bergerak
        cx, cy = 524, 84

        def tip(deg, r):
            return (cx + math.sin(math.radians(deg)) * r, cy - math.cos(math.radians(deg)) * r)
        pygame.draw.line(cv, (44, 32, 32), (cx, cy), tip(240, 11), 3)
        pygame.draw.line(cv, (44, 32, 32), (cx, cy), tip(0, 17), 2)
        pygame.draw.line(cv, RED2, (cx, cy), tip((t * 6) % 360, 19), 1)
        self.circle((44, 32, 32), cx, cy, 2)
        if int(t * 1.4) % 2 == 0:                        # LED standby TV
            self.rectf((255, 60, 50), 570, 230, 3, 3)
        self._person(330, 236, 1 if math.sin(t * 1.8) > .55 else 0)
        # uap kopi
        for k in range(7):
            u = (t * 14 + k * 4.4) % 31
            a = int(150 * (1 - u / 31))
            self.rectf((255, 255, 255, a), 350 + 3 * math.sin(t * 2 + k * 1.3 + u * .15), 204 - u, 2, 3)
        # berkas cahaya matahari
        pulse = .10 + .025 * math.sin(t * 1.1)
        self.polygon(rgba(255, 226, 150, pulse), [(72, 70), (244, 70), (420, 334), (190, 334)])
        self.polygon(rgba(255, 236, 190, pulse * .6), [(110, 70), (170, 70), (300, 334), (250, 334)])
        for i in range(18):
            self._mote(i, t, 100, 80, 300, 250)
        self._intro_post()


    # ------------------------------------------------------------------
    # ADEGAN 2 - Siaran berita darurat di TV tabung
    # ------------------------------------------------------------------
    TVS = (84, 52, 400, 244)          # x, y, lebar, tinggi layar

    def _bg_tv(self):
        f, cv = self.rectf, self.cv
        sx, sy, sw, sh = self.TVS
        self._grad(0, 0, CW, CH, (20, 22, 36), (6, 6, 10), 8)
        for x in range(0, CW, 18):
            f((255, 255, 255, 5), x, 0, 8, CH)
        for infl, a in ((46, .03), (34, .04), (22, .05), (12, .06)):
            f(rgba(70, 120, 255, a), 60 - infl, 34 - infl, 520 + 2 * infl, 296 + 2 * infl)
        # badan TV
        pygame.draw.rect(cv, (14, 14, 18), (60, 34, 520, 298), 0, border_radius=16)
        pygame.draw.rect(cv, (36, 34, 42), (60, 34, 518, 294), 0, border_radius=16)
        pygame.draw.rect(cv, (56, 54, 66), (62, 36, 514, 3), 0)
        pygame.draw.rect(cv, (10, 10, 14), (74, 42, 420, 264), 0, border_radius=20)
        pygame.draw.rect(cv, (24, 24, 30), (74, 42, 420, 264), 2, border_radius=20)
        f((218, 190, 110), 252, 312, 64, 2)
        self.T("INDONESIA", 284, 312, (150, 126, 70), 1, "center")
        # panel kontrol
        f((22, 22, 28), 504, 52, 62, 244)
        for i in range(16):
            f((8, 8, 12), 512, 64 + i * 5, 46, 2)
            f((52, 52, 62), 512, 66 + i * 5, 46, 1)
        for ky in (176, 214):
            self.circle((12, 12, 16), 535, ky, 13)
            self.circle((78, 78, 90), 535, ky, 11)
            self.circle((104, 104, 118), 535, ky - 1, 8)
            pygame.draw.line(cv, (20, 20, 26), (535, ky), (535, ky - 9), 2)
        self.T("CH", 535, 236, (130, 130, 146), 1, "center")
        f((30, 30, 36), 520, 262, 30, 12)
        # ---- isi layar: studio berita (statis)
        cv.set_clip(pygame.Rect(sx, sy, sw, sh))
        self._grad(sx, sy, sw, sh, (30, 60, 128), (10, 20, 58), 10)
        f((90, 150, 230, 40), sx, sy, sw, 6)
        for i in range(0, sw, 20):
            f((255, 255, 255, 8), sx + i, sy, 1, sh)
        # video wall istana
        wx, wy, ww, wh = sx + 232, sy + 46, 148, 90
        f((190, 204, 232), wx - 3, wy - 3, ww + 6, wh + 6)
        self._grad(wx, wy, ww, wh - 14, (250, 176, 96), (124, 64, 120), 8)
        f((30, 20, 44), wx, wy + wh - 40, ww, 26)
        f((62, 40, 70), wx + 18, wy + wh - 52, ww - 36, 38)
        f((78, 52, 86), wx + 50, wy + wh - 62, ww - 100, 48)
        pygame.draw.circle(cv, (78, 52, 86), (wx + ww // 2, wy + wh - 62), 18)
        f((255, 205, 90), wx + ww // 2 - 1, wy + wh - 90, 2, 10)
        f((178, 32, 40), wx + ww // 2 + 1, wy + wh - 90, 9, 5)
        for i in range(6):
            f((110, 80, 114), wx + 24 + i * 20, wy + wh - 50, 4, 36)
        f((10, 14, 30), wx, wy + wh - 14, ww, 14)
        self.T("ISTANA NEGARA - LIVE", wx + ww // 2, wy + wh - 11, WHITE, 1, "center")
        # meja studio
        f((12, 18, 44), sx + 6, sy + 148, 260, 60)
        f((26, 36, 78), sx + 6, sy + 148, 260, 10)
        f((70, 200, 230), sx + 6, sy + 148, 260, 2)
        f((70, 200, 230, 80), sx + 6, sy + 158, 260, 1)
        self.T("KNN", sx + 136, sy + 160, WHITE, 3, "center", (10, 40, 90))
        cv.set_clip(None)

    def _tv_overlay(self):
        key = "tvov"
        if key not in self._ic:
            sx, sy, sw, sh = self.TVS
            scan = pygame.Surface((sw, sh), pygame.SRCALPHA)
            for y in range(0, sh, 2):
                scan.fill((0, 0, 0, 62), (0, y, sw, 1))
            mask = pygame.Surface((sw, sh), pygame.SRCALPHA)
            mask.fill((0, 0, 0, 255))
            pygame.draw.rect(mask, (0, 0, 0, 0), (0, 0, sw, sh), 0, border_radius=22)
            for d in range(0, 26, 2):
                pygame.draw.rect(scan, (0, 0, 0, int(80 * (1 - d / 26) ** 2)),
                                 (d, d, sw - 2 * d, sh - 2 * d), 2, border_radius=22)
            pygame.draw.polygon(scan, (255, 255, 255, 14), [(8, 8), (150, 8), (60, 120), (8, 150)])
            self._ic[key] = (scan, mask)
        return self._ic[key]

    def _anchor(self, ox, oy, talk, blink):
        f = self.rectf
        OL = (16, 20, 44)
        self._blk((28, 36, 84), ox - 42, oy + 24, 84, 40, OL)             # jas
        f((48, 62, 124), ox - 42, oy + 24, 84, 2)
        self.polygon((240, 242, 248), [(ox - 8, oy + 20), (ox + 8, oy + 20), (ox, oy + 44)])
        self.polygon((178, 32, 40), [(ox - 2, oy + 26), (ox + 2, oy + 26), (ox + 3, oy + 46), (ox, oy + 50), (ox - 3, oy + 46)])
        self.polygon((18, 24, 56), [(ox - 8, oy + 20), (ox - 22, oy + 28), (ox - 10, oy + 56), (ox - 3, oy + 40)])
        self.polygon((18, 24, 56), [(ox + 8, oy + 20), (ox + 22, oy + 28), (ox + 10, oy + 56), (ox + 3, oy + 40)])
        f((226, 190, 90), ox + 18, oy + 34, 3, 3)
        f((20, 20, 24), ox - 20, oy + 38, 4, 6)                          # mic
        self._blk((224, 172, 134), ox - 5, oy + 12, 10, 10, OL)          # leher
        self._blk((234, 182, 142), ox - 14, oy - 24, 28, 36, OL)         # kepala
        f((206, 152, 114), ox + 8, oy - 24, 6, 36)
        f((36, 30, 34), ox - 15, oy - 29, 30, 12)                        # rambut
        f((36, 30, 34), ox - 15, oy - 29, 4, 22)
        f((214, 160, 122), ox - 15, oy - 18, 3, 6)
        f((30, 24, 28), ox - 11, oy - 14, 6, 1)
        f((30, 24, 28), ox + 3, oy - 14, 6, 1)
        if not blink:
            f((255, 255, 255), ox - 11, oy - 11, 6, 3)
            f((255, 255, 255), ox + 3, oy - 11, 6, 3)
            f((24, 20, 30), ox - 9, oy - 11, 3, 3)
            f((24, 20, 30), ox + 5, oy - 11, 3, 3)
        else:
            f((30, 24, 28), ox - 11, oy - 10, 6, 1)
            f((30, 24, 28), ox + 3, oy - 10, 6, 1)
        f((206, 152, 114), ox - 1, oy - 8, 2, 7)
        if talk:
            f((96, 30, 40), ox - 4, oy + 1, 8, 4)
            f((244, 244, 244), ox - 4, oy + 1, 8, 1)
        else:
            f((160, 78, 80), ox - 4, oy + 3, 8, 1)

    def draw_scene2(self):
        cv, t = self.cv, self.t
        sx, sy, sw, sh = self.TVS
        cv.blit(self._layer("s2", self._bg_tv), (0, 0))
        talk = self.msg_idx < len(self.msg_full) and int(t * 9) % 2 == 0
        cv.set_clip(pygame.Rect(sx, sy, sw, sh))
        self._anchor(sx + 138, sy + 90, talk, (t % 3.4) < .12)
        # bilah merah/ungu berkedip di dinding video
        flash = int(t * 4) % 2 == 0
        # lower-third
        ly = sy + 184
        self.rectf((192, 40, 40) if flash else (240, 96, 40), sx, ly, 124, 26)
        self.rectf((255, 255, 255, 60), sx, ly, 124, 2)
        self.T("BREAKING", sx + 62, ly + 6, WHITE, 2, "center", (90, 10, 10))
        self.rectf((14, 24, 64), sx + 124, ly, sw - 124, 26)
        self.rectf((70, 200, 230), sx + 124, ly, sw - 124, 2)
        self.T("PRESIDEN MUNDUR!", sx + 134, ly + 6, WHITE, 2)
        # ticker
        ty = sy + 212
        self.rectf((240, 200, 44), sx, ty, sw, 32)
        self.rectf((255, 232, 120), sx, ty, sw, 2)
        msg = "KRISIS PEMERINTAHAN! PRESIDEN MUNDUR MENDADAK! NEGARA DALAM KEADAAN DARURAT!  ***  "
        mw = self.font.width(msg, 2)
        off = (t * 90) % mw
        for k in (0, 1):
            self.T(msg, sx - off + k * mw, ty + 9, (20, 14, 0), 2)
        # logo & LIVE
        self.rectf((255, 255, 255), sx + 10, sy + 10, 50, 20)
        self.rectf((200, 36, 40), sx + 12, sy + 12, 46, 16)
        self.T("KNN", sx + 35, sy + 15, WHITE, 2, "center")
        if int(t * 1.6) % 2 == 0:
            self.circle((255, 50, 50), sx + sw - 62, sy + 18, 4)
        self.T("LIVE", sx + sw - 54, sy + 14, WHITE, 2, "left", (10, 10, 30))
        self.T("08:00 WIB", sx + sw - 10, sy + 34, (200, 220, 255), 1, "right")
        # efek CRT: noise, pita bergulir, glitch
        for _ in range(60):
            nx, ny = sx + random.randrange(sw), sy + random.randrange(sh)
            p = cv.get_at((nx, ny))
            cv.set_at((nx, ny), (min(255, p[0] + 60), min(255, p[1] + 60), min(255, p[2] + 70)))
        by = sy + ((t * 55) % (sh + 40)) - 20
        self.rectf((255, 255, 255, 14), sx, by, sw, 12)
        if random.random() < .10:
            self.rectf((255, 255, 255, 36), sx, sy + random.randrange(sh - 6), sw, random.randint(1, 3))
        if random.random() < .06:
            self.rectf((120, 160, 255, 26), sx, sy, sw, sh)
        cv.set_clip(None)
        scan, mask = self._tv_overlay()
        cv.blit(scan, (sx, sy))
        cv.blit(mask, (sx, sy))
        if int(t * 1.2) % 2 == 0:                        # LED daya
            self.rectf((255, 60, 50), 531, 267, 8, 4)
        self._intro_post()


    # ------------------------------------------------------------------
    # ADEGAN 3 - Surat keputusan resmi di atas meja kayu
    # ------------------------------------------------------------------
    PAPER = (196, 34, 248, 300)       # x, y, lebar, tinggi kertas

    def _emblem(self, cx, cy):
        """Lambang negara: elang bersayap, perisai merah, bintang."""
        G, Gd, K = GOLD2, GOLD_D, (60, 38, 20)
        for side in (-1, 1):
            for i in range(5):
                y = cy - 10 + i * 5
                ln = 27 - i * 3
                col = G if i % 2 == 0 else (230, 196, 90)
                self.polygon(K, [(cx + side * 7, y - 1), (cx + side * (8 + ln), y - 4 + i * 2),
                                 (cx + side * (5 + ln), y + 5 + i), (cx + side * 7, y + 7)])
                self.polygon(col, [(cx + side * 7, y), (cx + side * (7 + ln), y - 3 + i * 2),
                                   (cx + side * (4 + ln), y + 4 + i), (cx + side * 7, y + 6)])
        self.polygon(K, [(cx - 12, cy - 12), (cx + 12, cy - 12), (cx + 12, cy + 4), (cx, cy + 18), (cx - 12, cy + 4)])
        self.polygon(G, [(cx - 11, cy - 11), (cx + 11, cy - 11), (cx + 11, cy + 3), (cx, cy + 16), (cx - 11, cy + 3)])
        self.polygon((176, 32, 38), [(cx - 8, cy - 8), (cx + 8, cy - 8), (cx + 8, cy + 2), (cx, cy + 12), (cx - 8, cy + 2)])
        star = []
        for k in range(10):
            a = math.radians(-90 + k * 36)
            r = 6 if k % 2 == 0 else 2.6
            star.append((cx + math.cos(a) * r, cy - 1 + math.sin(a) * r))
        self.polygon((246, 232, 190), star)
        self.circle(K, cx, cy - 17, 6)
        self.circle(G, cx, cy - 17, 5)
        self.polygon(Gd, [(cx - 2, cy - 17), (cx - 9, cy - 14), (cx - 2, cy - 13)])
        self.rectf(K, cx - 1, cy - 19, 2, 2)

    def _bg_desk(self):
        f, cv = self.rectf, self.cv
        rnd = random.Random(23)
        self._grad(0, 0, CW, CH, (96, 58, 38), (64, 38, 26), 8)
        for _ in range(170):                          # serat kayu
            x, y = rnd.randrange(-40, CW), rnd.randrange(CH)
            ln = rnd.randint(30, 140)
            f((40, 22, 14, 70) if rnd.random() < .6 else (140, 90, 58, 50), x, y, ln, 1)
        for x in (118, 438, 600):
            f((34, 20, 14), x, 0, 2, CH)
            f((130, 84, 56, 80), x + 2, 0, 1, CH)
        cv.blit(self._glow(300, (255, 210, 130), 130), (CW // 2 - 300, CH // 2 - 300))
        px, py, pw, ph = self.PAPER
        f((0, 0, 0, 80), px + 7, py + 8, pw, ph)       # bayangan kertas
        # ---- alat tulis (kiri)
        f((0, 0, 0, 70), 104, 262, 70, 10)
        self.circle((20, 24, 52), 140, 248, 17)
        self.circle((40, 52, 110), 140, 246, 15)
        self.circle((12, 14, 34), 140, 244, 9)
        self.polygon((255, 255, 255, 60), [(130, 236), (136, 234), (132, 244)])
        f((0, 0, 0, 60), 60, 302, 120, 6)
        pygame.draw.line(cv, (16, 16, 22), (62, 302), (164, 268), 6)
        pygame.draw.line(cv, (226, 190, 90), (150, 273), (156, 271), 6)
        pygame.draw.line(cv, (226, 190, 90), (102, 289), (104, 288), 6)
        pygame.draw.line(cv, (170, 170, 180), (166, 267), (176, 263), 2)
        # map merah di kanan
        f((0, 0, 0, 70), 468, 56, 150, 120)
        self._blk((172, 36, 40), 462, 48, 146, 116, (60, 14, 16))
        f((206, 60, 64), 462, 48, 146, 4)
        f((236, 232, 214), 484, 84, 102, 22)
        self.T("RAHASIA", 535, 90, (150, 24, 28), 2, "center")
        f((90, 20, 24), 466, 150, 138, 2)
        # cangkir kopi (tampak atas)
        f((0, 0, 0, 70), 506, 262, 60, 14)
        self.circle((236, 236, 240), 575, 252, 10, 4)
        self.circle((240, 240, 244), 534, 252, 28)
        self.circle((196, 196, 206), 534, 252, 28, 2)
        self.circle((84, 50, 32), 534, 252, 22)
        self.circle((120, 76, 48), 534, 254, 17)
        self.polygon((255, 255, 255, 70), [(518, 240), (528, 236), (522, 246)])
        # ---- kertas
        f((246, 236, 206), px, py, pw, ph)
        f((228, 212, 172), px, py + ph - 6, pw, 6)
        f((210, 190, 148), px, py, 2, ph)
        for y in range(py + 6, py + ph - 8, 3):
            f((200, 180, 140, 22), px + 3, y, pw - 6, 1)
        self.frame((122, 40, 40), (px + 10, py + 10, pw - 20, ph - 20), 2)
        self.frame(GOLD2, (px + 14, py + 14, pw - 28, ph - 28), 1)
        cx = px + pw // 2
        self._emblem(cx, py + 40)
        self.T("REPUBLIK INDONESIA", cx, py + 68, INK, 2, "center")
        self.T("KEPUTUSAN DARURAT NEGARA", cx, py + 88, (122, 40, 40), 1, "center")
        self.T("NOMOR 001/KD/DARURAT", cx, py + 98, INK2, 1, "center")
        f(INK, px + 26, py + 112, pw - 52, 2)
        f(INK, px + 26, py + 116, pw - 52, 1)

    def draw_scene3(self):
        cv, t = self.cv, self.scene_time
        px, py, pw, ph = self.PAPER
        cx = px + pw // 2
        cv.blit(self._layer("s3", self._bg_desk), (0, 0))
        lines = ("Menimbang: negara dalam keadaan", "darurat dan jabatan presiden kosong.",
                 "Mengingat: Undang-Undang Darurat", "Pasal 1, tentang pelantikan segera.")
        for i, s in enumerate(lines):
            if t > 0.5 + 0.45 * i:
                self.T(s, px + 28, py + 126 + i * 11, INK2, 1)
        if t > 2.4:
            self.T("MEMUTUSKAN:", cx, py + 176, INK, 2, "center")
        if t > 3.0:
            if not self._decree_hit:
                self._decree_hit = True
                self.shake = 1.4
                self.audio.play("boom")
            k = min(1.0, (t - 3.0) / 0.25)
            sc = 3
            self.T("ANDA ADALAH", cx, py + 198, RED, 2, "center")
            self.T("PRESIDEN!", cx + 2, py + 220 + 2, (90, 14, 10), sc, "center")
            self.T("PRESIDEN!", cx, py + 220, RED, sc, "center")
            if k < 1:
                self.rectf((255, 255, 255, int(150 * (1 - k))), px, py, pw, ph)
        # tanda tangan + segel lilin
        if t > 3.5:
            pts = [(px + 30, py + 258), (px + 38, py + 248), (px + 44, py + 262), (px + 52, py + 246),
                   (px + 58, py + 260), (px + 70, py + 252), (px + 84, py + 258), (px + 100, py + 250)]
            n = min(len(pts) - 1, int((t - 3.5) * 8))
            for i in range(n):
                pygame.draw.line(cv, (20, 24, 70), pts[i], pts[i + 1], 2)
            self.rectf(INK2, px + 24, py + 268, 90, 1)
            self.T("Ketua Dewan Darurat", px + 24, py + 272, INK2, 1)
        if t > 3.9:
            sx_, sy_ = px + pw - 46, py + 262
            k = min(1.0, (t - 3.9) / 0.2)
            r = int(14 + 5 * k)
            self.polygon((140, 24, 28), [(sx_ - 8, sy_ + 12), (sx_ - 16, sy_ + 36), (sx_ - 9, sy_ + 31), (sx_ - 4, sy_ + 38), (sx_ + 2, sy_ + 14)])
            self.polygon((170, 32, 38), [(sx_ + 8, sy_ + 12), (sx_ + 16, sy_ + 36), (sx_ + 9, sy_ + 31), (sx_ + 4, sy_ + 38), (sx_ - 2, sy_ + 14)])
            for a in range(0, 360, 45):
                self.circle((150, 26, 30), sx_ + math.cos(math.radians(a)) * (r - 3), sy_ + math.sin(math.radians(a)) * (r - 3), 5)
            self.circle((168, 36, 40), sx_, sy_, r - 2)
            self.circle((124, 20, 26), sx_, sy_, r - 6, 2)
            star = []
            for q in range(10):
                a = math.radians(-90 + q * 36)
                rr = 7 if q % 2 == 0 else 3
                star.append((sx_ + math.cos(a) * rr, sy_ + math.sin(a) * rr))
            self.polygon((230, 120, 110), star)
            self.rectf((255, 150, 140, 90), sx_ - 8, sy_ - 9, 6, 3)
        for i in range(14):
            self._mote(i, t, 150, 60, 340, 240)
        self._intro_post()


    # ------------------------------------------------------------------
    # ADEGAN 4 - Ruang kerja presiden
    # ------------------------------------------------------------------
    def _flag(self, px, side):
        """Tiang bendera emas + bendera merah berbintang yang menjuntai."""
        f = self.rectf
        f((150, 112, 40), px - 1, 46, 4, 160)
        f((236, 204, 100), px, 46, 1, 160)
        self.polygon((236, 204, 100), [(px + 1, 38), (px - 3, 48), (px + 5, 48)])
        x0 = px + 3 if side > 0 else px - 31
        f((176, 30, 38), x0, 56, 28, 78)
        for i in range(0, 28, 7):
            f((140, 20, 30) if (i // 7) % 2 == 0 else (196, 44, 52), x0 + i, 56, 4, 78)
        self.polygon((176, 30, 38), [(x0, 134), (x0 + 28, 134), (x0 + 24, 142), (x0 + 14, 136), (x0 + 4, 142)])
        f(GOLD2, x0, 56, 28, 2)
        self.circle(GOLD2, x0 + 14, 92, 9)
        self.circle((176, 30, 38), x0 + 14, 92, 7)
        star = []
        for k in range(10):
            a = math.radians(-90 + k * 36)
            r = 6 if k % 2 == 0 else 2.4
            star.append((x0 + 14 + math.cos(a) * r, 92 + math.sin(a) * r))
        self.polygon((248, 222, 120), star)

    def _bg_office(self):
        f, cv = self.rectf, self.cv
        rnd = random.Random(5)
        # dinding anggur dengan pola damask + lis emas
        self._grad(0, 0, CW, 206, (80, 24, 38), (120, 42, 54), 8)
        for y in range(6, 206, 14):
            for x in range(((y // 14) % 2) * 7, CW, 14):
                f((150, 62, 74), x, y, 2, 2)
                f((150, 62, 74), x - 1, y + 2, 1, 1)
                f((150, 62, 74), x + 2, y + 2, 1, 1)
        f((50, 30, 22), 0, 24, CW, 14)
        f(GOLD2, 0, 38, CW, 2)
        f(GOLD_D, 0, 40, CW, 2)
        f((88, 52, 36), 0, 206, CW, 34)
        f(GOLD2, 0, 204, CW, 2)
        for x in range(8, CW - 20, 52):
            self.frame((62, 36, 26), (x, 212, 44, 20), 1)
        # lantai kayu
        for r, y in enumerate(range(240, CH, 8)):
            x = -rnd.randint(0, 60)
            while x < CW:
                ln = rnd.randint(56, 110)
                v = rnd.randint(0, 3)
                f((88 + v * 7, 56 + v * 5, 38 + v * 3), x, y, ln, 7)
                f((52, 32, 24), x + ln - 1, y, 1, 7)
                x += ln
            f((50, 30, 22, 120), 0, y + 7, CW, 1)
        f((0, 0, 0, 60), 0, 240, CW, 8)
        # karpet merah
        self.polygon((196, 150, 70), [(206, 240), (434, 240), (540, 360), (100, 360)])
        self.polygon((134, 34, 46), [(214, 242), (426, 242), (524, 360), (116, 360)])
        self.polygon((156, 50, 62), [(232, 252), (408, 252), (490, 360), (150, 360)])
        # ---- jendela melengkung dengan senja di atas ibu kota
        wx, wy, ww = 252, 54, 136
        cxw = wx + ww // 2
        f((210, 194, 160), wx - 7, 118, ww + 14, 92)
        pygame.draw.circle(cv, (210, 194, 160), (cxw, 122), 75)
        cv.set_clip(pygame.Rect(wx, wy, ww, 148))
        self._grad(wx, wy, ww, 78, (52, 40, 104), (200, 86, 112), 8)
        self._grad(wx, wy + 78, ww, 70, (200, 86, 112), (255, 192, 106), 8)
        cv.blit(self._glow(70, (255, 190, 110), 170), (wx + 98 - 70, 184 - 70))
        self.circle((255, 232, 166), wx + 98, 184, 13)
        far, near = (92, 56, 100), (40, 28, 60)
        x = wx
        while x < wx + ww:
            bw, bh = rnd.randint(8, 16), rnd.randint(14, 34)
            f(far, x, 202 - bh, bw, bh)
            x += bw
        x = wx - 3
        while x < wx + ww:
            bw, bh = rnd.randint(10, 20), rnd.randint(10, 26)
            f(near, x, 202 - bh, bw, bh)
            for yy in range(202 - bh + 3, 200, 5):
                for xx in range(x + 2, x + bw - 2, 4):
                    if rnd.random() < .3:
                        f((255, 214, 130), xx, yy, 2, 2)
            x += bw + rnd.randint(0, 2)
        mx = wx + 40                                   # monumen ibu kota
        f(near, mx, 108, 6, 94)
        f(near, mx - 4, 168, 14, 34)
        f(near, mx - 8, 190, 22, 12)
        self.circle((255, 214, 100), mx + 3, 104, 4)
        cv.blit(self._glow(18, (255, 214, 100), 160), (mx + 3 - 18, 104 - 18))
        # mask lengkung: tutup sudut kaca di luar busur
        for y in range(wy, 122):
            hw = int(math.sqrt(max(0, 68 * 68 - (y - 122) ** 2)))
            f((210, 194, 160), wx, y, cxw - hw - wx, 1)
            f((210, 194, 160), cxw + hw, y, wx + ww - cxw - hw, 1)
        cv.set_clip(None)
        f((70, 46, 34), cxw - 2, wy, 4, 150)
        f((70, 46, 34), wx, 130, ww, 4)
        f((70, 46, 34), wx + 34, 80, 3, 122)
        f((70, 46, 34), wx + ww - 37, 80, 3, 122)
        for deg in range(180, 360, 3):
            a0, a1 = math.radians(deg), math.radians(deg + 3)
            pygame.draw.line(cv, (70, 46, 34), (cxw + math.cos(a0) * 68, 122 + math.sin(a0) * 68),
                             (cxw + math.cos(a1) * 68, 122 + math.sin(a1) * 68), 4)
        f((236, 222, 190), wx - 9, 206, ww + 18, 6)
        f((150, 126, 96), wx - 9, 211, ww + 18, 3)
        # ---- tiang bendera
        self._flag(222, 1)
        self._flag(418, -1)
        # ---- pilaster marmer
        for px_ in (166, 458):
            f((40, 24, 20), px_ - 4, 36, 36, 6)
            f(GOLD2, px_ - 4, 40, 36, 3)
            f((228, 216, 192), px_, 43, 28, 163)
            for k in range(4):
                f((196, 182, 156), px_ + 4 + k * 7, 43, 2, 163)
            f((250, 244, 228), px_, 43, 2, 163)
            f((140, 120, 96), px_ + 26, 43, 2, 163)
            f(GOLD2, px_ - 3, 202, 34, 4)
        # ---- rak buku
        for sx_ in (30, 500):
            f((0, 0, 0, 50), sx_ + 4, 70, 112, 170)
            f((56, 34, 26), sx_, 62, 112, 176)
            f((30, 18, 18), sx_ + 5, 67, 102, 166)
            for sh in range(4):
                by = 67 + sh * 42
                x = sx_ + 7
                while x < sx_ + 104:
                    bw, bh = rnd.randint(3, 6), rnd.randint(18, 34)
                    col = rnd.choice(((150, 40, 44), (44, 70, 120), (50, 110, 84), (196, 160, 80),
                                      (110, 70, 130), (170, 120, 70), (200, 200, 190)))
                    f(col, x, by + 38 - bh, bw, bh)
                    f((255, 255, 255, 40), x, by + 38 - bh, 1, bh)
                    x += bw + 1
                f((90, 58, 40), sx_ + 5, by + 38, 102, 4)
        # ---- kursi tinggi berlapis kulit
        f((60, 36, 28), 280, 184, 80, 66)
        f((74, 44, 32), 280, 182, 80, 4)
        f((118, 30, 44), 284, 190, 72, 58)
        f((150, 46, 60), 284, 190, 72, 4)
        for ty in range(200, 244, 12):
            for tx in range(298, 350, 14):
                f((210, 166, 76), tx, ty, 2, 2)
        f((60, 36, 28), 270, 224, 14, 26)
        f((60, 36, 28), 356, 224, 14, 26)
        f((86, 54, 38), 270, 222, 14, 4)
        f((86, 54, 38), 356, 222, 14, 4)
        # ---- meja kerja besar
        f((0, 0, 0, 70), 160, 316, 320, 10)
        self.polygon((176, 114, 70), [(184, 244), (456, 244), (474, 258), (166, 258)])
        f((214, 150, 96), 184, 244, 272, 2)
        f((96, 54, 36), 166, 258, 308, 62)
        f((72, 40, 28), 166, 316, 308, 4)
        for dx in (176, 282, 388):
            self.frame((62, 34, 24), (dx, 266, 86, 44), 2)
            f(GOLD2, dx + 41, 286, 4, 4)
        f(GOLD2, 166, 258, 308, 2)
        # papan nama
        f((0, 0, 0, 60), 296, 262, 56, 14)
        f(GOLD2, 292, 260, 56, 14)
        f((248, 222, 130), 292, 260, 56, 2)
        self.T("PRESIDEN", 320, 264, (70, 44, 14), 1, "center")
        # tumpukan dokumen & telepon
        f((236, 230, 210), 200, 238, 34, 6)
        f((220, 214, 190), 204, 234, 34, 5)
        f((176, 40, 44), 208, 230, 30, 5)
        f((30, 30, 36), 252, 237, 22, 7)
        f((60, 60, 70), 256, 234, 14, 4)
        # lampu meja hijau
        f((0, 0, 0, 60), 420, 246, 24, 5)
        f((40, 40, 46), 424, 242, 16, 4)
        f(GOLD2, 431, 220, 3, 22)
        self.polygon((30, 108, 72), [(420, 212), (446, 212), (452, 224), (414, 224)])
        f((70, 160, 112), 422, 212, 22, 2)
        f((255, 230, 150), 420, 224, 28, 2)

    def draw_scene4(self):
        cv, t = self.cv, self.t
        cv.blit(self._layer("s4", self._bg_office), (0, 0))
        # cahaya senja dari jendela
        pulse = .09 + .02 * math.sin(t * 1.0)
        self.polygon(rgba(255, 190, 110, pulse), [(262, 130), (378, 130), (500, 340), (140, 340)])
        self.polygon(rgba(255, 210, 140, pulse * .7), [(296, 130), (344, 130), (400, 340), (240, 340)])
        # cahaya lampu meja yang sedikit bergetar
        fl = 0.5 + 0.5 * math.sin(t * 3.3) * 0.3
        cv.blit(self._glow(46, (255, 220, 140), int(120 * fl + 40)), (432 - 46, 232 - 46))
        for i in range(16):
            self._mote(i, t, 230, 120, 190, 200, (255, 220, 160))
        self._intro_post()

    # ------------------------------------------------------------------
    # MENU UTAMA, PENGATURAN, JEDA
    # ------------------------------------------------------------------
    @staticmethod
    def _build_glow():
        radius = 230
        stops = [(0.0, (212, 175, 55, 0.25)), (0.5, (139, 0, 0, 0.15)), (1.0, (0, 0, 0, 0.0))]
        surf = pygame.Surface((2 * radius, 2 * radius), pygame.SRCALPHA)
        for r in range(radius, 0, -2):
            t = min(max((r - 10) / (radius - 10), 0.0), 1.0)
            for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
                if t0 <= t <= t1:
                    k = (t - t0) / (t1 - t0)
                    a0, a1 = c0[3], c1[3]
                    a = a0 + (a1 - a0) * k
                    if a > 0:
                        rgb = tuple(round((c0[i] * a0 + (c1[i] * a1 - c0[i] * a0) * k) / a) for i in range(3))
                    else:
                        rgb = (0, 0, 0)
                    pygame.draw.circle(surf, (*rgb, round(a * 255)), (radius, radius), r)
                    break
        return surf

    def draw_backdrop(self):
        cx = CW / 2
        self.rectf(NIGHT, 0, 0, CW, CH)
        pulse = math.sin(self.t * 2) * 20
        d = max(2, round(2 * (220 + pulse)))
        glow = pygame.transform.smoothscale(self.glow, (d, d))
        self.cv.blit(glow, (round(cx - d / 2), round(120 - d / 2)))
        self.circle(rgba(212, 175, 55, .15), cx, 100, 82, width=3)

    # ------------------------------------------------------------------
    # MENU UTAMA - latar Istana Kepresidenan (senja), judul, panel & tombol
    # ------------------------------------------------------------------
    MENU_SUBTITLE = "STRATEGI KEPEMIMPINAN NUSANTARA"   # ubah sesuka Anda
    PAL_CX = 425                                         # sumbu tengah istana (kanvas 640x360)

    ICONS = {
        "play": ["#......", "###....", "#####..", "#######", "#####..", "###....", "#......"],
        "gear": ["#..#..#", ".#####.", "..#.#..", "###.###", "..#.#..", ".#####.", "#..#..#"],
        "star": ["...#...", "...#...", "#######", ".#####.", "..###..", ".##.##.", ".#...#."],
        "exit": ["####...", "#..#.#.", "#..#..#", "#..####", "#..#..#", "#..#.#.", "####..."],
        "cup": ["#######", "#######", ".#####.", "..###..", "...#...", "..###..", ".#####."],
    }

    @staticmethod
    def _lerp(c0, c1, k):
        k = max(0.0, min(1.0, k))
        return tuple(int(c0[i] + (c1[i] - c0[i]) * k) for i in range(3))

    @staticmethod
    def _R(s, c, x, y, w, h):
        """Isi persegi pada surface s (mendukung warna RGBA)."""
        x, y, w, h = int(x), int(y), int(w), int(h)
        if w <= 0 or h <= 0:
            return
        if len(c) == 4 and c[3] < 255:
            t = pygame.Surface((w, h), pygame.SRCALPHA)
            t.fill(c)
            s.blit(t, (x, y))
        else:
            s.fill(c[:3], (x, y, w, h))

    def _build_menu_scene(self):
        """Gambar sekali: langit senja + Istana Kepresidenan + Monas. Dipakai ulang tiap frame."""
        R, lerp = self._R, self._lerp
        rnd = random.Random(2026)
        cx, HZ = self.PAL_CX, 262

        # ============================ LANGIT ============================
        sky = pygame.Surface((CW, CH)).convert()
        stops = [(0.0, (10, 9, 34)), (0.30, (40, 24, 82)), (0.58, (112, 44, 110)),
                 (0.80, (216, 96, 98)), (1.0, (255, 192, 116))]

        def skycol(t):
            for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
                if t <= t1:
                    return lerp(c0, c1, (t - t0) / (t1 - t0))
            return stops[-1][1]

        N = 24
        ys = [round(i * HZ / N) for i in range(N + 1)]
        cols = [skycol((i + .5) / N) for i in range(N)]
        for i in range(N):
            sky.fill(cols[i], (0, ys[i], CW, ys[i + 1] - ys[i]))
        sky.fill(cols[-1], (0, HZ, CW, CH - HZ))
        for i in range(1, N):                      # dither antar pita warna
            yb = ys[i]
            for x in range(CW):
                if (x + yb) % 2 == 0:
                    sky.set_at((x, yb - 1), cols[i])
                else:
                    sky.set_at((x, yb), cols[i - 1])
                if x % 4 == (yb % 2) * 2:
                    sky.set_at((x, yb - 2), cols[i])
                    sky.set_at((x, yb + 1), cols[i - 1])
        sky.blit(self._glow(170, (255, 150, 80), 150), (270 - 170, 256 - 170))
        sky.blit(self._glow(120, (255, 196, 120), 120), (cx - 120, 248 - 120))
        mx, my = 586, 52                            # bulan
        sky.blit(self._glow(46, (190, 200, 255), 110), (mx - 46, my - 46))
        pygame.draw.circle(sky, (232, 236, 250), (mx, my), 11)
        for (dx, dy, rr) in ((-3, -2, 3), (4, 3, 2), (2, -5, 1)):
            pygame.draw.circle(sky, (204, 210, 236), (mx + dx, my + dy), rr)
        stars = [(rnd.randrange(CW), rnd.randrange(4, 150), rnd.random() * 6.3,
                  1 if rnd.random() < .8 else 2) for _ in range(80)]

        def make_cloud(w, h, hi, lo, seed):
            r = random.Random(seed)
            s = pygame.Surface((w, h), pygame.SRCALPHA)
            n = max(5, w // 9)
            blobs = []
            for i in range(n):
                k = math.sin(math.pi * (i + .5) / n)           # tengah lebih tinggi
                br = max(3, int((h // 2 - 3) * (0.45 + 0.55 * k)) + r.randint(-1, 1))
                blobs.append((int(w * (i + .5) / n), h - 5 - br - r.randint(0, 1), br))
            for bx, by, br in blobs:
                pygame.draw.circle(s, (*lo, 225), (bx, by), br)
            s.fill((*lo, 225), (int(w * .04), h - 11, int(w * .92), 6))
            for bx, by, br in blobs:
                pygame.draw.circle(s, (*hi, 225), (bx - 1, by - 3), max(2, br - 3))
            s.fill((*hi, 225), (int(w * .08), h - 12, int(w * .8), 3))
            s.fill((0, 0, 0, 0), (0, h - 5, w, 5))
            return s

        specs = [(30, 84, 26, 3.0, 40, (92, 66, 138), (60, 40, 104)),
                 (58, 120, 30, 4.5, 330, (130, 80, 150), (92, 56, 124)),
                 (104, 96, 24, 6.0, 180, (190, 100, 130), (140, 70, 116)),
                 (140, 150, 30, 7.5, 520, (240, 130, 112), (190, 90, 104)),
                 (190, 130, 26, 5.0, 60, (255, 170, 120), (224, 116, 104)),
                 (220, 170, 26, 9.0, 400, (255, 196, 130), (236, 140, 110))]
        clouds = [dict(y=y, w=w, spd=spd, x0=x0, img=make_cloud(w, h, hi, lo, 10 + i))
                  for i, (y, w, h, spd, x0, hi, lo) in enumerate(specs)]

        # ============================ LAPISAN DEPAN ============================
        fg = pygame.Surface((CW, CH), pygame.SRCALPHA)

        # --- siluet kota jauh
        far = (70, 46, 104)
        x = -4
        while x < CW:
            bw, bh = rnd.randint(9, 19), rnd.randint(12, 44)
            R(fg, far, x, 258 - bh, bw, bh)
            if rnd.random() < .25:
                R(fg, far, x + bw // 2, 258 - bh - 5, 1, 5)
            for yy in range(258 - bh + 3, 254, 5):
                for xx in range(x + 2, x + bw - 2, 4):
                    if rnd.random() < .22:
                        R(fg, (255, 176, 110), xx, yy, 1, 2)
            x += bw + rnd.randint(0, 3)

        # --- Monas (tugu nasional) di kejauhan
        mc, mxp = (96, 66, 116), 598
        R(fg, mc, mxp - 14, 240, 28, 14)
        R(fg, mc, mxp - 10, 236, 20, 4)
        pygame.draw.polygon(fg, mc, [(mxp - 3, 236), (mxp + 3, 236), (mxp + 1, 152), (mxp - 1, 152)])
        R(fg, mc, mxp - 8, 178, 16, 5)
        R(fg, mc, mxp - 6, 183, 12, 2)
        R(fg, mc, mxp - 3, 146, 6, 6)
        pygame.draw.line(fg, (214, 134, 112), (mxp - 3, 236), (mxp - 1, 152))

        # --- barisan pohon di belakang
        tl, tl2 = (16, 36, 50), (26, 58, 66)
        R(fg, tl, 0, 246, CW, 20)
        crowns = [(x, 246 - rnd.randint(0, 8), rnd.randint(9, 15)) for x in range(-8, CW + 8, 8)]
        for x, cy, rr in crowns:
            pygame.draw.circle(fg, tl, (x, cy), rr)
        for x, cy, rr in crowns:
            pygame.draw.circle(fg, tl2, (x - 3, cy - 4), max(3, rr // 2))

        # --- halaman rumput bergaris
        GR = 258
        M = 10
        for i in range(M):
            y0 = GR + round(i * (CH - GR) / M)
            y1 = GR + round((i + 1) * (CH - GR) / M)
            R(fg, lerp((38, 88, 66), (12, 36, 38), (i + .5) / M), 0, y0, CW, y1 - y0)
        stripes = pygame.Surface((CW, CH), pygame.SRCALPHA)
        for k in range(-18, 18, 2):
            pygame.draw.polygon(stripes, (255, 255, 255, 9),
                                [(cx + k * 6, 270), (cx + (k + 1) * 6, 270),
                                 (cx + (k + 1) * 40, CH), (cx + k * 40, CH)])
        fg.blit(stripes, (0, 0))
        # teras batu di depan istana
        pygame.draw.polygon(fg, (128, 124, 148), [(cx - 150, 266), (cx + 150, 266), (cx + 176, 282), (cx - 176, 282)])
        pygame.draw.line(fg, (178, 174, 196), (cx - 176, 282), (cx + 176, 282))
        pygame.draw.line(fg, (160, 156, 178), (cx - 150, 266), (cx - 176, 282))
        pygame.draw.line(fg, (160, 156, 178), (cx + 150, 266), (cx + 176, 282))

        # ============================ ISTANA ============================
        W_, WL, WS, WD, OUT = (238, 236, 230), (252, 248, 238), (196, 200, 216), (150, 154, 182), (84, 86, 122)
        ROOF, ROOFL = (66, 72, 102), (96, 102, 136)
        wins = []

        def win(x, y, w, h, frame=WL):
            R(fg, frame, x - 2, y - 3, w + 4, 3)
            R(fg, WS, x - 1, y - 1, w + 2, h + 2)
            R(fg, (26, 32, 58), x, y, w, h)
            R(fg, frame, x + w // 2, y, 1, h)
            R(fg, frame, x, y + h // 2, w, 1)
            R(fg, frame, x - 2, y + h + 1, w + 4, 2)
            R(fg, WD, x - 2, y + h + 3, w + 4, 1)
            wins.append((x, y, w, h, rnd.random() * 6.28, rnd.random() < .7))

        # --- sayap kiri & kanan
        for side in (-1, 1):
            x0 = cx - 126 if side < 0 else cx + 50
            w = 76
            R(fg, ROOF, x0 + 6, 182, w - 12, 12)
            R(fg, ROOFL, x0 + 6, 182, w - 12, 2)
            chx = x0 + 14 if side < 0 else x0 + w - 20
            R(fg, (140, 84, 76), chx, 172, 6, 12)
            R(fg, (190, 130, 110), chx, 172, 2, 12)
            R(fg, WL, chx - 1, 171, 8, 2)
            R(fg, OUT, x0 - 1, 190, w + 2, 78)
            R(fg, WL, x0, 191, w, 2)                                   # balustrade
            for bx in range(x0 + 1, x0 + w - 1, 4):
                R(fg, W_, bx, 193, 2, 6)
                R(fg, WS, bx + 1, 193, 1, 6)
            R(fg, WL, x0, 199, w, 1)
            R(fg, WL, x0 - 1, 200, w + 2, 2)                           # lis atap
            R(fg, W_, x0, 202, w, 2)
            for dx in range(x0 + 1, x0 + w - 1, 3):
                R(fg, WS, dx, 204, 2, 2)
            R(fg, WD, x0, 206, w, 1)
            R(fg, WS, x0, 207, w, 2)
            R(fg, W_, x0, 206, w, 60)                                  # dinding
            R(fg, WL, x0, 209, 1, 57)
            R(fg, WS, x0 + w - 2, 209, 2, 57)
            R(fg, WS, x0, 234, w, 1)
            R(fg, WL, x0, 235, w, 1)
            for yy in range(244, 266, 4):
                R(fg, (218, 216, 214), x0, yy, w, 1)
            for i, yy in enumerate(range(209, 266, 6)):                # batu sudut
                qw = 5 if i % 2 == 0 else 3
                qx = x0 if side < 0 else x0 + w - qw
                R(fg, (244, 242, 236), qx, yy, qw, 3)
                R(fg, WS, qx, yy + 3, qw, 1)
            for off in (6, 24, 42, 60):
                win(x0 + off, 213, 8, 16)
                win(x0 + off, 242, 8, 16)
            R(fg, (176, 176, 196), x0 - 1, 264, w + 2, 4)              # alas
            R(fg, WL, x0 - 1, 264, w + 2, 1)

        # --- blok tengah + portico
        bx0 = cx - 56
        R(fg, OUT, bx0 - 1, 180, 114, 88)
        R(fg, W_, bx0, 182, 112, 84)
        R(fg, WL, bx0, 182, 1, 84)
        R(fg, WS, bx0 + 110, 182, 2, 84)
        R(fg, WS, cx - 48, 192, 96, 66)                                # dinding cekung
        R(fg, (172, 176, 200), cx - 48, 192, 96, 6)
        for o in (-35, -17, 17, 35):
            win(cx + o - 3, 204, 6, 14)
            win(cx + o - 3, 230, 6, 16)
        R(fg, OUT, cx - 6, 220, 12, 38)                                # pintu utama
        R(fg, (40, 26, 22), cx - 5, 221, 10, 37)
        for o in (-44, -26, -8, 8, 26, 44):                            # tiang
            x = cx + o - 3
            R(fg, (120, 124, 160, 110), x + 6, 195, 4, 60)
            R(fg, W_, x, 195, 6, 59)
            R(fg, WL, x + 1, 195, 1, 59)
            R(fg, (226, 224, 220), x + 3, 195, 1, 59)
            R(fg, WS, x + 4, 195, 1, 59)
            R(fg, WD, x + 5, 195, 1, 59)
            R(fg, WL, x - 1, 192, 8, 3)
            R(fg, WS, x - 1, 194, 8, 1)
            R(fg, WL, x - 1, 254, 8, 3)
            R(fg, WS, x - 1, 256, 8, 1)
        R(fg, WL, cx - 54, 182, 108, 2)                                # entablatur
        R(fg, W_, cx - 54, 184, 108, 6)
        for x in range(cx - 52, cx + 52, 6):
            R(fg, WS, x, 185, 2, 4)
        R(fg, WS, cx - 54, 190, 108, 2)
        R(fg, WD, cx - 48, 192, 96, 1)
        pygame.draw.polygon(fg, OUT, [(cx - 62, 183), (cx, 148), (cx + 62, 183)])      # pedimen
        pygame.draw.polygon(fg, W_, [(cx - 60, 182), (cx, 150), (cx + 60, 182)])
        pygame.draw.polygon(fg, WS, [(cx - 50, 180), (cx, 156), (cx + 50, 180)])
        pygame.draw.line(fg, WL, (cx - 60, 182), (cx, 150))
        pygame.draw.line(fg, WD, (cx + 60, 182), (cx, 150))
        pygame.draw.circle(fg, GOLD2, (cx, 170), 5)                    # lambang bulat
        pygame.draw.circle(fg, (26, 32, 58), (cx, 170), 3)
        R(fg, (74, 70, 78), cx, 88, 2, 62)                             # tiang bendera
        R(fg, GOLD, cx - 1, 85, 4, 4)
        for i, (sw, sy, sh) in enumerate(((120, 257, 3), (130, 260, 3), (140, 263, 3))):   # tangga
            R(fg, (176, 180, 200), cx - sw // 2, sy, sw, sh)
            R(fg, WL, cx - sw // 2, sy, sw, 1)
            R(fg, (124, 128, 160), cx - sw // 2, sy + sh - 1, sw, 1)
        pygame.draw.polygon(fg, (158, 34, 46), [(cx - 5, 258), (cx + 5, 258), (cx + 10, 284), (cx - 10, 284)])   # karpet merah
        pygame.draw.line(fg, (222, 176, 72), (cx - 5, 258), (cx - 10, 284))
        pygame.draw.line(fg, (222, 176, 72), (cx + 5, 258), (cx + 10, 284))

        # --- jalan masuk, air mancur, semak, bunga
        pygame.draw.polygon(fg, (156, 142, 134), [(cx - 18, 282), (cx + 18, 282), (cx - 74, CH), (cx + 74, CH)])
        pygame.draw.line(fg, (206, 192, 176), (cx - 18, 282), (cx - 74, CH))
        pygame.draw.line(fg, (206, 192, 176), (cx + 18, 282), (cx + 74, CH))
        for _ in range(90):
            yy = rnd.randint(284, CH - 1)
            hw = 18 + (yy - 282) * 0.72
            R(fg, (176 + rnd.randint(-14, 14), 162, 150), cx + rnd.uniform(-hw + 3, hw - 3), yy, 1, 1)
        fcy = 308
        pygame.draw.ellipse(fg, (222, 218, 212), (cx - 26, fcy - 8, 52, 17))
        pygame.draw.ellipse(fg, (150, 146, 158), (cx - 26, fcy - 6, 52, 15), 1)
        pygame.draw.ellipse(fg, (70, 136, 190), (cx - 22, fcy - 6, 44, 11))
        pygame.draw.ellipse(fg, (110, 176, 220), (cx - 16, fcy - 5, 22, 5))
        R(fg, WS, cx - 2, fcy - 20, 4, 15)
        R(fg, W_, cx - 7, fcy - 21, 14, 3)
        R(fg, WL, cx - 7, fcy - 21, 14, 1)
        for yy in (288, 304, 322):
            hw = 18 + (yy - 282) * 0.72
            bw = 12 + (yy - 282) // 4
            for sg in (-1, 1):
                hx = cx + sg * (hw + 8) - bw // 2
                R(fg, (16, 62, 48), hx, yy - 7, bw, 8)
                R(fg, (16, 62, 48), hx + 2, yy - 9, bw - 4, 2)
                R(fg, (44, 116, 76), hx + 2, yy - 9, bw - 4, 1)
                R(fg, (30, 92, 62), hx + 1, yy - 7, bw - 2, 2)
                R(fg, (8, 36, 34), hx, yy, bw, 1)
                for k in range(0, bw - 2, 3):
                    R(fg, (210, 44, 52) if (k // 3 + sg) % 2 else (244, 244, 244), hx + 1 + k, yy - 5, 1, 1)
        for _ in range(46):
            fx, fy = rnd.randint(0, CW - 1), rnd.randint(290, 326)
            if abs(fx - cx) < 20 + (fy - 282) * 0.8 or (fx < 256 and fy > 120):
                continue
            R(fg, (210, 44, 52) if rnd.random() < .5 else (240, 240, 244), fx, fy, 1, 1)

        # --- pohon-pohon sisi
        def tree(x, base, h, r):
            R(fg, (44, 28, 30), x - 2, base - int(h * .45), 4, int(h * .45))
            parts = [(0, -.72, r), (-.7, -.52, .8 * r), (.7, -.52, .8 * r), (0, -.44, .9 * r)]
            for dx, dy, rr in parts:
                pygame.draw.circle(fg, (14, 46, 46), (int(x + dx * r), int(base + dy * h)), int(rr))
            for dx, dy, rr in parts:
                pygame.draw.circle(fg, (28, 80, 62), (int(x + dx * r - 3), int(base + dy * h - 3)), max(2, int(rr * .55)))
            pygame.draw.circle(fg, (50, 116, 78), (int(x - 4), int(base - .8 * h)), max(2, int(r * .25)))

        for tx, tb, th, tr in ((254, 272, 58, 16), (284, 274, 40, 12), (566, 272, 50, 14),
                               (606, 278, 64, 18), (634, 276, 52, 15)):
            tree(tx, tb, th, tr)

        # --- pagar besi + gerbang + trotoar
        iron, ironh = (14, 14, 24), (56, 56, 80)
        gx0, gx1 = cx - 44, cx + 44
        R(fg, iron, 0, 334, gx0, 2)
        R(fg, iron, 0, 346, gx0, 2)
        R(fg, iron, gx1, 334, CW - gx1, 2)
        R(fg, iron, gx1, 346, CW - gx1, 2)
        for x in range(0, CW, 6):
            if gx0 - 2 < x < gx1 + 2:
                continue
            R(fg, iron, x, 330, 2, 22)
            R(fg, ironh, x, 331, 1, 20)
            R(fg, (150, 120, 60), x, 328, 2, 2)
        R(fg, (70, 66, 90), 0, 352, CW, 8)
        R(fg, (116, 112, 134), 0, 352, CW, 1)
        lamps = []
        for px in (gx0 - 8, gx1):
            R(fg, OUT, px - 1, 314, 10, 38)
            R(fg, (176, 178, 198), px, 316, 8, 36)
            R(fg, WL, px, 316, 1, 36)
            R(fg, WS, px + 6, 316, 2, 36)
            R(fg, WL, px - 1, 312, 10, 3)
            R(fg, (60, 56, 70), px + 1, 304, 6, 8)
            R(fg, (255, 226, 150), px + 2, 305, 4, 6)
            R(fg, GOLD2, px + 2, 302, 4, 2)
            lamps.append((px + 4, 308))

        # --- vinyet gelap (tepi atas / bawah / kiri-panel / kanan)
        vig = pygame.Surface((CW, CH), pygame.SRCALPHA)

        def layer(fn):
            lay = pygame.Surface((CW, CH), pygame.SRCALPHA)
            fn(lay)
            vig.blit(lay, (0, 0))

        def v_top(L):
            for y in range(0, 120, 2):
                L.fill((4, 2, 18, int(96 * (1 - y / 120) ** 1.6)), (0, y, CW, 2))

        def v_bot(L):
            for y in range(CH - 30, CH, 2):
                L.fill((4, 2, 12, int(110 * ((y - (CH - 30)) / 30) ** 1.5)), (0, y, CW, 2))

        def v_left(L):
            for x in range(0, 280, 2):
                L.fill((4, 4, 16, int(84 * (1 - x / 280) ** 1.5)), (x, 0, 2, CH))

        def v_right(L):
            for x in range(CW - 70, CW, 2):
                L.fill((4, 2, 14, int(60 * ((x - (CW - 70)) / 70) ** 1.5)), (x, 0, 2, CH))
        for fn in (v_top, v_bot, v_left, v_right):
            layer(fn)

        return dict(sky=sky, fg=fg, vig=vig, stars=stars, clouds=clouds, wins=wins, lamps=lamps,
                    flag=(cx + 2, 90), fountain=(cx, fcy - 19), monas=(mxp, 142), door=(cx - 5, 221, 10, 37),
                    lunette=(cx, 170))

    def draw_menu_backdrop(self, door_open=0.0):
        """Latar menu: senja di depan Istana Kepresidenan, lengkap dengan animasinya."""
        m = getattr(self, "_mn", None)
        if m is None:
            m = self._mn = self._build_menu_scene()
        cv, t, R = self.cv, self.t, self._R
        cv.blit(m["sky"], (0, 0))
        for x, y, ph, sz in m["stars"]:                               # bintang berkedip
            v = 110 + int(130 * (0.5 + 0.5 * math.sin(t * 1.6 + ph)))
            cv.fill((v, v, min(255, v + 25)), (x, y, sz, sz))
        for c in m["clouds"]:                                         # awan melayang
            span = CW + c["w"]
            x = (c["x0"] - t * c["spd"]) % span - c["w"]
            cv.blit(c["img"], (int(x), c["y"]))
        for i in range(3):                                            # burung
            bx = (t * (20 + i * 4) + i * 120) % (CW + 40) - 20
            by = 96 + i * 22 + math.sin(t * 1.3 + i) * 4
            flap = int(t * 6 + i * 2) % 2
            pts = ((-3, -1), (-2, 0), (-1, 1), (0, 1), (1, 1), (2, 0), (3, -1)) if flap else \
                  ((-3, 1), (-2, 0), (-1, 0), (0, 1), (1, 0), (2, 0), (3, 1))
            for dx, dy in pts:
                cv.fill((24, 14, 44), (int(bx) + dx, int(by) + dy, 1, 1))
        cv.blit(m["fg"], (0, 0))

        # nyala Monas
        fx, fy = m["monas"]
        fl = 0.8 + 0.2 * math.sin(t * 7.0) + 0.08 * math.sin(t * 13.0)
        cv.blit(self._glow(18, (255, 200, 90), int(190 * fl)), (fx - 18, fy - 18))
        R(cv, (255, 214, 90), fx - 1, 138, 3, 6)
        R(cv, (255, 250, 200), fx, 139, 1, 3)

        # bendera Merah Putih
        flx, fly = m["flag"]
        for col in range(32):
            ph = t * 5 - col * 0.45
            off = int(round(math.sin(ph) * (col / 32) * 3))
            dark = math.cos(ph) < -0.3
            R(cv, (150, 20, 32) if dark else (206, 32, 44), flx + col, fly + off, 1, 10)
            R(cv, (200, 198, 210) if dark else (248, 244, 238), flx + col, fly + 10 + off, 1, 10)

        # jendela menyala (berkedip halus)
        for x, y, w, h, ph, lit in m["wins"]:
            if not lit:
                continue
            a = 0.86 + 0.14 * math.sin(t * (1.0 + ph % 3) + ph * 5)
            R(cv, (255, 200, 110, 34), x - 2, y - 2, w + 4, h + 4)
            R(cv, (255, int(150 + 60 * a), int(70 + 50 * a)), x, y, w, h)
            R(cv, (126, 86, 54), x + w // 2, y, 1, h)
            R(cv, (126, 86, 54), x, y + h // 2, w, 1)
        lx, ly = m["lunette"]
        pygame.draw.circle(cv, (255, int(196 + 24 * math.sin(t * 2)), 110), (lx, ly), 3)
        dx, dy, dw, dh = m["door"]                                    # pintu utama (daun kayu)
        gap = int(round(dw * door_open))
        lw = (dw - gap) // 2
        if gap > 0:                                                   # cahaya dari dalam aula
            for i in range(4):
                R(cv, self._lerp((255, 252, 236), (255, 214, 130), i / 3), dx + lw, dy + 1 + i * 9, gap, 9)
        for lx0 in (dx, dx + dw - lw):
            if lw > 0:
                R(cv, (98, 58, 34), lx0, dy + 1, lw, dh - 1)
                R(cv, (62, 34, 24), lx0 + 1, dy + 5, max(0, lw - 2), 12)
                R(cv, (62, 34, 24), lx0 + 1, dy + 21, max(0, lw - 2), 13)
                R(cv, (146, 92, 52), lx0, dy + 1, 1, dh - 1)
        if gap == 0:
            R(cv, (30, 16, 12), dx + dw // 2, dy + 1, 1, dh - 1)
            R(cv, (236, 194, 84), dx + dw // 2 - 2, dy + 20, 1, 3)
            R(cv, (236, 194, 84), dx + dw // 2 + 1, dy + 20, 1, 3)
        if door_open > 0:
            rr = 6 * int((20 + 70 * door_open) // 6)
            cv.blit(self._glow(rr, (255, 232, 170), int(230 * door_open)), (dx + dw // 2 - rr, dy + dh // 2 - rr))
            k = door_open
            self.polygon((255, 236, 170, int(96 * k)),
                         [(dx + lw, dy + dh), (dx + lw + gap, dy + dh), (dx + dw + 16 * k, 284), (dx - 16 * k, 284)])

        # air mancur
        ax, ay = m["fountain"]
        for i in range(10):
            u = ((t * 1.4 + i / 10) % 1.0) * 0.9
            px = ax + (i - 4.5) * 5 * u
            py = ay - 26 * u + 30 * u * u
            R(cv, (196, 232, 255), px, py, 1, 1)
        for k in range(3):
            sx = ax - 14 + ((int(t * 3) * 7 + k * 11) % 28)
            R(cv, (226, 246, 255), sx, ay + 15 + (k % 2), 1, 1)

        # lampu gerbang
        for lx, ly in m["lamps"]:
            r = 18 + 2 * int(1.5 + 1.5 * math.sin(t * 2 + lx))
            cv.blit(self._glow(r, (255, 210, 120), 150), (lx - r, ly - r))
        cv.blit(m["vig"], (0, 0))

    # ------------------------------------------------------------------
    # Judul 3D berkilau, ornamen, panel & tombol bergaya pixel
    # ------------------------------------------------------------------
    def _title_word(self, s, cx, y, scale=4):
        cv, f, t = self.cv, self.font, self.t
        w = f.width(s, scale)
        x = int(cx - w / 2)
        ol = f.render(s, scale, (22, 6, 20))
        for ex, ey in ((x, y), (x + 3, y + 3)):                        # kontur gelap
            for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2), (-2, -2), (2, -2), (-2, 2), (2, 2)):
                cv.blit(ol, (ex + dx, ey + dy))
        side = f.render(s, scale, (150, 62, 14))                        # sisi tebal (3D)
        for i in (3, 2, 1):
            cv.blit(side, (x + i, y + i))
        for r0, r1, col in ((0, 11, (255, 244, 170)), (11, 21, GOLD), (21, 40, AMBER)):
            cv.set_clip(pygame.Rect(0, y + r0, CW, r1 - r0))
            cv.blit(f.render(s, scale, col), (x, y))
        cv.set_clip(None)
        band = int((t * 90 + y * 3) % (w + 140)) - 70                   # kilau berjalan
        cv.set_clip(pygame.Rect(x + band, y, 9, 7 * scale))
        cv.blit(f.render(s, scale, (255, 255, 255)), (x, y))
        cv.set_clip(None)

    def _ornament(self, cx, y, half=110):
        R = self._R
        cv = self.cv
        for sg in (-1, 1):
            x = cx + sg * 14 if sg > 0 else cx - 14 - (half - 14)
            R(cv, GOLD2, x, y, half - 14, 1)
            R(cv, GOLD_D, x, y + 1, half - 14, 1)
        R(cv, GOLD, cx, y - 3, 1, 7)
        R(cv, GOLD, cx - 3, y, 7, 1)
        R(cv, GOLD2, cx - 1, y - 1, 3, 3)
        R(cv, (255, 244, 170), cx, y, 1, 1)

    def draw_title(self, y=16):
        cx = CW / 2
        self._title_word("SUDDENLY", cx, y)
        self._title_word("A PRESIDENT", cx, y + 34)
        self._ornament(int(cx), y + 72)
        self.T(self.MENU_SUBTITLE, cx, y + 80, CREAMT, 1, "center", (10, 4, 16))

    def _icon(self, name, x, y, color):
        for ry, row in enumerate(self.ICONS.get(name, ())):
            for rx, ch in enumerate(row):
                if ch == "#":
                    self.cv.fill(color, (x + rx, y + ry, 1, 1))

    def draw_panel_frame(self, rect, title=None, tscale=1, alpha=228):
        R, cv = self._R, self.cv
        r = pygame.Rect(rect)
        R(cv, (0, 0, 0, 120), r.x + 3, r.y + 4, r.w, r.h)
        R(cv, (10, 8, 22, alpha), r.x, r.y, r.w, r.h)
        R(cv, (70, 44, 100, 46), r.x + 2, r.y + 2, r.w - 4, 16)
        self.frame((6, 4, 10), r.inflate(4, 4), 1)
        self.frame(GOLD2, r, 1)
        self.frame((138, 109, 59, 150), r.inflate(-6, -6), 1)
        for qx, qy in ((r.x - 2, r.y - 2), (r.right - 3, r.y - 2), (r.x - 2, r.bottom - 3), (r.right - 3, r.bottom - 3)):
            R(cv, GOLD2, qx, qy, 5, 5)
            R(cv, (10, 8, 22), qx + 1, qy + 1, 3, 3)
            R(cv, GOLD, qx + 2, qy + 2, 1, 1)
        if title:
            tw = self.font.width(title, tscale) + 34
            rh = 7 * tscale + 6
            rx, ry = r.centerx - tw // 2, r.y - rh // 2 - 1
            R(cv, (8, 4, 10), rx - 1, ry - 1, tw + 2, rh + 2)
            R(cv, (110, 24, 34), rx, ry, tw, rh)
            R(cv, (156, 44, 52), rx, ry + 1, tw, rh // 3)
            R(cv, GOLD2, rx, ry, tw, 1)
            R(cv, GOLD2, rx, ry + rh - 1, tw, 1)
            R(cv, GOLD, rx + 3, ry + rh // 2, 2, 2)
            R(cv, GOLD, rx + tw - 5, ry + rh // 2, 2, 2)
            self.T(title, r.centerx, ry + (rh - 7 * tscale) // 2, GOLD, tscale, "center", (40, 6, 12))

    def menu_button(self, bid, rect, label, enabled=True, scale=2, style="normal", icon=None, led=None):
        """Tombol menu bergaya pixel: bevel, bayangan, kilau saat hover, ikon & lampu status."""
        r = pygame.Rect(rect)
        hover = enabled and r.collidepoint(self.mpos)
        if hover:
            self._hov_now = bid
        pal = {"normal": ((78, 58, 36), (44, 32, 22), (176, 138, 74), (232, 216, 176)),
               "primary": ((176, 42, 42), (106, 18, 32), (255, 214, 110), (255, 240, 190)),
               "danger": ((122, 42, 38), (68, 20, 22), (204, 120, 90), (246, 208, 192)),
               "go": ((38, 104, 64), (20, 58, 38), (130, 220, 150), (214, 246, 222))}
        top, bot, edge, fg = pal.get(style, pal["normal"])
        if not enabled:
            top, bot, edge, fg = (46, 42, 38), (30, 28, 26), (84, 76, 62), (120, 110, 94)
        elif hover:
            top, bot = self._lerp(top, (255, 220, 140), .30), self._lerp(bot, (255, 190, 90), .22)
            edge, fg = GOLD, (255, 244, 190)
        y = r.y - (1 if hover else 0)
        x, w, h = r.x, r.w, r.h
        R, cv = self._R, self.cv
        R(cv, (0, 0, 0, 110), x + 1, r.y + 2, w, h)                      # bayangan
        if hover:
            R(cv, (255, 210, 90, 70), x - 2, y - 2, w + 4, h + 4)
        R(cv, (10, 6, 8), x + 1, y, w - 2, h)                            # sudut terpotong 1px
        R(cv, (10, 6, 8), x, y + 1, w, h - 2)
        R(cv, edge, x + 1, y + 1, w - 2, h - 2)
        R(cv, top, x + 2, y + 2, w - 4, h - 4)
        R(cv, bot, x + 2, y + 2 + (h - 4) // 2, w - 4, (h - 4) - (h - 4) // 2)
        R(cv, self._lerp(top, (255, 255, 255), .28), x + 2, y + 2, w - 4, 1)   # highlight atas
        R(cv, self._lerp(bot, (0, 0, 0), .35), x + 2, y + h - 3, w - 4, 1)     # bayangan bawah
        for sx, sy in ((x + 3, y + 3), (x + w - 4, y + 3), (x + 3, y + h - 4), (x + w - 4, y + h - 4)):
            R(cv, edge, sx, sy, 1, 1)                                    # paku sudut
        if hover:                                                         # kilau menyapu
            bx = x + 2 + int((self.t * 110) % (w + 40)) - 20
            lo, hi = max(x + 2, bx), min(x + w - 2, bx + 8)
            if hi > lo:
                R(cv, (255, 255, 255, 46), lo, y + 2, hi - lo, h - 4)
            bob = int(self.t * 6) % 2                                    # penunjuk panah
            for i in range(3):
                R(cv, GOLD, x - 8 + i + bob, y + h // 2 - 2 + i, 1, 5 - 2 * i)
        ty = y + (h - 7 * scale) // 2
        self.T(label, r.centerx, ty, fg, scale, "center", (12, 6, 8) if enabled else None)
        if icon:
            self._icon(icon, x + 8, y + (h - 7) // 2, fg)
        if led is not None:
            lc = (90, 236, 130) if led else (214, 64, 54)
            R(cv, (10, 6, 8), x + w - 15, y + h // 2 - 4, 7, 7)
            R(cv, lc, x + w - 14, y + h // 2 - 3, 5, 5)
            R(cv, self._lerp(lc, (255, 255, 255), .5), x + w - 14, y + h // 2 - 3, 2, 2)
        self.ui.append((bid, r, enabled))

    def draw_menu(self):
        self.draw_menu_backdrop()
        self.draw_menu_ui()

    def draw_menu_ui(self):
        self.draw_title(16)
        pr = pygame.Rect(16, 128, 236, 196)
        self.draw_panel_frame(pr, "MENU UTAMA")
        bx, bw = pr.x + 12, pr.w - 24
        self.menu_button("start", (bx, 142, bw, 26), "MULAI PERMAINAN", True, 2, "primary", "play")
        self.menu_button("settings", (bx, 173, bw, 26), "PENGATURAN", True, 2, "normal", "gear")
        self.menu_button("trophies", (bx, 204, bw, 26), "RAK PIALA", True, 2, "normal", "cup")
        self.menu_button("credits", (bx, 235, bw, 26), "KREDIT", True, 2, "normal", "star")
        self.menu_button("exit", (bx, 266, bw, 26), "KELUAR GAME", True, 2, "danger", "exit")
        self.menu_button("tutorial", (bx, 300, 102, 16), "TUTORIAL", True, 1)
        self.menu_button("replay", (bx + 110, 300, 102, 16), "ULANG INTRO", True, 1)
        self.T("BETA", 8, CH - 14, (170, 136, 88), 1, "left", (0, 0, 0))

    # ------------------------------------------------------------------
    # ANIMASI MASUK ISTANA: pintu terbuka -> zoom ke dalam -> layar memutih
    # ------------------------------------------------------------------
    ENTER_TOTAL = 4.9
    ENTER_ZOOM = 9.0          # perbesaran akhir kamera

    def begin_enter(self):
        self.state = "enter"
        self.enter_t = 0.0
        self._enter_sfx = False
        self.mini = None
        self.say("Pintu Istana terbuka...")

    def draw_enter(self):
        t, cx = self.enter_t, self.PAL_CX
        sm = lambda k: k * k * (3 - 2 * k)
        cl = lambda v: max(0.0, min(1.0, v))
        open_p = sm(cl((t - 1.2) / 1.6))
        self.draw_menu_backdrop(open_p)
        # --- kamera: zoom eksponensial menuju pintu utama
        e = sm(cl(t / 3.9))
        z = self.ENTER_ZOOM ** e
        w = max(8, int(round(CW / z)))
        h = max(8, int(round(w * CH / CW)))
        fx = CW / 2 + (cx - CW / 2) * e
        fy = CH / 2 + (238 - CH / 2) * e
        x0 = int(max(0, min(CW - w, fx - w / 2)))
        y0 = int(max(0, min(CH - h, fy - h / 2)))
        snap = self.cv.copy()
        self.cv.blit(pygame.transform.scale(snap.subsurface(pygame.Rect(x0, y0, w, h)), (CW, CH)), (0, 0))
        # --- getaran halus saat pintu terbuka
        self.shake = 0.35 if 1.2 < t < 2.9 else 0.0
        # --- UI naik & memudar di awal
        if t < 0.7:
            u = cl(t / 0.7)
            ui = pygame.Surface((CW, CH), pygame.SRCALPHA)
            real, self.cv = self.cv, ui
            mp, self.mpos = self.mpos, (-999, -999)
            self.draw_menu_ui()
            self.cv, self.mpos = real, mp
            self.ui = []
            ui.set_alpha(int(255 * (1 - u)))
            self.cv.blit(ui, (0, -int(150 * u * u)))
        # --- cahaya meluap dari pintu, lalu putih penuh
        kb = cl((t - 2.6) / 1.6)
        if kb > 0:
            bw = int((10 * z) + (CW * 1.3 - 10 * z) * kb * kb)
            self._R(self.cv, (255, 250, 228, int(40 + 215 * kb)), CW / 2 - bw / 2, 0, bw, CH)
        wa = cl((t - 3.5) / 1.0)
        if wa > 0:
            self._R(self.cv, (255, 255, 255, int(255 * wa)), 0, 0, CW, CH)

    def draw_settings(self):
        from_pause = self.settings_from == "pause"
        if from_pause:
            self.draw_pause_backdrop()
            self.rectf((0, 0, 0, 170), 0, 0, CW, CH)
            pr = pygame.Rect(CW // 2 - 124, 58, 248, 244)
            by = pr.y + 20
        else:
            self.draw_menu_backdrop()
            self.draw_title(16)
            pr = pygame.Rect(16, 128, 236, 196)
            by = 144
        self.draw_panel_frame(pr, "PENGATURAN", 2 if from_pause else 1)
        bx, bw = pr.x + 12, pr.w - 24
        self.menu_button("sound", (bx, by, bw, 26), "TYPING SFX : " + ("OFF" if self.audio.muted else "ON"),
                         self.audio.enabled, 2, "normal", None, (not self.audio.muted))
        self.menu_button("music", (bx, by + 32, bw, 26), "MUSIK : " + ("NYALA" if self.music.on else "MATI"),
                         self.music.enabled, 2, "normal", None, bool(self.music.on))
        self.menu_button("crt", (bx, by + 64, bw, 26), "EFEK CRT : " + ("NYALA" if self.crt else "MATI"),
                         True, 2, "normal", None, bool(self.crt))
        self.menu_button("fullscreen", (bx, by + 96, bw, 26), "LAYAR PENUH (F11)", True, 2)
        self.menu_button("back", (bx, by + 136, bw, 28), "KEMBALI", True, 2, "primary")
        self.T("SFX = ketik, klik & efek lain", pr.centerx, by + 170, (170, 136, 88), 1, "center", (0, 0, 0))

    def draw_pause_backdrop(self):
        """Gambar adegan game di balik menu jeda (peta, atau minigame yang sedang dimainkan)."""
        if self.pause_from == "mini" and self.mini is not None:
            self.draw_mini()
            self.ui = []
            self._hov_now = None
        else:
            self.draw_underlay()

    def draw_pause(self):
        self.rectf((0, 0, 0, 170), 0, 0, CW, CH)
        pr = pygame.Rect(CW // 2 - 124, 74, 248, 186)
        self.draw_panel_frame(pr, "JEDA", 2)
        bx, bw = pr.x + 12, pr.w - 24
        self.menu_button("resume", (bx, pr.y + 22, bw, 28), "LANJUTKAN", True, 2, "primary", "play")
        self.menu_button("settings", (bx, pr.y + 58, bw, 28), "PENGATURAN", True, 2, "normal", "gear")
        self.menu_button("tomenu", (bx, pr.y + 94, bw, 28), "MENU UTAMA", True, 2)
        self.menu_button("exit", (bx, pr.y + 130, bw, 28), "KELUAR GAME", True, 2, "danger", "exit")

    # ------------------------------------------------------------------
    # ALUR GAME
    # ------------------------------------------------------------------
    TRANS_TOTAL = 3.2

    def market(self):
        return 1 + 0.15 * (self.s["day"] - 1)

    def set_scene(self, i):
        self.state = "intro"
        self.scene = i
        self.scene_time = 0.0
        self._decree_hit = False
        self.shake = 1.5 if i in (1, 2) else 0.0
        if i in (1, 2):
            self.audio.play("dramatic")
        self.say(SCENES[i][2])

    def next_scene(self):
        if self.scene < len(SCENES) - 1:
            self.set_scene(self.scene + 1)
        else:
            self.go_menu()

    def go_menu(self):
        self.credits_preview = False
        self.state = "menu"
        self.shake = 0.0
        self.mini = None
        self.say(MENU_CAPTION)

    def start_game(self):
        self.credits_preview = False
        self.s = new_state()
        self.mini = None
        self.start_transition(1)

    def start_transition(self, day):
        self.trans = {"day": day, "t": 0.0, "snap": self.cv.copy()}
        self.state = "transition"
        self.say("Klik atau tekan SPASI untuk lanjut.")

    def choose_hidden(self, day):
        if day == 1:
            return set()
        limit = 0 if day <= 7 else 1
        cand = [r for r in REGIONS if self.s["streak"][r] <= limit]
        return set(random.sample(cand, min(2, len(cand))))

    def start_day(self):
        s = self.s
        day = s["day"]
        s["mini_done"] = s["exported"] = False
        s["played"] = set()
        s["pending_hidden"] = self.choose_hidden(day)
        s["hidden"] = set()
        s["observing"] = True
        s["obs_total"] = 10.0 if day < 5 else 5.0
        s["obs_left"] = s["obs_total"]
        s["banner"] = ["Hafalkan kondisi pulau (%d detik)!" % int(s["obs_total"]), 3.0]
        self.state = "main"
        if day == 1:
            self.say("Hafalkan angka tiap pulau sebelum kabut turun. "
                     "Hasil bumi dijual lewat Jawa.")
        else:
            hint = self.mood_hint()
            self.say("Hari %d: hafalkan angka tiap pulau sebelum kabut turun!%s" %
                     (day, (" " + hint[2]) if hint else ""))
        if s["pending_events"]:
            self.next_event()

    def finish_obs(self):
        s = self.s
        s["observing"] = False
        s["hidden"] = set(s["pending_hidden"])
        for r in REGIONS:
            s["streak"][r] = s["streak"][r] + 1 if r in s["hidden"] else 0
        if s["hidden"]:
            names = " & ".join(r for r in REGIONS if r in s["hidden"])
            s["banner"] = ["Kabut turun! %s tersembunyi!" % names, 3.5]
            self.say("Kabut menutupi %s. Ingat angkanya, lalu bagikan dana!" % names)
            self.audio.play("fog")
        else:
            s["banner"] = ["Hari 1: semua pulau terlihat jelas.", 3.0]
            self.say("Tidak ada kabut hari ini. Mulai bekerja!")
        if s["day"] in s["corrupt_days"]:
            amt = random.randint(15, 25)
            s["offer"] = (random.choice(OFFERS).format(x=amt), amt)
            self.state = "corrupt"
            self.audio.play("dramatic")

    def check_secession(self):
        """Pulau dengan kesejahteraan 0 memilih berpisah dari Indonesia."""
        s = self.s
        for r in REGIONS:
            if r not in s["seceded"] and s["welfare"][r] <= 0:
                s["seceded"].add(r)
                s["welfare"][r] = 0
                s["dissat"] = min(100, s["dissat"] + 10)

    def open_secede(self, r):
        self.secede_name = r
        self.state = "secede"
        self.audio.play("bad")
        self.say("%s memilih untuk berpisah dari Indonesia." % r)

    def advance_day(self):
        s = self.s
        s["marks"] = {}
        for r in REGIONS:
            if r in s["seceded"]:
                s["exploit"][r] = 0
                continue
            # eksploitasi berturut-turut: hitung hari beruntun, lalu kalikan hasil acak penyusutan
            s["exploit"][r] = s["exploit"][r] + 1 if r in s["played"] else 0
            mult = exploit_mult(s["exploit"][r])
            decay = round(random.randint(4, 9) * mult, 1) + (3 if r == "Papua" else 0)
            s["welfare"][r] = max(0, s["welfare"][r] - decay)
        if s["day"] < 10:
            self.roll_disasters()
        self.check_secession()
        low = sum(1 for v in s["welfare"].values() if v < 30)
        s["dissat"] += low * 4 + 3 * len(s["seceded"])
        if all(v >= 40 for v in s["welfare"].values()):
            s["dissat"] -= 3
        s["dissat"] = max(0, min(100, s["dissat"]))
        if s["day"] < 10:
            self.roll_people_event()
        if s["day"] >= 10:
            s["end"] = self.compute_end()
            self.start_ending()
            return
        s["day"] += 1
        self.start_transition(s["day"])

    def give(self, amt):
        s = self.s
        r = REGIONS[s["sel"]]
        if r in s["seceded"]:
            self.open_secede(r)
            return
        if s["budget"] < amt:
            return
        gain = amt * 2.0 * (1 - s["welfare"][r] / 140)
        s["welfare"][r] = min(100, s["welfare"][r] + gain)
        s["budget"] -= amt
        s["flash"] = (s["sel"], self.t)
        self.audio.play("coin")
        self.say("Rp%d juta dikirim ke %s." % (amt, r))

    def export_quota(self):
        """Porsi gudang yang boleh diekspor. Makin tinggi ketidakpuasan, makin kecil
        (0% marah = 100%, 50% = 55%, 100% = 10%)."""
        return max(0.1, min(1.0, 1.0 - 0.9 * self.s["dissat"] / 100.0))

    def export_plan(self):
        """Jumlah unit per komoditas yang benar-benar bisa dikirim sekarang."""
        q = self.export_quota()
        out = {}
        for c in COMMS:
            n = self.s["stock"][c]
            out[c] = 0 if n <= 0 else min(n, max(1, int(round(n * q))))
        return out

    def export_value(self):
        plan = self.export_plan()
        return sum(plan[c] * PRICE[c] for c in COMMS) * self.market()

    def export_goods(self, mult=1.0, extra_msg=""):
        s = self.s
        plan = self.export_plan()
        base = sum(plan[c] * PRICE[c] for c in COMMS) * self.market()
        income = round(base * mult, 1)
        held = sum(s["stock"][c] - plan[c] for c in COMMS)
        s["budget"] += income
        s["export_total"] += income
        s["stock"] = {c: s["stock"][c] - plan[c] for c in COMMS}
        s["exported"] = True
        self.audio.play("coin")
        extra = " (bonus negosiasi x%.1f)" % mult if mult > 1.0 else ""
        held_msg = (" %d unit tertahan karena rakyat tidak puas (kuota %d%%)." %
                    (held, round(self.export_quota() * 100))) if held > 0 else ""
        self.say("Ekspor berhasil%s! Kas bertambah Rp%.1f juta.%s%s" %
                 (extra, income, held_msg, extra_msg))

    def compute_end(self):
        s = self.s
        thr = s["thr"]
        vals = [s["welfare"][r] for r in REGIONS]
        avg = sum(vals) / 5
        sec = [r for r in REGIONS if r in s["seceded"]]
        pros = [r for r in REGIONS if r not in s["seceded"] and s["welfare"][r] >= thr]
        n = len(pros)
        if len(sec) >= 2:
            head = "INDONESIA TERPECAH: %d PULAU MEMILIH BERPISAH" % len(sec)
        elif len(sec) == 1:
            head = "%s MEMISAHKAN DIRI DARI INDONESIA, PRESIDEN DIKECAM" % sec[0].upper()
        elif s["corrupt"] >= 2 and n <= 2:
            head = "INDONESIA BANGKRUT, PRESIDEN LARI DENGAN UANG RAKYAT"
        elif s["corrupt"] >= 2:
            head = "INDONESIA MAKMUR, TAPI PRESIDEN JUGA MENDADAK KAYA"
        else:
            head = {5: "SELURUH PULAU MAKMUR, INDONESIA JAYA, PRESIDEN DIELU-ELUKAN",
                    4: "HAMPIR SEMUA PULAU MAKMUR, INDONESIA BERSYUKUR",
                    3: "INDONESIA MAJU, NAMUN SEBAGIAN PULAU MASIH TERTINGGAL",
                    2: "PEMBANGUNAN TIMPANG: HANYA 2 PULAU YANG MAKMUR",
                    1: "HANYA 1 PULAU MAKMUR, INDONESIA MASIH BERTANYA-TANYA",
                    0: "INDONESIA TERPURUK, TIDAK ADA PULAU YANG MAKMUR"}[n]
        subs = []
        for r in sec:
            subs.append("Warga %s mengibarkan bendera sendiri dan menolak kembali." % r)
        if n:
            subs.append("%d dari 5 pulau melampaui ambang makmur (%d%%): %s." % (n, thr, ", ".join(pros)))
        if s["corrupt"] >= 2:
            subs.append("Amplop-amplop misterius ternyata berujung di rekening pribadi presiden.")
        elif s["corrupt"] == 1:
            subs.append("Sebuah amplop misterius dikabarkan sempat mampir ke meja presiden.")
        else:
            subs.append("Presiden menolak semua tawaran 'uang terima kasih'. Netizen curiga ini prank.")
        if s["dissat"] > 60:
            subs.append("Demo besar-besaran mengguncang ibu kota, kursi presiden mulai goyah.")
        if s["budget"] >= 40:
            subs.append("Rp%.0f juta anggaran masih utuh, sementara rakyat menunggu." % s["budget"])
        if s["export_total"] >= 150:
            subs.append("Pelabuhan Jawa sibuk siang-malam: ekspor menembus Rp%.0f juta." % s["export_total"])
        win = n >= 3 and not sec and s["dissat"] <= 60 and s["corrupt"] < 2
        return {"head": head, "subs": subs[:3], "win": win, "avg": avg, "thr": thr, "rating": rating_of(avg),
                "pros": pros, "sec": sec}

    # ------------------------------------------------------------------
    # LAYAR UTAMA
    # ------------------------------------------------------------------
    # ==================================================================
    # TOOLKIT UI BERGAYA RPG: ikon, teks bergaris tepi, jendela, bar, label
    # ==================================================================
    _pics = {}
    _otx = {}
    COMM_ICON = {"Padi": "wheat", "Ikan": "fish", "Kayu": "log", "Besi": "ore"}

    def pic(self, name, x, y, scale=1, surf=None):
        """Gambar ikon pixel berwarna dari ICON_ART. Mengembalikan lebarnya."""
        key = (name, scale)
        sp = self._pics.get(key)
        if sp is None:
            art = ICON_ART[name]
            sp = pygame.Surface((max(len(r) for r in art) * scale, len(art) * scale), pygame.SRCALPHA)
            for ry, row in enumerate(art):
                for rx, ch in enumerate(row):
                    if ch != ".":
                        sp.fill(ICON_PAL[ch], (rx * scale, ry * scale, scale, scale))
            self._pics[key] = sp
        (self.cv if surf is None else surf).blit(sp, (int(x), int(y)))
        return sp.get_width()

    def OT(self, s, x, y, color=TXT, scale=1, align="left", outline=WIN_EDGE, surf=None):
        """Teks dengan garis tepi gelap: jauh lebih mudah dibaca di atas latar apa pun."""
        surf = self.cv if surf is None else surf
        w = self.font.width(s, scale)
        if align == "center":
            x -= w // 2
        elif align == "right":
            x -= w
        x, y = int(x), int(y)
        key = (s, scale, tuple(color[:3]), tuple(outline[:3]))
        sp = self._otx.get(key)
        if sp is None:
            if len(self._otx) > 700:
                self._otx.clear()
            k = scale
            sp = pygame.Surface((w + 2 * k, 9 * scale + 2 * k), pygame.SRCALPHA)
            dark = self.font.render(s, scale, outline)
            for dx, dy in ((0, 1), (2, 1), (1, 0), (1, 2), (0, 0), (2, 0), (0, 2), (2, 2)):
                sp.blit(dark, (dx * k, dy * k))
            sp.blit(self.font.render(s, scale, color), (k, k))
            self._otx[key] = sp
        surf.blit(sp, (x - scale, y - scale))

    def bands(self, x, y, w, h, c0, c1, n=8, surf=None):
        """Gradasi vertikal berpita (khas pixel-art, murah digambar tiap frame)."""
        surf = self.cv if surf is None else surf
        for i in range(n):
            ya = y + h * i // n
            yb = y + h * (i + 1) // n
            if yb > ya:
                surf.fill(self._mix(c0, c1, i / max(1, n - 1)), (int(x), int(ya), int(w), int(yb - ya)))

    def rwin(self, rect, title=None, top=WIN_TOP, bot=WIN_BOT, ribbon=(150, 34, 44), shadow=True):
        """Jendela RPG: bayangan, bingkai emas, latar biru malam bergradasi, paku di sudut."""
        r = pygame.Rect(rect)
        if shadow:
            self.rectf((0, 0, 0, 120), r.x + 3, r.y + 3, r.w, r.h)
        self.rectf(WIN_EDGE, r.x - 1, r.y - 1, r.w + 2, r.h + 2)
        self.rectf(GOLD2, r.x, r.y, r.w, r.h)
        self.rectf((255, 236, 160), r.x + 1, r.y + 1, r.w - 2, 1)
        self.rectf(WIN_EDGE, r.x + 2, r.y + 2, r.w - 4, r.h - 4)
        body = pygame.Rect(r.x + 3, r.y + 3, r.w - 6, r.h - 6)
        self.bands(body.x, body.y, body.w, body.h, top, bot, 7)
        self.rectf((WIN_HI[0], WIN_HI[1], WIN_HI[2], 90), body.x + 2, body.y + 2, body.w - 4, 1)
        for qx, qy in ((r.x - 1, r.y - 1), (r.right - 4, r.y - 1), (r.x - 1, r.bottom - 4), (r.right - 4, r.bottom - 4)):
            self.rectf(WIN_EDGE, qx, qy, 5, 5)
            self.rectf(GOLD, qx + 1, qy + 1, 3, 3)
            self.rectf(WIN_EDGE, qx + 2, qy + 2, 1, 1)
        if title:
            tw = self.font.width(title) + 24
            rx, ry = r.centerx - tw // 2, r.y - 7
            self.rectf(WIN_EDGE, rx - 1, ry - 1, tw + 2, 15)
            self.rectf(ribbon, rx, ry, tw, 13)
            self.rectf(self._mix(ribbon, (255, 255, 255), .25), rx, ry + 1, tw, 4)
            self.rectf(GOLD2, rx, ry, tw, 1)
            self.rectf(GOLD2, rx, ry + 12, tw, 1)
            self.rectf(GOLD, rx + 5, ry + 5, 3, 3)
            self.rectf(GOLD, rx + tw - 8, ry + 5, 3, 3)
            self.OT(title, r.centerx, ry + 3, TXT_GOLD, 1, "center", self._mix(ribbon, (0, 0, 0), .6))

    def rbar(self, x, y, w, h, v, vmax=100.0, col=None, segs=0):
        """Bar status ala RPG (HP bar): bingkai gelap, kilau di atas, sekat segmen."""
        self.rectf(WIN_EDGE, x - 1, y - 1, w + 2, h + 2)
        self.rectf((38, 42, 74), x, y, w, h)
        f = max(0.0, min(1.0, v / float(vmax)))
        fw = int(w * f)
        if v > 0:
            fw = max(2, fw)
        c = col or bar_color(v)
        if fw > 0:
            self.rectf(c, x, y, fw, h)
            self.rectf(self._mix(c, (255, 255, 255), .45), x, y, fw, max(1, h // 3))
            self.rectf(self._mix(c, (0, 0, 0), .35), x, y + h - 1, fw, 1)
        for i in range(1, segs):
            self.rectf(WIN_EDGE, x + w * i // segs, y, 1, h)

    def rtag(self, x, y, text, bg, fg=TXT, align="left"):
        """Label kecil berwarna (seperti lencana status). Mengembalikan lebarnya."""
        w = self.font.width(text) + 10
        if align == "right":
            x -= w
        self.rectf(WIN_EDGE, x - 1, y - 1, w + 2, 13)
        self.rectf(bg, x, y, w, 11)
        self.rectf(self._mix(bg, (255, 255, 255), .3), x, y, w, 1)
        self.rectf(self._mix(bg, (0, 0, 0), .35), x, y + 10, w, 1)
        self.T(text, x + 5, y + 2, fg, 1, "left", self._mix(bg, (0, 0, 0), .6))
        return w

    def rdiv(self, x, y, w):
        """Garis pemisah bagian di dalam jendela."""
        self.rectf(WIN_EDGE, x, y, w, 1)
        self.rectf((70, 86, 160), x, y + 1, w, 1)
        self.rectf(GOLD2, x + w // 2 - 3, y - 1, 7, 3)
        self.rectf(WIN_EDGE, x + w // 2 - 1, y, 3, 1)

    def hud_slot(self, x, w, icon, label, value, vcol=TXT, lcol=TXT_DIM):
        """Satu kotak di bar atas: ikon + judul kecil + nilai."""
        self.rectf(WIN_EDGE, x, 3, w, 20)
        self.rectf((24, 30, 66), x + 1, 4, w - 2, 18)
        self.rectf((44, 54, 112), x + 1, 4, w - 2, 1)
        self.pic(icon, x + 3, 9)
        self.OT(label, x + 14, 6, lcol)
        if value is not None:
            self.OT(value, x + 14, 14, vcol)

    def map_frame(self):
        r = MAP.inflate(6, 6)
        self.frame(WIN_EDGE, r, 1)
        self.frame(GOLD2, r.inflate(-2, -2), 2)
        for qx, qy in ((r.x - 1, r.y - 1), (r.right - 4, r.y - 1), (r.x - 1, r.bottom - 4), (r.right - 4, r.bottom - 4)):
            self.rectf(WIN_EDGE, qx, qy, 5, 5)
            self.rectf(GOLD, qx + 1, qy + 1, 3, 3)
            self.rectf(WIN_EDGE, qx + 2, qy + 2, 1, 1)

    def draw_event_card(self, title, accent, art, text, rows, tip, tip_col, badge=None, pending=0):
        """Kartu kejadian (bencana / rakyat): gambar, cerita singkat, daftar DAMPAK berikon."""
        cx = CW / 2
        box = pygame.Rect(90, 34, 460, 292)
        self.rwin(box, title, ribbon=accent)
        if pending:
            self.OT("+%d lagi" % pending, box.right - 12, box.y + 12, TXT_DIM, 1, "right")
        ax, ay = box.x + 18, box.y + 28
        self.rectf(WIN_EDGE, ax - 1, ay - 1, 74, 74)
        self.rectf(accent, ax, ay, 72, 72)
        self.rectf((236, 226, 196), ax + 2, ay + 2, 68, 68)
        self.cv.blit(art, (ax + 4, ay + 4))
        ty = box.y + 30
        for ln in self.font.wrap(text, 1, box.w - 104 - 16)[:5]:
            self.OT(ln, box.x + 104, ty, TXT, 1)
            ty += 12
        hh = 17 + sum(20 if big else 15 for _, _, _, big in rows) + 3
        eb = pygame.Rect(box.x + 16, box.y + 108, box.w - 32, hh)
        self.rectf(WIN_EDGE, eb.x - 1, eb.y - 1, eb.w + 2, eb.h + 2)
        self.rectf((10, 12, 34), eb.x, eb.y, eb.w, eb.h)
        self.OT("DAMPAK", eb.x + 8, eb.y + 5, TXT_GOLD)
        yy = eb.y + 17
        for icon, txt, col, big in rows:
            if big:
                self.pic(icon, eb.x + 8, yy + 2, 2)
                self.OT(txt, eb.x + 30, yy + 4, col, 2)
                yy += 20
            else:
                self.pic(icon, eb.x + 10, yy + 3)
                self.OT(txt, eb.x + 24, yy + 4, col, 1)
                yy += 15
        yb = eb.bottom + 8
        if badge:
            pb = pygame.Rect(box.x + 20, yb, box.w - 40, 28)
            self.rectf(WIN_EDGE, pb.x - 1, pb.y - 1, pb.w + 2, pb.h + 2)
            self.rectf((70, 52, 18), *pb)
            self.rectf(GOLD2, pb.x, pb.y, pb.w, 1)
            self.pic("star", pb.x + 8, pb.y + 10)
            self.OT("PIALA BARU: " + badge, pb.centerx + 6, pb.y + 5, TXT_GOLD, 1, "center")
            self.OT("Tersimpan di RAK PIALA (menu utama)", pb.centerx + 6, pb.y + 16, TXT, 1, "center")
        elif tip:
            for j, ln in enumerate(self.font.wrap(tip, 1, box.w - 40)[:2]):
                self.OT(ln, cx, yb + 2 + j * 12, tip_col, 1, "center")
        self.button("event_ok", (cx - 70, box.bottom - 36, 140, 26), "LANJUT", True, 2, "primary")

    def draw_hud(self):
        s = self.s
        self.bands(0, 0, CW, 25, (22, 30, 70), (8, 11, 32), 5)
        self.rectf(GOLD2, 0, 25, CW, 1)
        self.hud_slot(4, 62, "calendar", "HARI", "%d / 10" % s["day"], TXT_GOLD)
        self.hud_slot(70, 100, "coin", "KAS", "Rp%.1f jt" % s["budget"], TXT)
        self.hud_slot(174, 70, "crate", "GUDANG", "%d unit" % sum(s["stock"].values()), TXT)
        hint = self.mood_hint()
        d = s["dissat"]
        self.hud_slot(248, 150, "heart", hint[0] if hint else "KETIDAKPUASAN", None,
                      TXT, hint[1] if hint else TXT_DIM)
        self.rbar(262, 15, 96, 6, d, 100, OK_C if d < 35 else WARN_C if d < 55 else BAD_C)
        self.OT("%d%%" % d, 364, 14, TXT)
        self.hud_slot(402, 76, "chart", "PASAR", "x%.2f" % self.market(), WARN_C)
        n = len(s["hidden"])
        self.hud_slot(482, 70, "cloud", "KABUT", "%d pulau" % n, WARN_C if n else TXT_DIM)
        self.rectf(WIN_EDGE, 558, 5, 22, 15)
        self.rectf((190, 196, 220), 559, 6, 20, 12)
        self.rectf((120, 128, 160), 559, 15, 20, 3)
        self.T("ESC", 569, 9, (30, 30, 50), 1, "center")
        self.OT("JEDA", 584, 9, TXT_DIM)

    def draw_island(self, r, i):
        s = self.s
        reveal = r not in s["hidden"]
        welfare = s["welfare"][r]
        gone = r in s["seceded"]
        level = 0 if gone and reveal else tier_of(welfare) if reveal else 1
        gray = (not reveal) or gone
        key = (r, level, gray)
        if key not in CACHE:
            CACHE[key] = render_island(r, level, gray)
        surf, (ox, oy) = CACHE[key]
        bob = int(math.sin(self.t * 1.6 + i) * 1.5 + .5)
        self.cv.blit(surf, (MAP.x + ox, MAP.y + oy + bob))
        if not reveal:
            fs, (fx, fy) = FOG[r]
            self.cv.blit(fs, (MAP.x + fx, MAP.y + fy + bob))
            cx, cy = CENTER[r]
            self.T("?", MAP.x + cx, MAP.y + cy + bob - 12, (60, 60, 75), 4, "center")
        if gone and reveal:                       # tanda silang merah: pulau berpisah dari Indonesia
            cx, cy = CENTER[r]
            cx, cy = MAP.x + cx, MAP.y + cy + bob
            d = 17 + int(self.t * 3) % 2
            for wd, col in ((11, (34, 6, 10)), (7, (196, 36, 40)), (3, (255, 110, 96))):
                pygame.draw.line(self.cv, col, (cx - d, cy - d), (cx + d, cy + d), wd)
                pygame.draw.line(self.cv, col, (cx - d, cy + d), (cx + d, cy - d), wd)
        if reveal and r in s["marks"]:           # ikon bencana hari ini di atas pulau
            cx, cy = CENTER[r]
            cx, cy = MAP.x + cx, MAP.y + cy + bob - 24
            pygame.draw.circle(self.cv, (30, 14, 14), (cx, cy), 15)
            pygame.draw.circle(self.cv, (214, 44, 44) if int(self.t * 3) % 2 else (255, 120, 90), (cx, cy), 15, 2)
            self.cv.blit(self.emblem(s["marks"][r], 2), (cx - 16, cy - 16))
        pts = [(MAP.x + x, MAP.y + y + bob) for x, y in POLY[r]]
        if i == s["sel"]:
            pygame.draw.polygon(self.cv, GOLD, pts, 1 + int(self.t * 4) % 2)
        fl_i, fl_t = s["flash"]
        if fl_i == i and self.t - fl_t < 0.4:
            pygame.draw.polygon(self.cv, WHITE, pts, 3)

    def draw_badge(self, r, i):
        s = self.s
        reveal = r not in s["hidden"]
        v = s["welfare"][r]
        gone = reveal and r in s["seceded"]
        cx, cy = LABEL_POS[r]
        rc = pygame.Rect(0, 0, 100, 24)
        rc.center = (MAP.x + cx, MAP.y + cy)
        sel = i == s["sel"]
        edge = GOLD if sel else (118, 130, 190)
        if gone:
            c0, c1 = (96, 30, 38), (46, 14, 20)
        elif not reveal:
            c0, c1 = (62, 64, 80), (30, 32, 44)
        else:
            c0, c1 = (36, 50, 108), (14, 18, 48)
        self.rectf((0, 0, 0, 110), rc.x + 2, rc.y + 2, rc.w, rc.h)
        self.rectf(WIN_EDGE, rc.x - 1, rc.y - 1, rc.w + 2, rc.h + 2)
        self.rectf(edge, rc.x, rc.y, rc.w, rc.h)
        hh = (rc.h - 2) // 2
        self.rectf(c0, rc.x + 1, rc.y + 1, rc.w - 2, hh)
        self.rectf(c1, rc.x + 1, rc.y + 1 + hh, rc.w - 2, rc.h - 2 - hh)
        if gone:
            self.OT(r, rc.x + 6, rc.y + 4, (200, 200, 210))
            self.OT("BERPISAH", rc.x + 6, rc.y + 14, BAD_C)
        elif reveal:
            self.OT(r, rc.x + 6, rc.y + 4, TXT_GOLD if sel else TXT)
            self.OT("%d" % v, rc.right - 6, rc.y + 4, self._mix(bar_color(v), (255, 255, 255), .4), 1, "right")
            self.rbar(rc.x + 6, rc.y + 15, rc.w - 12, 5, v, 100, None, 10)
        else:
            self.OT(r, rc.x + 6, rc.y + 4, (176, 176, 190))
            self.pic("cloud", rc.x + 6, rc.y + 13)
            self.OT("TERTUTUP", rc.x + 17, rc.y + 14, WARN_C)
        if sel:
            self.pic("down", rc.centerx - 3, rc.y - 9 - int(self.t * 5) % 2)

    def draw_map(self):
        cv = self.cv
        cv.set_clip(MAP)
        cv.blit(self.sea, MAP.topleft)
        for gx, gy, ph in GLINTS:
            if math.sin(self.t * 1.6 + ph) > .6:
                self.rectf((120, 180, 205), MAP.x + gx, MAP.y + gy, 5, 1)
        for y, off, sp in CLOUDS:
            cv.blit(self.cloud, (MAP.x + (self.t * sp + off) % (MAP.w + 160) - 100, MAP.y + y))
        for k, (y, sp, off) in enumerate(BOATS):
            bx = MAP.x + (self.t * sp + off) % (MAP.w + 80) - 40
            draw_boat(cv, bx, MAP.y + y + math.sin(self.t * 3 + k) * 1.5, sp < 0)
        for i, r in enumerate(REGIONS):
            self.draw_island(r, i)
        for i, r in enumerate(REGIONS):
            self.draw_badge(r, i)
        cv.set_clip(None)
        self.map_frame()

    def draw_obs(self, x, y):
        s = self.s
        fast = s["day"] >= 5
        r = pygame.Rect(434, 118, 194, 132)
        self.rwin(r, "PENGAMATAN" + (" CEPAT!" if fast else ""),
                  ribbon=(176, 52, 40) if fast else (50, 80, 160))
        left = max(0.0, s["obs_left"])
        col = BAD_C if left <= 2 else WARN_C if left <= 4 else OK_C
        cx = r.centerx
        self.pic("hourglass", cx - 8, r.y + 12, 2)
        self.OT("%.1f" % left, cx, r.y + 32, col, 3, "center")
        self.rbar(r.x + 12, r.y + 60, r.w - 24, 7, left, s["obs_total"], col)
        self.OT("Hafalkan angka tiap pulau!", cx, r.y + 73, TXT, 1, "center")
        self.OT("Lalu kabut akan turun." if s["day"] > 1 else "Hari pertama: tanpa kabut.",
                cx, r.y + 85, TXT_DIM, 1, "center")
        self.button("skipobs", (r.x + 12, r.y + 102, r.w - 24, 22), "LEWATI >>", True, 1, "go")

    def draw_panel(self):
        s = self.s
        i = s["sel"]
        r = REGIONS[i]
        com, role = ROLE[r]
        can = self.state == "main" and not s["observing"]
        Pn = pygame.Rect(428, 28, 206, 326)
        self.rwin(Pn)
        x, w = Pn.x + 8, Pn.w - 16
        y = Pn.y + 9
        hid = r in s["hidden"]
        gone = r in s["seceded"]
        v = s["welfare"][r]
        can_r = can and (hid or not gone)

        # --- judul pulau
        self.OT(r.upper(), x, y, TXT_GOLD, 2)
        self.pic(self.COMM_ICON.get(com, "ship"), Pn.right - 26, y - 1, 2)
        self.rtag(x, y + 19, role, (120, 36, 46), TXT_GOLD)
        y += 35

        # --- kemakmuran (bar HP)
        self.OT("KEMAKMURAN", x, y, TXT_DIM)
        if hid:
            self.OT("??/100", x + w, y, WARN_C, 1, "right")
            self.rectf(WIN_EDGE, x - 1, y + 10, w + 2, 11)
            self.rectf((64, 68, 96), x, y + 11, w, 9)
            self.OT("TERTUTUP KABUT", x + w // 2, y + 12, TXT, 1, "center")
            self.rtag(x, y + 25, "Angka tersembunyi", (90, 70, 40), WARN_C)
        elif gone:
            self.OT("0/100", x + w, y, BAD_C, 1, "right")
            self.rectf(WIN_EDGE, x - 1, y + 10, w + 2, 11)
            self.rectf((120, 36, 40), x, y + 11, w, 9)
            self.OT("BERPISAH DARI INDONESIA", x + w // 2, y + 12, TXT, 1, "center")
        else:
            tier = tier_of(v)
            self.OT("%d/100" % v, x + w, y, self._mix(bar_color(v), (255, 255, 255), .4), 1, "right")
            self.rbar(x, y + 11, w, 9, v, 100, None, 10)
            tier_bg = ((150, 44, 44), (150, 108, 30), (40, 120, 72), (50, 100, 190))[tier]
            self.rtag(x, y + 25, TIER_NAMES[tier], tier_bg, TXT)
        y += 44
        self.rdiv(x, y - 4, w)

        # --- bagikan dana
        self.pic("coin", x, y)
        self.OT("BAGIKAN DANA", x + 11, y + 1, TXT_GOLD)
        y += 12
        self.button("a5", (x, y, 92, 20), "+ Rp5 jt", can_r and s["budget"] >= 5, 1, "normal", "coin")
        self.button("a10", (x + 98, y, 92, 20), "+ Rp10 jt", can_r and s["budget"] >= 10, 1, "normal", "coin")
        y += 24
        self.OT("Pulau miskin lebih terbantu.", x, y, TXT_DIM)
        y += 14
        self.rdiv(x, y - 3, w)
        y += 4

        # --- aksi hari ini
        self.pic("star", x, y)
        self.OT("AKSI HARI INI", x + 11, y + 1, TXT_GOLD)
        y += 12
        stok = sum(s["stock"].values())
        value = self.export_value()
        if com:
            kind = MINI_OF[r]
            self.button("prod", (x, y, w, 24), MINI_TITLE[kind], can_r and not s["mini_done"], 1, "go",
                        self.COMM_ICON[com])
            y += 28
            self.OT("Main minigame untuk dapat %s." % com, x, y, TXT)
            y += 12
            bonus = "?" if hid else "+%d%%" % (10 * tier_of(v))
            self.pic("star", x, y - 1)
            self.OT("Bonus hasil: %s" % bonus, x + 11, y, WARN_C)
            y += 12
            ex = s["exploit"][r]
            if r in s["played"] and exploit_mult(ex + 1) > 1.0:
                ic, col, txt = "warn", BAD_C, "Eksploitasi x%.1f (hari ke-%d)" % (exploit_mult(ex + 1), ex + 1)
            elif r not in s["played"] and ex > 0:
                ic, col, txt = "warn", WARN_C, "Jika kerja: x%.1f (hari ke-%d)" % (exploit_mult(ex + 1), ex + 1)
            else:
                ic, col, txt = "check", OK_C, "Eksploitasi: aman"
            self.pic(ic, x, y - 1)
            self.OT(txt, x + 11, y, col)
        else:
            ok = can_r and not s["exported"] and stok > 0
            self.button("export", (x, y, w, 24), "JUAL LANGSUNG", ok, 1, "primary", "coin")
            y += 28
            self.button("nego", (x, y, w, 24), "NEGOSIASI (s.d. +50%)", ok, 1, "go", "star")
            y += 28
            quota = round(self.export_quota() * 100)
            qc = OK_C if quota >= 70 else WARN_C if quota >= 40 else BAD_C
            self.OT("Kuota ekspor: %d%%" % quota, x, y, qc)
            self.OT("Marah %d%%" % s["dissat"], x + w, y, TXT_DIM, 1, "right")

        # --- gudang & status hari ini
        Yg = Pn.y + 224
        self.rdiv(x, Yg - 4, w)
        self.pic("crate", x, Yg + 1)
        self.OT("GUDANG", x + 11, Yg + 2, TXT_GOLD)
        yy = Yg + 14
        for k, c in enumerate(COMMS):
            sx = x + k * 48
            n = s["stock"][c]
            self.rectf(WIN_EDGE, sx, yy, 44, 18)
            self.rectf((20, 26, 60), sx + 1, yy + 1, 42, 16)
            self.pic(self.COMM_ICON[c], sx + 3, yy + 5)
            self.OT(str(n), sx + 40, yy + 6, TXT if n > 0 else TXT_DIM, 1, "right")
        yy += 23
        self.pic("coin", x, yy - 1)
        self.OT("Nilai jual: ~Rp%.1f jt" % value, x + 11, yy, TXT)
        yy += 14
        for k, (lab, done) in enumerate((("Produksi", s["mini_done"]), ("Ekspor", s["exported"]))):
            cx0 = x + k * 96
            self.pic("box", cx0, yy)
            if done:
                self.pic("check", cx0, yy)
            self.OT(lab, cx0 + 12, yy + 1, OK_C if done else TXT_DIM)

        if s["observing"]:
            self.draw_obs(x, y)
        self.button("next", (x, Pn.bottom - 32, w, 24),
                    "HARI BERIKUTNYA >>" if s["day"] < 10 else "AKHIRI JABATAN", can, 1, "danger")

    def draw_game(self):
        s = self.s
        self.bands(0, 0, CW, CH, (14, 18, 46), (6, 8, 24), 10)
        for xx in range(0, CW, 32):
            self.rectf((255, 255, 255, 5), xx, 26, 16, CH - 26)
        self.draw_hud()
        self.draw_map()
        if not s["observing"]:
            txt, left = s["banner"]
            if txt and left > 0:
                rc = pygame.Rect(0, 0, self.font.width(txt) + 32, 18)
                rc.center = (MAP.centerx, MAP.y + 22)
                self.rectf((0, 0, 0, 110), rc.x + 2, rc.y + 2, rc.w, rc.h)
                self.rectf(WIN_EDGE, rc.x - 1, rc.y - 1, rc.w + 2, rc.h + 2)
                self.rectf(GOLD2, rc.x, rc.y, rc.w, rc.h)
                self.rectf((72, 28, 36), rc.x + 1, rc.y + 1, rc.w - 2, rc.h - 2)
                self.pic("warn", rc.x + 6, rc.y + 5)
                self.OT(txt, rc.x + 19, rc.y + 5, TXT)
        self.draw_panel()

    def draw_underlay(self):
        self.draw_game()
        self.ui = []
        self._hov_now = None

    def draw_transition(self):
        tr = self.trans
        t, day = tr["t"], tr["day"]
        FADE = 0.5
        cv = self.cv
        cx = CW / 2
        if t < FADE:
            cv.blit(tr["snap"], (0, 0))
            ov = pygame.Surface((CW, CH))
            ov.fill((0, 0, 0))
            ov.set_alpha(int(t / FADE * 255))
            cv.blit(ov, (0, 0))
            return
        self.bands(0, 0, CW, CH, (14, 18, 46), (4, 5, 16), 10)
        self.rwin((60, 30, 520, 300))
        self.circle(GOLD_D, cx, 70, 22)
        self.circle(GOLD, cx, 70, 19)
        self.circle(WIN_EDGE, cx, 70, 15)
        self.T("RI", cx, 64, GOLD, 2, "center")
        tag = "PELANTIKAN PRESIDEN" if day == 1 else "LAPORAN PAGI ISTANA"
        self.OT(tag, cx, 100, TXT_DIM, 1, "center")
        self.OT("HARI %d / 10" % day, cx, 116, TXT_GOLD, 4, "center")
        self.rectf(GOLD2, cx - 150, 156, 300, 1)
        y = 172
        for ln in self.font.wrap(QUOTES.get(day, "Pimpin nusantara dengan bijak."), 2, 430)[:3]:
            self.OT(ln, cx, y, TXT, 2, "center")
            y += 20
        secs = 10 if day < 5 else 5
        box = pygame.Rect(int(cx) - 170, 250, 340, 28)
        self.rectf(WIN_EDGE, box.x - 1, box.y - 1, box.w + 2, box.h + 2)
        self.rectf((22, 28, 62), *box)
        self.pic("hourglass", box.x + 12, box.y + 10)
        self.OT("Waktu pengamatan: %d detik" % secs, box.x + 30, box.y + 11, BAD_C if day >= 5 else WARN_C)
        if int(self.t * 2) % 2 == 0:
            self.OT("KLIK / SPASI UNTUK LANJUT", cx, 298, TXT_DIM, 1, "center")
        a = 0
        if t < FADE + 0.35:
            a = int(255 * (1 - (t - FADE) / 0.35))
        elif t > self.TRANS_TOTAL - 0.35:
            a = int(255 * (1 - (self.TRANS_TOTAL - t) / 0.35))
        if a > 0:
            ov = pygame.Surface((CW, CH))
            ov.fill((0, 0, 0))
            ov.set_alpha(min(255, a))
            cv.blit(ov, (0, 0))

    def draw_corrupt(self):
        self.draw_underlay()
        self.rectf((0, 0, 0, 170), 0, 0, CW, CH)
        box = pygame.Rect(100, 54, 440, 252)
        cx = CW / 2
        self.rwin(box, "TAWARAN RAHASIA", (96, 28, 44), (40, 10, 22), (120, 24, 30))
        self.pic("warn", cx - 8, box.y + 18, 2)
        y = box.y + 44
        for ln in self.font.wrap(self.s["offer"][0], 2, 380)[:5]:
            self.OT(ln, cx, y, TXT, 2, "center")
            y += 19
        self.OT("Tidak ada yang akan tahu...", cx, box.bottom - 88, TXT_DIM, 1, "center")
        bw = 190
        self.button("accept", (box.x + 20, box.bottom - 70, bw, 30), "TERIMA UANG", True, 1, "danger", "coin")
        self.button("refuse", (box.right - 20 - bw, box.bottom - 70, bw, 30), "TOLAK", True, 1, "go", "check")
        self.OT("Rakyat marah, 1 pulau rusak", box.x + 20 + bw // 2, box.bottom - 32, BAD_C, 1, "center")
        self.OT("Kepercayaan rakyat naik", box.right - 20 - bw // 2, box.bottom - 32, OK_C, 1, "center")

    # ------------------------------------------------------------------
    # DIALOG PULAU BERPISAH
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TUTORIAL "HARI 0"
    # ------------------------------------------------------------------
    TUT_PAGES = [
        ("TUJUAN", "goal", [
            "Kamu mendadak jadi Presiden Indonesia selama 10 hari.",
            "Ada 5 pulau: Sumatera, Jawa, Kalimantan, Sulawesi, Papua.",
            "Jaga KEMAKMURAN tiap pulau tetap tinggi. Angkanya turun sendiri setiap hari.",
            "Di hari ke-10, rata-rata kemakmuran menentukan rating akhirmu."]),
        ("PENGAMATAN & KABUT", "fog", [
            "Tiap hari dimulai dengan masa PENGAMATAN (10 detik, lalu 5 detik mulai hari ke-5). "
            "Hafalkan angka kemakmuran tiap pulau.",
            "Lalu KABUT menutupi 2 pulau. Angkanya jadi '?', tapi pulau itu tetap bisa dibantu.",
            "Klik pulau di peta untuk memilihnya. Aksinya ada di panel kanan.",
            "Tombol LEWATI mempercepat masa pengamatan."]),
        ("BAGIKAN DANA", "budget", [
            "Kas awal: Rp100 juta (lihat bagian atas layar).",
            "Pilih pulau, lalu tekan + Rp5 jt atau + Rp10 jt.",
            "Pulau yang miskin sangat terbantu. Pulau yang sudah makmur hampir tidak.",
            "Bantu dulu pulau yang paling terpuruk, juga yang tertutup kabut."]),
        ("PRODUKSI & EKSPOR", "flow", [
            "Sumatera (Ikan), Kalimantan (Kayu), Sulawesi (Padi), dan Papua (Besi) bisa PRODUKSI lewat "
            "minigame. Hasilnya masuk GUDANG. Satu kali sehari.",
            "Jual isi gudang lewat JAWA: EKSPOR LANGSUNG, atau NEGOSIASI + KUIS agar harganya lebih tinggi. "
            "Uangnya masuk ke kas.",
            "Makin banyak rakyat TIDAK PUAS, makin sedikit barang yang boleh diekspor.",
            "Awas EKSPLOITASI! Produksi di pulau yang sama berhari-hari membuat kemakmurannya cepat turun. "
            "Bergiliranlah antar pulau."]),
        ("BAHAYA", "danger", [
            "BENCANA ACAK bisa menimpa satu pulau tiap malam dan memotong kemakmurannya.",
            "Kadang datang TAWARAN SUAP. Terima = uang pribadi, tapi rakyat marah dan 1 pulau rusak. "
            "Tolak = rakyat makin percaya.",
            "Rakyat yang terlalu marah bisa DEMO (maks. 5 kali). Rakyat yang puas memberi APRESIASI. "
            "Peluangnya tampil di bar atas.",
            "Pulau dengan kemakmuran 0 akan BERPISAH selamanya."]),
        ("RATING & PIALA", "trophy", [
            "Tekan HARI BERIKUTNYA setelah semua aksi selesai. Masa jabatan berakhir setelah hari ke-10.",
            "Rata-rata di atas 65 = BERHASIL, 40 - 65 = BIASA SAJA, di bawah 40 = GAGAL.",
            "Rating dan bencana yang kamu alami memberi PIALA di RAK PIALA (menu utama).",
            "Selamat bertugas, Presiden!"]),
    ]

    def press_start(self):
        """Tombol START di menu: naikkan counter lalu putar animasi masuk istana."""
        self.start_count += 1
        if TUTORIAL_PERSIST:
            save_start_count(self.start_count)
        self.begin_enter()

    def finish_enter(self):
        """Akhir animasi pintu: tutorial hanya pada klik START yang pertama."""
        if self.start_count == 1:
            self.begin_tutorial("game")
        else:
            self.start_game()

    def begin_tutorial(self, nxt):
        self.tut = {"page": 0, "t": 0.0, "next": nxt, "white": nxt == "game"}
        self.state = "tutorial"
        self.shake = 0.0
        self.say("Hari 0: belajar cara memimpin. Tekan ESC untuk melewati.")

    def tut_step(self, d):
        tt = self.tut
        n = len(self.TUT_PAGES)
        if tt["page"] + d >= n:
            self.end_tutorial()
        else:
            tt["page"] = max(0, tt["page"] + d)

    def end_tutorial(self):
        nxt = self.tut["next"]
        self.tut = None
        if nxt == "game":
            self.start_game()
        else:
            self.go_menu()

    def _arrow(self, x, y, d="down", col=None):
        col = col or GOLD
        pts = {"down": [(x - 4, y), (x + 4, y), (x, y + 5)], "right": [(x, y - 4), (x, y + 4), (x + 5, y)]}[d]
        pygame.draw.polygon(self.cv, col, pts)

    def _tut_art(self, kind, bx):
        t, cx = self.t, bx.centerx
        if kind == "goal":
            vals = [62, 48, 70, 38, 55]
            for i, (n, v) in enumerate(zip(REGIONS, vals)):
                y = bx.y + 12 + i * 27
                self.T(n, bx.x + 10, y, CREAMT)
                self.T("%d" % v, bx.right - 10, y, CREAMT, 1, "right")
                self.rectf((60, 56, 50), bx.x + 10, y + 11, bx.w - 20, 6)
                self.rectf(bar_color(v), bx.x + 10, y + 11, (bx.w - 20) * v / 100, 6)
            mx = bx.x + 10 + int((bx.w - 20) * .65)
            self.rectf(GOLD, mx, bx.y + 8, 1, 5 * 27)
            self.T("65", mx, bx.bottom - 18, GOLD, 1, "center")
        elif kind == "fog":
            left = max(1, 10 - int(t % 10))
            self.T("%d" % left, cx, bx.y + 6, AMBER, 3, "center", SHADOW)
            self.T("detik pengamatan", cx, bx.y + 34, CREAMT, 1, "center")
            for k, fog in enumerate((False, True)):
                rc = pygame.Rect(0, 0, 120, 24)
                rc.center = (cx, bx.y + 70 + k * 74)
                self.rectf(BRONZE, rc.x - 1, rc.y - 1, rc.w + 2, rc.h + 2)
                self.rectf((40, 40, 46) if fog else DKPANEL, *rc)
                if fog:
                    self.T("Papua", rc.x + 5, rc.y + 3, (130, 130, 140))
                    self.T("tersembunyi (?)", rc.x + 5, rc.y + 14, (200, 130, 70))
                    self.T("?", cx, rc.y - 20, (150, 150, 165), 3, "center")
                else:
                    self.T("Papua", rc.x + 5, rc.y + 3, CREAMT)
                    self.T("58", rc.right - 5, rc.y + 3, CREAMT, 1, "right")
                    self.rectf((60, 56, 50), rc.x + 5, rc.y + 15, rc.w - 10, 5)
                    self.rectf(bar_color(58), rc.x + 5, rc.y + 15, (rc.w - 10) * .58, 5)
            self._arrow(cx, bx.y + 100, "down")
            self.T("KABUT", cx, bx.y + 108, (150, 150, 165), 1, "center")
        elif kind == "budget":
            self.T("KAS Rp100 jt", cx, bx.y + 8, WHITE, 1, "center")
            b = pygame.Rect(0, 0, 110, 22)
            b.center = (cx, bx.y + 48)
            self.rectf(GOLD2, b.x - 1, b.y - 1, b.w + 2, b.h + 2)
            self.rectf(DKPANEL, *b)
            self.T("+ Rp10 jt", b.centerx, b.y + 7, CREAMT, 1, "center")
            self._arrow(cx, bx.y + 66, "down")
            k = (t * 0.6) % 1.0
            for j, (name, v0, gain) in enumerate((("Terpuruk", 20, 17), ("Makmur", 80, 3))):
                y = bx.y + 90 + j * 52
                v = v0 + gain * min(1, k * 1.6)
                self.T("%s: %d" % (name, v), bx.x + 12, y, CREAMT)
                self.rectf((60, 56, 50), bx.x + 12, y + 12, bx.w - 24, 7)
                self.rectf(bar_color(v), bx.x + 12, y + 12, (bx.w - 24) * v / 100, 7)
                self.T("+%d" % gain, bx.right - 12, y, GREEN, 1, "right")
        elif kind == "flow":
            for i, (c, col) in enumerate((("Ikan", (90, 160, 220)), ("Kayu", (150, 100, 56)),
                                          ("Padi", (200, 180, 70)), ("Besi", (150, 150, 165)))):
                x = bx.x + 12 + (i % 2) * 84
                y = bx.y + 8 + (i // 2) * 24
                self.rectf(col, x, y, 70, 18)
                self.T(c, x + 35, y + 5, WHITE, 1, "center", (0, 0, 0))
            self._arrow(cx, bx.y + 58, "down")
            for k, (label, col) in enumerate((("GUDANG", BRONZE), ("JAWA: EKSPOR", GREEN))):
                y = bx.y + 70 + k * 44
                self.rectf(col, bx.x + 18, y, bx.w - 36, 22)
                self.T(label, cx, y + 7, WHITE, 1, "center", (0, 0, 0))
                if k == 0:
                    self._arrow(cx, y + 25, "down")
            self._arrow(cx, bx.y + 162, "down")
            self.T("KAS +Rp", cx, bx.y + 170, GOLD, 1, "center")
        elif kind == "danger":
            for i, did in enumerate(("banjir", "gempa", "gunung")):
                self.cv.blit(self.emblem(did, 2), (bx.x + 12 + i * 56, bx.y + 6))
            self.T("BENCANA", cx, bx.y + 42, RED2, 1, "center")
            e = pygame.Rect(bx.x + 28, bx.y + 70, 52, 34)
            self.rectf(PARCH, *e)
            pygame.draw.polygon(self.cv, (200, 70, 60), [(e.x, e.y), (e.right, e.y), (e.centerx, e.y + 16)])
            self.T("Rp", e.centerx, e.y + 20, INK, 1, "center")
            self.T("SUAP", e.centerx, e.bottom + 6, AMBER, 1, "center")
            ix, iy = bx.x + 124, bx.y + 86
            pygame.draw.circle(self.cv, (110, 110, 122), (ix, iy), 18)
            for sg in (1, -1):
                pygame.draw.line(self.cv, (214, 44, 44), (ix - 14, iy - 14 * sg), (ix + 14, iy + 14 * sg), 5)
            self.T("BERPISAH", ix, iy + 24, RED2, 1, "center")
            self.T("kemakmuran = 0", ix, iy + 35, CREAMT, 1, "center")
        elif kind == "trophy":
            for i, (tid, lab) in enumerate((("r_berhasil", ">65%"), ("r_biasa", "40-65%"), ("r_gagal", "<40%"))):
                x = bx.x + 34 + i * 60
                self.draw_trophy(x, bx.y + 70, tid, True)
                self.T(lab, x, bx.y + 96, CREAMT, 1, "center")
            self.T("BERHASIL", bx.x + 34, bx.y + 112, GOLD, 1, "center")
            self.T("BIASA", bx.x + 94, bx.y + 112, (205, 127, 50), 1, "center")
            self.T("GAGAL", bx.x + 154, bx.y + 112, (170, 170, 182), 1, "center")
            self.T("RAK PIALA", bx.centerx, bx.y + 146, AMBER, 2, "center", SHADOW)

    def draw_tutorial(self):
        tt = self.tut
        pg = tt["page"]
        title, art, lines = self.TUT_PAGES[pg]
        cx = CW / 2
        self.bands(0, 0, CW, CH, (16, 22, 52), (8, 10, 28), 10)
        for x in range(0, CW, 20):
            self.rectf((255, 255, 255, 6), x, 0, 10, CH)
        self.rectf((8, 10, 26), 0, 0, CW, 70)
        self.rectf(GOLD2, 0, 70, CW, 1)
        self.OT("HARI 0", cx, 8, TXT_GOLD, 4, "center")
        self.OT("%d/%d  -  %s" % (pg + 1, len(self.TUT_PAGES), title), cx, 48, WARN_C, 1, "center")
        bx = pygame.Rect(26, 86, 192, 196)
        self.rectf(GOLD_D, bx.x - 2, bx.y - 2, bx.w + 4, bx.h + 4)
        self.rectf((22, 28, 40), *bx)
        self._tut_art(art, bx)
        tb = pygame.Rect(236, 82, 384, 206)
        self.rwin(tb)
        x, y = tb.x + 16, tb.y + 14
        for src in lines:
            self.rectf(WIN_EDGE, x - 1, y + 1, 5, 5)
            self.rectf(GOLD, x, y + 2, 3, 3)
            for ln in self.font.wrap(src, 1, tb.w - 52):
                self.OT(ln, x + 10, y, TXT)
                y += 12
            y += 7
        for i in range(len(self.TUT_PAGES)):
            self.rectf(GOLD if i == pg else (70, 70, 90), int(cx - 3.5 * len(self.TUT_PAGES) * 2 + i * 14), 300, 8, 4)
        last = pg == len(self.TUT_PAGES) - 1
        self.menu_button("tut_prev", (26, 322, 120, 22), "<< KEMBALI", pg > 0, 1)
        self.menu_button("tut_next", (CW - 26 - 160, 322, 160, 22),
                         ("MULAI BERTUGAS >>" if tt["next"] == "game" else "SELESAI") if last else "LANJUT >>",
                         True, 1, "primary")
        self.T("ESC: LEWATI TUTORIAL", cx, 330, (140, 140, 160), 1, "center")
        if tt["white"] and tt["t"] < 0.9:
            self._R(self.cv, (255, 255, 255, int(255 * (1 - tt["t"] / 0.9))), 0, 0, CW, CH)

    # ------------------------------------------------------------------
    # BENCANA ACAK
    # ------------------------------------------------------------------
    def unlock_trophy(self, tid):
        """Tambah hitungan piala. True jika ini pertama kali diraih."""
        first = self.trophies.get(tid, 0) == 0
        self.trophies[tid] = self.trophies.get(tid, 0) + 1
        save_trophies(self.trophies)
        return first

    def roll_disasters(self):
        s = self.s
        alive = [r for r in REGIONS if r not in s["seceded"]]
        if not alive or random.random() > DISASTER_CHANCE:
            return
        used = set()
        for _ in range(2 if random.random() < DISASTER_DOUBLE else 1):
            combos, weights = [], []
            for did, d in DISASTERS.items():
                if did in used:
                    continue
                for r in alive:
                    w = d["w"] * d["reg"].get(r, 1.0)
                    if did in EXPLOIT_PRONE:
                        w *= 1 + 0.5 * s["exploit"][r]     # eksploitasi membuat alam lebih rentan
                    if w > 0:
                        combos.append((did, r))
                        weights.append(w)
            if not combos:
                return
            did, r = random.choices(combos, weights)[0]
            used.add(did)
            s["pending_events"].append(self.apply_disaster(did, r))

    # ---------------- event rakyat (demo / apresiasi) ----------------
    def mood_odds(self):
        """Peluang (demo, apresiasi) malam ini, dari persentase ketidakpuasan."""
        d = self.s["dissat"]
        p_demo = 0.0
        if d >= DEMO_MIN_DISSAT and self.s.get("demos", 0) < DEMO_MAX:
            p_demo = max(0.05, min(0.9, (d - 40) / 50.0))      # 45% -> 10%, 60% -> 40%, 85%+ -> 90%
        p_apr = max(0.0, min(0.8, (35 - d) / 35.0 * 0.8)) if d <= 30 else 0.0
        return p_demo, p_apr

    def mood_hint(self):
        """(label HUD, warna, kalimat panjang) atau None bila rakyat netral."""
        pd, pa = self.mood_odds()
        n = self.s.get("demos", 0)
        if pd > 0:
            return ("AWAS DEMO %d%% (%d/%d)" % (round(pd * 100), n, DEMO_MAX), (236, 96, 76),
                    "Rakyat resah: peluang DEMO malam ini sekitar %d%% (sudah %d dari maks. %d kali)." %
                    (round(pd * 100), n, DEMO_MAX))
        if n >= DEMO_MAX and self.s["dissat"] >= DEMO_MIN_DISSAT:
            return ("DEMO SUDAH %d/%d" % (n, DEMO_MAX), (170, 150, 120),
                    "Rakyat sudah lelah berdemo: tidak akan ada demo lagi.")
        if pa > 0:
            return ("APRESIASI %d%%" % round(pa * 100), (110, 222, 140),
                    "Rakyat puas: peluang APRESIASI malam ini sekitar %d%%." % round(pa * 100))
        return None

    def roll_people_event(self):
        s = self.s
        alive = [r for r in REGIONS if r not in s["seceded"]]
        if not alive:
            return
        d = s["dissat"]
        pd, pa = self.mood_odds()
        roll = random.random()
        if pd > 0 and roll < pd:
            kind = "demo_besar" if d >= 70 else "demo"
            s["demos"] = s.get("demos", 0) + 1
        elif pa > 0 and roll < pa:
            kind = "pesta" if d <= 12 else "apresiasi"
        else:
            return
        s["pending_events"].append(self.apply_people_event(kind, alive))

    def apply_people_event(self, kind, alive):
        s = self.s
        ev = dict(id=kind, kind="rakyat", region="", dw=0, dbud=0.0, ddis=0, dall=0)
        if kind in ("demo", "demo_besar"):
            w = [2.0 if r == "Jawa" else 1.0 for r in alive]          # ibu kota paling sering jadi pusat demo
            r = random.choices(alive, w)[0]
            lo, hi = (5, 8) if kind == "demo_besar" else (2, 4)
            dw = min(s["welfare"][r], random.randint(lo, hi))
            dbud = min(s["budget"], float(random.randint(lo, hi + 1)))
            ddis = 3 if kind == "demo_besar" else 1
            s["welfare"][r] -= dw
            s["budget"] -= dbud
            s["dissat"] = min(100, s["dissat"] + ddis)
            ev.update(region=r, dw=-dw, dbud=-dbud, ddis=ddis)
        else:
            r = min(alive, key=lambda x: s["welfare"][x]) if kind == "apresiasi" else random.choice(alive)
            dw = random.randint(3, 5)
            dbud = float(random.randint(3, 6) if kind == "apresiasi" else random.randint(6, 10))
            ddis = 2 if kind == "apresiasi" else 3
            s["welfare"][r] = min(100, s["welfare"][r] + dw)
            if kind == "pesta":
                for x in alive:
                    s["welfare"][x] = min(100, s["welfare"][x] + 2)
                ev["dall"] = 2
            s["budget"] += dbud
            s["dissat"] = max(0, s["dissat"] - ddis)
            ev.update(region=r, dw=dw, dbud=dbud, ddis=-ddis)
        return ev

    def apply_disaster(self, did, r):
        s = self.s
        d = DISASTERS[did]
        before = s["welfare"][r]
        s["welfare"][r] = max(0, before - random.randint(*d["dmg"]))
        dmg = before - s["welfare"][r]
        com, lost = ROLE[r][0], 0
        if d["stock"] and com and s["stock"][com] > 0:
            lost = min(s["stock"][com], max(1, int(s["stock"][com] * d["stock"])))
            s["stock"][com] -= lost
        s["dissat"] = min(100, s["dissat"] + d["dissat"])
        s["marks"][r] = did
        return dict(id=did, region=r, dmg=dmg, lost=lost, com=com, new=self.unlock_trophy(did),
                    exploit=did in EXPLOIT_PRONE and s["exploit"][r] >= 2)

    def next_event(self):
        s = self.s
        self.cur_event = s["pending_events"].pop(0)
        if self.cur_event.get("kind") == "rakyat":
            p = PEOPLE[self.cur_event["id"]]
            self.state = "disaster"
            self.shake = 0.8 if self.cur_event["id"] == "demo_besar" else 0.0
            self.audio.play("bad" if p["bad"] else "coin")
            self.say("%s di %s!" % (p["name"].title(), self.cur_event["region"]))
            return
        d = DISASTERS[self.cur_event["id"]]
        self.state = "disaster"
        self.shake = d["shake"]
        self.audio.play("bad")
        self.say("%s melanda %s!" % (d["name"].title(), self.cur_event["region"]))

    def close_event(self):
        self.shake = 0.0
        if self.s["pending_events"]:
            self.next_event()
        else:
            self.state = "main"
            self.say("Hari %d: hafalkan angka tiap pulau sebelum kabut turun!" % self.s["day"])

    # ---------------- gambar ikon bencana & piala ----------------
    def _draw_emblem(self, sf, did, x, y):
        D = pygame.draw

        def R(c, a, b, w, h):
            sf.fill(c, (x + a, y + b, w, h))
        if did == "panas":
            D.circle(sf, (255, 214, 64), (x, y), 3)
            for a, b, w, h in ((-1, -7, 2, 3), (-1, 5, 2, 3), (-7, -1, 3, 2), (5, -1, 3, 2),
                               (-5, -5, 2, 2), (4, -5, 2, 2), (-5, 4, 2, 2), (4, 4, 2, 2)):
                R((255, 160, 40), a, b, w, h)
        elif did == "banjir":
            R((90, 70, 54), -7, -7, 4, 6)                         # atap rumah yang terendam
            D.polygon(sf, (170, 60, 50), [(x - 8, y - 6), (x - 5, y - 9), (x - 2, y - 6)])
            for k, yy in enumerate((-2, 2, 6)):
                for a in range(-7, 7, 4):
                    R((70, 140, 230), a + (k % 2) * 2, yy + (1 if (a // 4) % 2 else 0), 4, 2)
                R((170, 214, 255), -6 + k * 4, yy, 2, 1)
        elif did == "gunung":
            D.polygon(sf, (122, 76, 56), [(x - 7, y + 6), (x, y - 4), (x + 7, y + 6)])
            R((255, 128, 40), -2, -4, 4, 2)
            R((255, 206, 90), -1, -4, 2, 1)
            R((96, 96, 108), -1, -7, 2, 2)
        elif did == "kekeringan":
            R((176, 124, 56), -7, -1, 14, 7)
            for a, b, c, d2 in ((-4, -1, -2, 3), (1, -1, 3, 3), (-2, 3, -4, 6)):
                D.line(sf, (80, 50, 24), (x + a, y + b), (x + c, y + d2))
            D.circle(sf, (255, 214, 64), (x + 4, y - 4), 2)
        elif did == "gempa":
            pts = [(x - 7, y), (x - 3, y - 5), (x, y + 4), (x + 3, y - 4), (x + 7, y)]
            for a, b in zip(pts, pts[1:]):
                D.line(sf, (204, 56, 48), a, b, 2)
        elif did == "longsor":
            R((140, 98, 56), -7, 2, 6, 4)
            R((110, 76, 44), -1, -1, 6, 5)
            R((150, 110, 66), 3, 3, 4, 4)
            R((96, 64, 36), -4, -4, 4, 3)
        elif did == "tsunami":
            D.circle(sf, (40, 110, 210), (x, y + 1), 6)
            sf.fill((0, 0, 0, 0), (x + 1, y - 2, 7, 6))
            R((40, 110, 210), -7, 3, 14, 4)
            R((255, 255, 255), -5, -3, 3, 1)
            R((255, 255, 255), -3, -4, 2, 1)
        elif did == "kebakaran":
            D.polygon(sf, (255, 110, 30), [(x - 5, y + 7), (x - 5, y + 1), (x - 2, y - 2), (x - 1, y - 7),
                                           (x + 2, y - 3), (x + 5, y + 1), (x + 5, y + 7)])
            D.polygon(sf, (255, 214, 70), [(x - 2, y + 7), (x - 2, y + 3), (x, y), (x + 2, y + 3), (x + 2, y + 7)])
        elif did == "badai":
            D.circle(sf, (150, 156, 172), (x - 3, y - 3), 4)
            D.circle(sf, (150, 156, 172), (x + 2, y - 3), 4)
            R((150, 156, 172), -6, -3, 12, 3)
            D.polygon(sf, (255, 220, 60), [(x, y - 1), (x - 3, y + 4), (x, y + 4), (x - 1, y + 8), (x + 4, y + 2), (x + 1, y + 2)])
        elif did == "r_berhasil":
            pts = []
            for i in range(10):
                a = -math.pi / 2 + i * math.pi / 5
                rr = 7 if i % 2 == 0 else 3
                pts.append((x + rr * math.cos(a), y + rr * math.sin(a)))
            D.polygon(sf, (255, 248, 190), pts)
        elif did == "r_biasa":
            R((90, 60, 24), -6, -3, 12, 3)
            R((90, 60, 24), -6, 2, 12, 3)
        elif did == "r_gagal":
            D.line(sf, (90, 20, 24), (x - 6, y - 6), (x + 6, y + 6), 3)
            D.line(sf, (90, 20, 24), (x - 6, y + 6), (x + 6, y - 6), 3)

    def emblem(self, did, k=1):
        key = (did, k)
        if key not in self._emb:
            base = pygame.Surface((16, 16), pygame.SRCALPHA)
            self._draw_emblem(base, did, 8, 8)
            self._emb[key] = base if k == 1 else pygame.transform.scale(base, (16 * k, 16 * k))
        return self._emb[key]

    def draw_trophy(self, cx, cy, tid, got=True):
        R = lambda c, x, y, w, h: self._R(self.cv, c, x, y, w, h)
        if not got:
            main, dark, light = (58, 52, 62), (36, 32, 40), (74, 68, 80)
        elif tid == "r_berhasil":
            main, dark, light = (255, 212, 40), (176, 126, 18), (255, 244, 170)
        elif tid == "r_biasa":
            main, dark, light = (205, 127, 50), (130, 78, 28), (236, 178, 110)
        elif tid == "r_gagal":
            main, dark, light = (150, 150, 162), (92, 92, 104), (200, 200, 210)
        else:
            main, dark, light = (196, 204, 218), (116, 126, 148), (240, 244, 252)
        R(dark, cx - 10, cy + 12, 20, 4)                         # alas
        R(main, cx - 8, cy + 10, 16, 3)
        R(dark, cx - 3, cy + 3, 6, 8)                            # batang
        R(main, cx - 2, cy + 3, 4, 8)
        R(dark, cx - 11, cy - 15, 22, 2)                         # mangkuk
        R(main, cx - 10, cy - 14, 20, 4)
        R(main, cx - 9, cy - 10, 18, 6)
        R(main, cx - 7, cy - 4, 14, 4)
        R(main, cx - 4, cy, 8, 3)
        R(dark, cx + 5, cy - 9, 4, 11)                           # bayangan kanan
        R(light, cx - 8, cy - 12, 2, 9)                          # kilau kiri
        for sg in (-1, 1):                                       # telinga cangkir
            hx = cx - 15 if sg < 0 else cx + 11
            R(main, hx, cy - 12, 4, 2)
            R(main, hx + (0 if sg < 0 else 2), cy - 12, 2, 7)
            R(main, hx, cy - 6, 4, 2)
        if got:
            self.cv.blit(self.emblem(tid), (cx - 8, cy - 14))
            if tid == "r_gagal":
                R((70, 70, 82), cx - 1, cy - 14, 1, 6)           # retak
                R((70, 70, 82), cx, cy - 9, 1, 4)
            if int(self.t * 1.5 + cx * 0.05) % 5 == 0:
                R((255, 255, 255), cx - 8, cy - 13, 2, 2)
        else:
            self.T("?", cx, cy - 12, (96, 90, 108), 2, "center")

    # ---------------- popup bencana ----------------
    def people_art(self, kind):
        """Ilustrasi pixel kerumunan (16x16 diperbesar 4x)."""
        cache = self.__dict__.setdefault("_people_cache", {})
        if kind in cache:
            return cache[kind]
        t = pygame.Surface((16, 16), pygame.SRCALPHA)
        skin = (224, 172, 105)
        cols = [(192, 57, 43), (41, 128, 185), (46, 160, 90), (142, 68, 173)]
        bad = PEOPLE[kind]["bad"]
        xs = (1, 5, 9, 13) if kind in ("demo_besar", "pesta") else (2, 7, 12)
        if kind == "demo_besar":
            t.fill((90, 90, 100), (0, 0, 16, 2))                    # asap
            t.fill((255, 140, 30), (0, 13, 2, 2))                   # api unggun
            t.fill((255, 214, 64), (0, 14, 1, 1))
        for i, x in enumerate(xs):
            c = cols[i % 4]
            t.fill(skin, (x, 9, 2, 2))
            t.fill(c, (x, 11, 2, 4))
            t.fill((30, 30, 40), (x, 15, 2, 1))
            if i % 2 == 1 and x + 2 < 16:
                t.fill(skin, (x + 2, 8, 1, 2))                      # tangan terangkat
        if bad:
            x = xs[1]
            t.fill((120, 90, 50), (x, 4, 1, 5))
            t.fill((236, 226, 196), (x - 2, 1, 6, 4))
            t.fill((192, 57, 43), (x - 1, 2, 4, 1))
        else:
            for px, py in ((1, 0), (3, 0), (0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (1, 2), (2, 2), (3, 2), (2, 3)):
                t.fill((226, 60, 80), (5 + px, 1 + py, 1, 1))       # hati
            if kind == "pesta":
                for px, py, c in ((1, 2, (255, 214, 64)), (13, 3, (90, 200, 255)), (3, 6, (255, 120, 200)),
                                  (11, 1, (120, 230, 120)), (14, 7, (255, 214, 64)), (0, 5, (90, 200, 255))):
                    t.fill(c, (px, py, 1, 1))
        art = pygame.transform.scale(t, (64, 64))
        cache[kind] = art
        return art

    def draw_people_event(self):
        ev = self.cur_event
        p = PEOPLE[ev["id"]]
        self.draw_underlay()
        self.rectf((0, 0, 0, 170), 0, 0, CW, CH)
        sign = "-" if ev["dw"] < 0 else "+"
        rows = [("star", "%s: kemakmuran %s%d" % (ev["region"], sign, abs(ev["dw"])),
                 BAD_C if p["bad"] else OK_C, True)]
        if ev["dall"]:
            rows.append(("star", "Semua pulau: kemakmuran +%d" % ev["dall"], OK_C, False))
        if ev["dbud"]:
            rows.append(("coin", "Kas %sRp%d juta" % ("-" if ev["dbud"] < 0 else "+", abs(ev["dbud"])),
                         BAD_C if ev["dbud"] < 0 else OK_C, False))
        if ev["ddis"]:
            rows.append(("heart", "Ketidakpuasan %s%d%%" % ("+" if ev["ddis"] > 0 else "-", abs(ev["ddis"])),
                         BAD_C if ev["ddis"] > 0 else OK_C, False))
        tip = ("Bantu pulau yang terpuruk agar rakyat tenang." if p["bad"] else
               "Pertahankan! Rakyat puas = kuota ekspor lebih besar.")
        self.draw_event_card(p["name"], p["color"], self.people_art(ev["id"]),
                             p["text"].format(r=ev["region"]), rows, tip,
                             WARN_C if p["bad"] else OK_C, None, len(self.s["pending_events"]))

    def draw_disaster(self):
        ev = self.cur_event
        if ev.get("kind") == "rakyat":
            self.draw_people_event()
            return
        d = DISASTERS[ev["id"]]
        self.draw_underlay()
        self.rectf((0, 0, 0, 170), 0, 0, CW, CH)
        rows = [("star", "%s: kemakmuran -%.0f" % (ev["region"], ev["dmg"]), BAD_C, True)]
        if ev["lost"]:
            rows.append(("crate", "Hasil rusak: -%d %s" % (ev["lost"], ev["com"]), TXT, False))
        rows.append(("heart", "Rakyat marah +%d%%" % d["dissat"], WARN_C, False))
        if ev["exploit"]:
            rows.append(("warn", "Pulau yang dieksploitasi lebih rentan.", WARN_C, False))
        badge = TROPHY_BY_ID[ev["id"]][1].upper() if ev["new"] else None
        self.draw_event_card(d["name"], d["color"], self.emblem(ev["id"], 4),
                             d["text"].format(r=ev["region"]), rows, "", TXT_DIM, badge,
                             len(self.s["pending_events"]))

    # ---------------- rak piala ----------------
    def draw_trophies(self):
        cv, R = self.cv, (lambda c, x, y, w, h: self._R(self.cv, c, x, y, w, h))
        cv.fill((46, 30, 38))
        for x in range(0, CW, 16):
            R((52, 35, 44), x, 0, 8, CH)
        R((28, 18, 24), 0, 0, CW, 34)
        R(GOLD2, 0, 34, CW, 1)
        self.T("RAK PIALA", CW / 2, 8, GOLD, 3, "center", SHADOW)
        got_n = sum(1 for t in TROPHIES if self.trophies.get(t[0], 0) > 0)
        self.T("%d/%d" % (got_n, len(TROPHIES)), CW - 10, 14, CREAMT, 1, "right")
        ids = [t[0] for t in TROPHIES if t[0] in DISASTERS]
        rows = [(72, ["r_berhasil", "r_biasa", "r_gagal"], [160, 320, 480], "PIALA JABATAN (RATING AKHIR)"),
                (158, ids[:5], [70, 195, 320, 445, 570], "PIALA BENCANA"),
                (244, ids[5:], [133, 258, 383, 508], None)]
        hover = None
        for cy, tids, xs, head in rows:
            if head:
                self.T(head, 28, cy - 34, AMBER)
            R((70, 44, 26), 24, cy + 52, CW - 48, 3)             # papan rak
            R((122, 80, 46), 24, cy + 46, CW - 48, 6)
            R((176, 122, 72), 24, cy + 46, CW - 48, 1)
            for tid, x in zip(tids, xs):
                got = self.trophies.get(tid, 0) > 0
                hr = pygame.Rect(x - 56, cy - 20, 112, 64)
                if hr.collidepoint(self.mpos):
                    hover = tid
                    R((255, 214, 90, 36), hr.x, hr.y, hr.w, hr.h)
                self.draw_trophy(x, cy, tid, got)
                name = TROPHY_BY_ID[tid][1] if got else "???"
                for k, ln in enumerate(self.font.wrap(name, 1, 108)[:2]):
                    self.T(ln, x, cy + 20 + k * 11, CREAMT if got else (110, 100, 120), 1, "center", (0, 0, 0))
        ib = pygame.Rect(40, 304, 560, 28)
        self.rectf(GOLD_D, ib.x - 1, ib.y - 1, ib.w + 2, ib.h + 2)
        self.rectf((24, 16, 22), *ib)
        if hover:
            t = TROPHY_BY_ID[hover]
            n = self.trophies.get(hover, 0)
            self.T(t[1].upper() if n else "??? (BELUM DIDAPAT)", ib.x + 8, ib.y + 4, GOLD if n else (150, 140, 160))
            self.T(t[2] + ("   Diraih %dx." % n if n else ""), ib.x + 8, ib.y + 16, CREAMT)
        else:
            self.T("Arahkan kursor ke piala untuk melihat keterangannya.", ib.centerx, ib.y + 10, (150, 140, 160), 1, "center")
        self.menu_button("back", (CW // 2 - 60, 338, 120, 18), "KEMBALI", True, 1, "primary")

    def draw_secede(self):
        self.rectf((0, 0, 0, 170), 0, 0, CW, CH)
        box = pygame.Rect(110, 78, 420, 196)
        cx = CW / 2
        self.rwin(box, "KABAR BURUK", (96, 28, 44), (40, 10, 22), (120, 24, 30))
        y = box.y + 40
        for ln in self.font.wrap("%s memilih keluar dari Indonesia." % self.secede_name, 2, 360):
            self.OT(ln, cx, y, TXT, 2, "center")
            y += 20
        self.OT("Rakyatnya sudah tidak percaya lagi.", cx, y + 8, TXT_DIM, 1, "center")
        self.OT("Pulau ini tidak bisa dibantu lagi.", cx, y + 21, TXT_DIM, 1, "center")
        self.button("secede_ok", (cx - 70, box.bottom - 40, 140, 26), "TUTUP", True, 2, "primary")

    # ------------------------------------------------------------------
    # CUTSCENE ENDING: ruang tamu -> koran -> THE END -> credit roll
    # ------------------------------------------------------------------
    PW, PH, PX, PY = 568, 326, 36, 4        # ukuran & posisi lembar koran di layar
    ROOM_T = 8.2        # lama adegan ruang tamu (termasuk zoom)
    ZOOM_AT = 5.6
    ZOOM_DUR = 1.9
    FRONT_T = 3.8       # halaman depan terbaca sebelum otomatis dibalik
    FLIP_T = 1.7        # lama animasi membalik halaman
    HOLD = 2.8          # "THE END" diam sebelum credit mulai naik
    SLIDE_T = 4.6       # lama tiap gambar rekap
    XFADE = 1.0
    NEWS = (320, 172)   # pusat koran di adegan ruang tamu
    NEWS_BG = (230, 220, 192)
    INK_N = (32, 28, 26)
    INK_S = (88, 80, 70)
    RULE = (70, 62, 54)

    # ---------------- utilitas ----------------
    @staticmethod
    def _lerp(a, b, t):
        return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

    @staticmethod
    def _ease(p):
        p = max(0.0, min(1.0, p))
        return p * p * (3 - 2 * p)

    def render_to(self, fn, size=(CW, CH)):
        """Jalankan fungsi gambar pada Surface terpisah (self.cv dialihkan sementara)."""
        surf = pygame.Surface(size).convert()
        old = self.cv
        self.cv = surf
        try:
            fn()
        finally:
            self.cv = old
        return surf

    def fade(self, alpha):
        if alpha <= 0:
            return
        ov = pygame.Surface((CW, CH))
        ov.fill((0, 0, 0))
        ov.set_alpha(min(255, int(alpha)))
        self.cv.blit(ov, (0, 0))

    # ---------------- alur ----------------
    def start_ending(self):
        self.credits_preview = False
        e = self.s.get("end")
        self.last_trophy = "r_" + e["rating"] if e else None
        self.last_trophy_new = self.unlock_trophy(self.last_trophy) if self.last_trophy else False
        self.state = "ending"
        self.end_stage = "room"
        self.end_t = 0.0
        self.page_front = self.render_to(self.draw_page_front, (self.PW, self.PH))
        self.page_stats = self.render_to(self.draw_page_stats, (self.PW, self.PH))
        self._front_view = None
        self.slides = []
        self.say("Beberapa hari setelah masa jabatan berakhir, di sebuah ruang tamu di Indonesia...")

    def preview_credits(self):
        """Kredit dari menu utama: gambar rekap memakai kondisi awal permainan."""
        self.s = new_state()
        self.s["end"] = self.compute_end()
        self.mini = None
        self.credits_preview = True
        self.last_trophy = None
        self.state = "ending"
        self.end_goto("credits")

    def end_goto(self, stage):
        self.end_stage = stage
        self.end_t = 0.0
        e = self.s["end"]
        if stage == "front":
            self.say("Halaman depan koran pagi ini membahas presiden mereka.")
        elif stage == "flip":
            self.audio.play("page")
            self.say("Pembaca membalik lembaran koran...")
        elif stage == "stats":
            self.audio.play("fanfare" if e["win"] else "bad")
            self.say("Halaman 2: rapor lengkap dan status tiap pulau selama sepuluh hari kepemimpinan Anda.")
        elif stage == "credits":
            self.start_credits()
            self.audio.play("fanfare")
            self.say("Terima kasih telah memimpin Indonesia.")
        elif stage == "final":
            self.say("Indonesia menunggumu kembali.")

    def update_ending(self):
        st, t = self.end_stage, self.end_t
        if st == "room" and t >= self.ROOM_T:
            self.end_goto("front")
        elif st == "front" and t >= self.FRONT_T:
            self.end_goto("flip")
        elif st == "flip" and t >= self.FLIP_T:
            self.end_goto("stats")
        elif st == "credits" and t >= self.cred_total:
            if self.credits_preview:
                self.go_menu()
            else:
                self.end_goto("final")

    # ---------------- ruang tamu ----------------
    def draw_room(self):
        f = self.rectf
        t = self.t
        f((44, 34, 59), 0, 0, CW, CH)
        for i in range(0, CW, 40):               # wallpaper bergaris
            f((50, 39, 66), i, 0, 18, 232)
        f((60, 46, 78), 0, 200, CW, 36)          # wainscoting
        for i in range(0, CW, 48):
            f((52, 40, 68), i + 4, 204, 40, 28)
        f((26, 16, 38), 0, 232, CW, 6)
        f((74, 46, 43), 0, 238, CW, 122)         # lantai kayu
        for i in range(0, CW, 40):
            f((59, 35, 32), i, 238, 2, 122)
        for j in range(0, 122, 24):
            f((66, 40, 37), 0, 250 + j, CW, 1)
        # jendela pagi + tirai
        wx, wy, ww, wh = 46, 40, 120, 130
        f((243, 156, 18), wx, wy, ww, wh)
        f((241, 196, 15), wx, wy + 40, ww, 90)
        f((230, 126, 34), wx, wy + 76, ww, 54)
        for bx, by, bw, bh in ((8, 58, 22, 72), (34, 38, 26, 92), (64, 66, 18, 64), (86, 48, 30, 82)):
            f((44, 62, 80), wx + bx, wy + by, bw, bh)
        fr = (26, 16, 38)
        f(fr, wx - 4, wy - 4, ww + 8, 6)
        f(fr, wx - 4, wy + wh, ww + 8, 6)
        f(fr, wx - 4, wy, 6, wh)
        f(fr, wx + ww, wy, 6, wh)
        f(fr, wx + ww / 2 - 2, wy, 4, wh)
        f(fr, wx, wy + wh / 2 - 2, ww, 4)
        for cx_, side in ((wx - 22, 1), (wx + ww + 4, -1)):
            f((110, 24, 36), cx_, wy - 12, 24, wh + 28)
            for k in range(0, 24, 6):
                f((88, 16, 28), cx_ + k, wy - 12, 2, wh + 28)
        f((150, 120, 60), wx - 26, wy - 16, ww + 52, 4)
        self.polygon(rgba(255, 230, 150, .13), [(wx + ww, wy), (wx + ww + 170, 360), (wx + 10, 360), (wx, wy + wh)])
        # bingkai foto & rak buku & jam
        f(GOLD2, 206, 56, 40, 32)
        f((59, 89, 152), 210, 60, 32, 24)
        f(GOLD2, 254, 72, 30, 24)
        f((142, 68, 173), 258, 76, 22, 16)
        f((60, 38, 26), 452, 104, 96, 130)
        f((36, 22, 16), 456, 108, 88, 122)
        cols = [(176, 56, 48), (46, 120, 160), (200, 160, 60), (70, 140, 90), (140, 90, 160), (220, 220, 210)]
        for row in range(3):
            ry = 108 + row * 41
            f((60, 38, 26), 456, ry + 38, 88, 4)
            xx = 458
            k = 0
            while xx < 540:
                bw = 5 + (k * 3) % 5
                bh = 24 + (k * 7) % 12
                f(cols[(k + row) % 6], xx, ry + 38 - bh, bw, bh)
                xx += bw + 1
                k += 1
        self.circle((236, 240, 241), 500, 72, 15)
        self.circle((44, 62, 80), 500, 72, 12)
        pygame.draw.line(self.cv, (241, 196, 15), (500, 72), (500, 63), 2)
        pygame.draw.line(self.cv, (241, 196, 15), (500, 72), (493, 72), 2)
        # karpet
        pygame.draw.ellipse(self.cv, (123, 17, 19), (160, 286, 340, 62))
        pygame.draw.ellipse(self.cv, (88, 10, 12), (180, 294, 300, 46))
        pygame.draw.ellipse(self.cv, (200, 160, 60), (200, 302, 260, 30), 1)
        # kucing tidur di karpet
        f((70, 60, 66), 226, 308, 36, 12)
        self.circle((70, 60, 66), 224, 312, 8)
        self.polygon((70, 60, 66), [(218, 306), (221, 299), (225, 305)])
        self.polygon((70, 60, 66), [(226, 305), (229, 299), (232, 306)])
        lift = int(math.sin(t * 1.6) * 1.2)
        f((70, 60, 66), 226, 306 + lift, 36, 4)
        pygame.draw.line(self.cv, (70, 60, 66), (262, 316), (276 + int(math.sin(t * 2) * 3), 322), 3)
        # tanaman
        f((176, 90, 56), 34, 232, 28, 26)
        for cx_, cy_, r_ in ((42, 222, 9), (54, 218, 10), (48, 208, 8), (60, 228, 7)):
            self.circle((46, 140, 70), cx_, cy_, r_)
        # kursi
        f((92, 28, 40), 238, 190, 30, 70)
        f((92, 28, 40), 372, 190, 30, 70)
        f((110, 38, 52), 252, 118, 136, 130)
        f((140, 52, 66), 262, 128, 116, 96)
        f((110, 38, 52), 252, 232, 136, 30)
        f((60, 24, 30), 246, 262, 12, 12)
        f((60, 24, 30), 382, 262, 12, 12)
        # penonton
        breathe = int(math.sin(t * 1.4) * 1)
        f((41, 128, 185), 290, 176 + breathe, 60, 68)
        f((44, 62, 80), 290, 238, 60, 20)
        f((224, 172, 105), 302, 104 + breathe, 36, 30)
        f((30, 24, 30), 300, 98 + breathe, 40, 12)
        f((26, 26, 32), 306, 114 + breathe, 12, 7)
        f((26, 26, 32), 322, 114 + breathe, 12, 7)
        f((150, 200, 240), 308, 116 + breathe, 8, 3)
        f((150, 200, 240), 324, 116 + breathe, 8, 3)
        # koran yang dibaca
        sway = int(math.sin(t * 2) * 1.2)
        px, py = 270, 128 + sway
        f((24, 20, 20), px + 4, py + 4, 100, 92)
        f(self.NEWS_BG, px, py, 100, 92)
        f((214, 204, 176), px + 50, py, 50, 92)
        self.T("KORAN NUSANTARA", px + 50, py + 4, self.INK_N, 1, "center")
        f(self.INK_N, px + 6, py + 16, 88, 2)
        f(self.INK_N, px + 6, py + 19, 88, 1)
        f(self.INK_N, px + 8, py + 24, 84, 5)
        for k in range(7):
            f((130, 120, 104), px + 6, py + 34 + k * 8, 40 if k < 3 else 88, 2)
        f((110, 104, 94), px + 52, py + 34, 40, 20)
        f((224, 172, 105), px - 8, py + 46, 10, 10)
        f((224, 172, 105), px + 98, py + 46, 10, 10)
        # meja kopi + uap
        f((74, 44, 17), 424, 252, 128, 10)
        f((45, 26, 10), 432, 262, 8, 28)
        f((45, 26, 10), 536, 262, 8, 28)
        f((236, 236, 240), 474, 240, 12, 12)
        f((90, 50, 30), 475, 241, 10, 3)
        for k in range(3):
            rise = (t * 9 + k * 4) % 14
            self.rectf((255, 255, 255, 110), 477 + math.sin(t * 3 + k) * 2, 236 - rise, 2, 3)
        # lampu berdiri
        f((127, 140, 141), 588, 112, 3, 128)
        f((241, 196, 15), 578, 96, 24, 18)
        self.circle(rgba(255, 230, 150, .10), 590, 108, 52)
        self.polygon(rgba(255, 230, 150, .06), [(580, 114), (600, 114), (640, 250), (540, 250)])
        # vinyet ruangan
        self.cv.blit(self.get_cvig(), (0, 0))
        self.draw_particles((255, 220, 130))

    # ---------------- halaman koran ----------------
    def paper_base(self):
        W, H = self.PW, self.PH
        self.rectf(self.NEWS_BG, 0, 0, W, H)
        rng = random.Random(11)
        for _ in range(520):
            sh = rng.randint(-24, -8)
            self.rectf((230 + sh, 220 + sh, 192 + sh), rng.randrange(W), rng.randrange(H), rng.randint(1, 2), 1)

    def paper_finish(self):
        W, H = self.PW, self.PH
        for i in range(9):
            self.frame((150, 120, 60, 30 - 3 * i), (i, i, W - 2 * i, H - 2 * i), 1)
        self.rectf((0, 0, 0, 18), W // 2 - 1, 0, 1, H)
        self.rectf((255, 255, 255, 45), W // 2, 0, 1, H)
        self.rectf((0, 0, 0, 14), 0, H // 2, W, 1)
        self.rectf((255, 255, 255, 36), 0, H // 2 + 1, W, 1)

    def story(self):
        s, e = self.s, self.s["end"]
        n, thr = len(e["pros"]), e["thr"]
        alive = [r for r in REGIONS if r not in s["seceded"]]
        best = max(alive, key=lambda r: s["welfare"][r]) if alive else REGIONS[0]
        worst = min(REGIONS, key=lambda r: s["welfare"][r])
        P = ["INDONESIA - Sepuluh hari masa jabatan presiden resmi berakhir hari ini. Dari lima pulau di nusantara, "
             "%d dinyatakan makmur karena melampaui ambang %d%%." % (n, thr)]
        if e["sec"]:
            P.append("Kabar paling mengejutkan datang dari %s. Warga di sana memilih berpisah dari Indonesia dan "
                     "mengibarkan bendera sendiri." % " dan ".join(e["sec"]))
        if s["corrupt"] >= 2:
            P.append("Sumber istana menyebut amplop 'uang terima kasih' berkali-kali mampir ke meja presiden. "
                     "Rp%d juta dikabarkan berpindah ke kantong pribadi." % s["personal"])
        elif s["corrupt"] == 1:
            P.append("Sebuah amplop misterius dikabarkan sempat mampir ke meja presiden. Rp%d juta disebut "
                     "masuk ke kantong pribadi." % s["personal"])
        else:
            P.append("Presiden tercatat menolak seluruh tawaran 'uang terima kasih'. Netizen masih curiga "
                     "ini hanya prank.")
        P.append("Pelabuhan di Jawa mencatat total ekspor Rp%.0f juta, sementara sisa kas negara tinggal "
                 "Rp%.0f juta." % (s["export_total"], s["budget"]))
        if s["dissat"] > 60:
            P.append("Gelombang demonstrasi memenuhi jalanan ibu kota. %d%% warga mengaku tidak puas." % s["dissat"])
        elif s["dissat"] <= 30:
            P.append("Survei terbaru menunjukkan hanya %d%% warga yang tidak puas, salah satu yang terendah." % s["dissat"])
        else:
            P.append("Survei menunjukkan %d%% warga masih merasa tidak puas dengan arah pemerintahan." % s["dissat"])
        P.append("Pulau %s menjadi yang paling sejahtera dengan skor %d, sedangkan %s tertinggal di angka %d." %
                 (best, s["welfare"][best], worst, s["welfare"][worst]))
        P.append("Pengamat menilai sepuluh hari ini sebagai awal kebangkitan Indonesia." if e["win"] else
                 "Pengamat menilai sepuluh hari ini meninggalkan banyak pekerjaan rumah bagi pemerintah berikutnya.")
        return P

    def flow_text(self, paras, cols, scale=1):
        """Alirkan paragraf ke beberapa kolom; paragraf terakhir dibuang jika tidak muat."""
        lh = 10 * scale
        width = cols[0][3]
        cap = sum((y1 - y0) // lh for _x, y0, y1, _w in cols) - 1
        paras = list(paras)
        while paras:
            need = sum(len(self.font.wrap(p, scale, width)) for p in paras) + len(paras) - 1
            if need <= cap or len(paras) == 1:
                break
            paras.pop()
        lines = []
        for i, p in enumerate(paras):
            lines += self.font.wrap(p, scale, width)
            if i < len(paras) - 1:
                lines.append("")
        li = 0
        for x, y0, y1, _w in cols:
            y = y0
            while y + lh <= y1 + 1 and li < len(lines):
                if lines[li] == "" and y == y0:
                    li += 1
                    continue
                if lines[li]:
                    self.T(lines[li], x, y, self.INK_N, scale)
                y += lh
                li += 1

    def draw_photo(self, x, y, w, h, win):
        f = self.rectf
        f((176, 174, 164), x, y, w, h)
        f((120, 116, 108), x, y + h - 22, w, 22)
        f((96, 92, 86), x + 10, y + h - 50, w - 20, 28)
        self.polygon((84, 80, 74), [(x + 6, y + h - 50), (x + w // 2, y + h - 66), (x + w - 6, y + h - 50)])
        for i in range(6):
            f((78, 74, 70), x + 16 + i * 26, y + h - 48, 7, 26)
        dark = (40, 38, 36)
        if win:
            for i in range(9):
                px_ = x + 12 + i * 18
                f(dark, px_, y + h - 16, 8, 16)
                self.circle(dark, px_ + 4, y + h - 20, 4)
                pygame.draw.line(self.cv, dark, (px_ + 1, y + h - 14), (px_ - 3, y + h - 28), 2)
                pygame.draw.line(self.cv, dark, (px_ + 7, y + h - 14), (px_ + 11, y + h - 28), 2)
        else:
            px_ = x + w // 2 + 22
            f(dark, px_, y + h - 30, 9, 24)
            self.circle(dark, px_ + 4, y + h - 34, 5)
            f(dark, px_ + 10, y + h - 14, 12, 9)
            f(dark, px_ + 2, y + h - 6, 3, 6)
            f(dark, px_ + 6, y + h - 6, 3, 6)
        for yy in range(y, y + h, 3):
            for xx in range(x + ((yy // 3) % 2) * 2, x + w, 4):
                f((0, 0, 0, 34), xx, yy, 1, 1)
        self.frame(self.INK_N, (x, y, w, h), 1)

    def draw_page_front(self):
        s, e = self.s, self.s["end"]
        W, H = self.PW, self.PH
        cx = W // 2
        T, f = self.T, self.rectf
        self.paper_base()
        self.frame(self.RULE, (10, 8, 112, 30), 1)
        T("CUACA: BERKABUT", 66, 14, self.INK_S, 1, "center")
        T("Rakyat menunggu", 66, 25, self.INK_S, 1, "center")
        self.frame(self.RULE, (W - 122, 8, 112, 30), 1)
        T("HARGA ECERAN", W - 66, 14, self.INK_S, 1, "center")
        T("Rp 3.000", W - 66, 25, self.INK_S, 1, "center")
        T("KORAN NUSANTARA", cx, 10, self.INK_N, 3, "center")
        f(self.INK_N, 10, 39, W - 20, 3)
        f(self.INK_N, 10, 44, W - 20, 1)
        T("EDISI KHUSUS * HARI KE-10 MASA JABATAN * TAHUN I NO. 10", cx, 48, self.INK_S, 1, "center")
        f(self.RULE, 10, 58, W - 20, 1)
        hs = 3
        lines = self.font.wrap(e["head"], 3, W - 28)
        if len(lines) > 2:
            hs = 2
            lines = self.font.wrap(e["head"], 2, W - 28)
        y = 64
        for ln in lines[:3]:
            T(ln, cx, y, self.INK_N, hs, "center")
            y += 26 if hs == 3 else 19
        y += 2
        f(self.INK_N, 10, y, W - 20, 2)
        y += 6
        for ln in self.font.wrap(e["subs"][0] if e["subs"] else "", 1, W - 80)[:2]:
            T(ln, cx, y, self.INK_S, 1, "center")
            y += 10
        y += 4
        f(self.RULE, 10, y, W - 20, 1)
        y += 7
        ycols, ybot = y, H - 22
        colw = 174
        xs = [10, 10 + colw + 12, 10 + 2 * (colw + 12)]
        self.draw_photo(xs[0], ycols, colw, 78, e["win"])
        cap = "Presiden Indonesia usai sepuluh hari masa jabatan. (Foto: arsip Koran Nusantara)"
        cy = ycols + 82
        for ln in self.font.wrap(cap, 1, colw)[:3]:
            T(ln, xs[0], cy, self.INK_S, 1)
            cy += 10
        cy += 5
        cols = [(xs[0], cy, ybot, colw), (xs[1], ycols, ybot, colw), (xs[2], ycols, ybot, colw)]
        self.flow_text(self.story(), cols)
        for x in (xs[0] + colw + 6, xs[1] + colw + 6):
            f(self.RULE, x, ycols, 1, ybot - ycols)
        f(self.RULE, 10, H - 18, W - 20, 1)
        T("HALAMAN 1  -  Rapor lengkap dan status tiap pulau di halaman 2 >>", cx, H - 13, self.INK_S, 1, "center")
        self.paper_finish()

    def draw_page_stats(self):
        s, e = self.s, self.s["end"]
        W, H = self.PW, self.PH
        thr = e["thr"]
        T, f = self.T, self.rectf
        self.paper_base()
        T("KORAN NUSANTARA", 12, 8, self.INK_N, 2)
        T("HALAMAN 2  -  LAPORAN KHUSUS", W - 12, 12, self.INK_S, 1, "right")
        f(self.INK_N, 10, 27, W - 20, 2)
        f(self.INK_N, 10, 31, W - 20, 1)
        T("RAPOR 10 HARI PEMERINTAHAN", W // 2, 37, self.INK_N, 3, "center")
        T("Redaksi Ekonomi & Politik  -  Statistik resmi Dewan Kemakmuran Indonesia", W // 2, 63, self.INK_S, 1, "center")
        f(self.RULE, 10, 75, W - 20, 1)
        # --- tabel kondisi pulau
        T("KONDISI PER PULAU", 10, 82, self.INK_N, 1)
        f(self.INK_N, 10, 92, 366, 1)
        for i, r in enumerate(REGIONS):
            yy = 96 + i * 24
            v = s["welfare"][r]
            com, role = ROLE[r]
            if r in s["seceded"]:
                st_txt, col = "BERPISAH", (150, 30, 20)
            elif v >= thr:
                st_txt, col = "MAKMUR", (30, 100, 60)
            elif v >= 30:
                st_txt, col = "BERKEMBANG", (150, 100, 10)
            else:
                st_txt, col = "KRITIS", (150, 30, 20)
            f(GROUND[r][0], 12, yy + 4, 10, 10)
            self.frame(self.INK_N, (12, yy + 4, 10, 10), 1)
            T(r, 28, yy + 2, self.INK_N, 1)
            T("Hasil: %s" % com if com else "Pusat ekspor", 28, yy + 12, self.INK_S, 1)
            self.frame(col, (112, yy + 3, 68, 14), 1)
            T(st_txt, 146, yy + 6, col, 1, "center")
            f((196, 182, 148), 190, yy + 6, 130, 8)
            f(bar_color(v), 190, yy + 6, 130 * v / 100, 8)
            f(self.INK_N, 190 + int(130 * thr / 100), yy + 3, 1, 14)
            T("%d" % v, 328, yy + 6, self.INK_N, 1)
            f((0, 0, 0, 40), 10, yy + 22, 366, 1)
        # --- ringkasan
        T("RINGKASAN KEPEMIMPINAN", 10, 224, self.INK_N, 1)
        f(self.INK_N, 10, 234, 366, 1)
        left = [("Pulau makmur", "%d dari 5" % len(e["pros"])), ("Ambang makmur", "%d%%" % thr),
                ("Rata-rata skor", "%.0f" % e["avg"]), ("Pulau berpisah", "%d" % len(e["sec"]))]
        right = [("Ketidakpuasan", "%d%%" % s["dissat"]), ("Sisa anggaran", "Rp%.0f jt" % s["budget"]),
                 ("Total ekspor", "Rp%.0f jt" % s["export_total"]), ("Kekayaan pribadi", "Rp%d jt" % s["personal"])]
        for k in range(4):
            yy = 239 + k * 12
            T(left[k][0], 12, yy, self.INK_S, 1)
            T(left[k][1], 176, yy, self.INK_N, 1, "right")
            T(right[k][0], 196, yy, self.INK_S, 1)
            T(right[k][1], 372, yy, self.INK_N, 1, "right")
        note = "Garis tegak pada grafik menandai ambang makmur tahun ini (%d%%)." % thr
        for k, ln in enumerate(self.font.wrap(note, 1, 366)[:2]):
            T(ln, 10, 292 + k * 10, self.INK_S, 1)
        f(self.RULE, 382, 80, 1, H - 90)
        # --- kolom kanan: vonis, tajuk, iklan
        rx, rw = 392, 166
        win = e["win"]
        col = (30, 100, 60) if win else (150, 30, 20)
        self.frame(col, (rx, 82, rw, 32), 2)
        self.frame(col, (rx + 4, 86, rw - 8, 24), 1)
        T("BERHASIL" if win else "GAGAL", rx + rw // 2, 93, col, 2, "center")
        T("TAJUK RENCANA", rx, 120, self.INK_N, 1)
        f(self.INK_N, rx, 130, rw, 1)
        if win:
            ed = ("Indonesia membuktikan bahwa kepemimpinan yang mau mendengar rakyat membuahkan hasil. "
                  "Ambang makmur %d%% terlampaui di %d pulau. Tugas berikutnya jelas: jangan biarkan "
                  "satu pulau pun tertinggal." % (thr, len(e["pros"])))
        elif e["sec"]:
            ed = ("Berpisahnya %s adalah alarm keras bagi pemerintah. Kepercayaan rakyat tidak bisa dibeli "
                  "dengan anggaran; ia dibangun lewat kehadiran. Indonesia harus belajar dari kegagalan ini." %
                  " dan ".join(e["sec"]))
        elif s["corrupt"] >= 2:
            ed = ("Amplop demi amplop menggerogoti kepercayaan publik. Rakyat berhak atas pemimpin yang "
                  "berani menolak uang terima kasih. Indonesia butuh pembenahan menyeluruh.")
        else:
            ed = ("Hanya %d pulau yang melampaui ambang makmur %d%%. Pemerintah perlu lebih sering menengok "
                  "daerah yang luput dari perhatian, terutama saat kabut menutup pandangan." % (len(e["pros"]), thr))
        for k, ln in enumerate(self.font.wrap(ed, 1, rw)[:10]):
            T(ln, rx, 134 + k * 10, self.INK_N, 1)
        ay = 246
        for dx in range(0, rw, 6):                 # kotak iklan putus-putus
            f(self.INK_S, rx + dx, ay, 3, 1)
            f(self.INK_S, rx + dx, ay + 70, 3, 1)
        for dy in range(0, 72, 6):
            f(self.INK_S, rx, ay + dy, 1, 3)
            f(self.INK_S, rx + rw - 1, ay + dy, 1, 3)
        T("IKLAN", rx + 4, ay + 4, self.INK_S, 1)
        T("KOPI", rx + rw // 2, ay + 14, self.INK_N, 3, "center")
        T("NUSANTARA", rx + rw // 2, ay + 42, self.INK_N, 1, "center")
        T("Seduh semangat negeri!", rx + rw // 2, ay + 56, self.INK_S, 1, "center")
        self.paper_finish()

    # ---------------- meja, balik halaman ----------------
    def get_desk(self):
        if self._desk is None:
            d = pygame.Surface((CW, CH)).convert()
            d.fill((46, 30, 24))
            rng = random.Random(4)
            for y in range(0, CH, 36):
                self.rectf((34, 22, 18), 0, y, CW, 2, d)
                for _ in range(40):
                    self.rectf((58 + rng.randint(-6, 6), 38, 30), rng.randrange(CW), y + rng.randint(3, 34),
                               rng.randint(8, 30), 1, d)
            ov = pygame.Surface((CW, CH), pygame.SRCALPHA)
            for dd in range(0, 80, 2):
                pygame.draw.rect(ov, (0, 0, 0, int(120 * (1 - dd / 80) ** 2)), (dd, dd, CW - 2 * dd, CH - 2 * dd), 2)
            d.blit(ov, (0, 0))
            self._desk = d
        return self._desk

    def draw_desk_paper(self, page):
        self.cv.blit(self.get_desk(), (0, 0))
        self.rectf((0, 0, 0, 110), self.PX + 5, self.PY + 7, self.PW, self.PH)
        self.cv.blit(page, (self.PX, self.PY))

    def draw_flip(self, p):
        """Lembar depan terangkat dan berputar ke kiri (poros di tepi kiri), memperlihatkan halaman 2."""
        PW, PH, PX, PY = self.PW, self.PH, self.PX, self.PY
        self.draw_desk_paper(self.page_stats)
        th = p * math.pi / 2
        c, sn = math.cos(th), math.sin(th)
        wp = int(PW * c)
        if wp < 2:
            return
        step = 2
        for xp in range(0, wp, step):
            u = (xp + step / 2) / wp
            x0 = int(xp / wp * PW)
            x1 = max(x0 + 1, min(PW, int((xp + step) / wp * PW)))
            h = int(PH * (1 + 0.14 * sn * u))
            col = pygame.transform.scale(self.page_front.subsurface((x0, 0, x1 - x0, PH)), (step, h))
            self.cv.blit(col, (PX + xp, PY - (h - PH) // 2 - int(10 * sn * u)))
        self.rectf((0, 0, 0, int(85 * sn)), PX, PY, wp, PH)
        self.rectf((255, 250, 235, 170), PX + wp - 1, PY - int(10 * sn), 2, PH + int(14 * sn))
        for i in range(34):
            a = int(120 * sn * (1 - i / 34) ** 2)
            if a > 0:
                self.rectf((0, 0, 0, a), PX + wp + 1 + i, PY, 1, PH)

    # ---------------- credit roll gaya ending anime ----------------
    def get_cvig(self):
        if self._cvig is None:
            ov = pygame.Surface((CW, CH), pygame.SRCALPHA)
            for d in range(0, 70, 2):
                pygame.draw.rect(ov, (0, 0, 0, int(130 * (1 - d / 70) ** 2)), (d, d, CW - 2 * d, CH - 2 * d), 2)
            self._cvig = ov
        return self._cvig

    def get_cgrad(self):
        if self._cgrad is None:
            gw = 290
            g = pygame.Surface((gw, CH), pygame.SRCALPHA)
            for x in range(gw):
                g.fill((6, 6, 12, int(220 * (x / gw) ** 1.3)), (x, 0, 1, CH))
            self._cgrad = g
        return self._cgrad

    def person(self, x, y, h, col):
        self.rectf(col, x - h // 6, y - h * 2 // 3, h // 3, h * 2 // 3)
        self.circle(col, x, y - h * 2 // 3 - h // 6, max(2, h // 6))

    def art_sky(self, top, bot, horizon):
        for y in range(0, horizon, 4):
            self.rectf(self._lerp(top, bot, y / max(1, horizon)), 0, y, CW, 4)

    def img_inaug(self):
        self.draw_scene4()
        self.fade(40)

    def img_map(self):
        self.cv.blit(pygame.transform.scale(self.sea, (CW, CH)), (0, 0))
        s = self.s
        saved = (s["hidden"], s["sel"], s["flash"], s["banner"])
        s["hidden"], s["sel"], s["flash"] = set(), -1, (-1, 0)
        self.draw_map()
        s["hidden"], s["sel"], s["flash"], s["banner"] = saved

    def img_island(self, r, gone):
        s = self.s
        self.cv.blit(pygame.transform.scale(self.sea, (CW, CH)), (0, 0))
        for i in range(5):
            self.polygon(rgba(255, 240, 190, .06), [(90 + i * 50, 0), (130 + i * 50, 0), (60 + i * 90, 360), (10 + i * 90, 360)])
        level = 0 if gone else tier_of(s["welfare"][r])
        surf, (ox, oy) = render_island(r, level, gone)
        k = 3
        big = pygame.transform.scale(surf, (surf.get_width() * k, surf.get_height() * k))
        cx, cy = CENTER[r]
        self.cv.blit(big, (int(210 - (cx - ox) * k), int(190 - (cy - oy) * k)))
        if gone:
            self.rectf((20, 10, 30, 120), 0, 0, CW, CH)
            use_target(self.cv)
            R((90, 60, 36), 206, 100, 3, 70)
            P((200, 60, 60), [(209, 102), (240, 112), (209, 124)])
            use_target(None)

    def img_money(self):
        f = self.rectf
        f((30, 14, 24), 0, 0, CW, CH)
        for i in range(0, 200, 12):
            f((60, 34, 46), 330, 20 + i, 250, 5)
        self.circle(rgba(255, 220, 140, .14), 180, 140, 120)
        f((74, 44, 17), 0, 250, CW, 110)
        f((45, 26, 10), 0, 250, CW, 6)
        f((236, 226, 200), 90, 190, 180, 62)
        self.polygon((214, 204, 176), [(90, 190), (180, 236), (270, 190)])
        for k in range(5):
            f((46, 130, 80), 110 + k * 28, 170 - (k % 2) * 8, 24, 30)
            f((30, 100, 60), 110 + k * 28, 170 - (k % 2) * 8, 24, 3)
        f((255, 215, 0), 80, 240, 10, 6)
        f((255, 215, 0), 276, 238, 10, 6)

    def img_clean(self):
        f = self.rectf
        f((40, 14, 24), 0, 0, CW, CH)
        for i in range(10):
            self.polygon(rgba(255, 220, 140, .06), [(180, 150), (60 + i * 36, 0), (96 + i * 36, 0)])
        self.polygon(GOLD2, [(110, 60), (250, 60), (250, 170), (180, 270), (110, 170)])
        self.polygon((40, 20, 30), [(122, 72), (238, 72), (238, 166), (180, 252), (122, 166)])
        self.polygon((236, 240, 220), [(144, 150), (166, 172), (218, 112), (208, 104), (166, 152), (154, 140)])

    def img_port(self):
        self.art_sky((50, 30, 80), (255, 150, 70), 200)
        self.circle((255, 210, 100), 150, 196, 44)
        self.rectf((20, 50, 70), 0, 196, CW, CH - 196)
        self.rectf((255, 190, 90, 90), 120, 200, 60, 4)
        tmp = pygame.Surface((100, 70), pygame.SRCALPHA)
        use_target(tmp)
        s_exportport(30, 46)
        use_target(None)
        big = pygame.transform.scale(tmp, (500, 350))
        self.cv.blit(big, (30, 50))
        self.fade(30)

    def img_crowd(self, mood):
        sky = {"angry": ((70, 20, 26), (210, 90, 40)), "happy": ((250, 170, 90), (120, 70, 140)),
               "calm": ((30, 40, 80), (160, 100, 110))}[mood]
        self.art_sky(sky[0], sky[1], 230)
        rng = random.Random(8)
        x = 0
        while x < CW:
            w = rng.randint(24, 46)
            self.rectf((24, 20, 36), x, 230 - rng.randint(30, 110), w, 140)
            x += w + 2
        self.rectf((30, 24, 34), 0, 230, CW, 130)
        signs = ["TURUN!", "ADIL!", "KAMI LAPAR", "MERDEKA!"]
        for row, (yy, h) in enumerate(((262, 44), (306, 56), (352, 70))):
            for i in range(14 - row * 3):
                px_ = int((i + .5) * CW / (14 - row * 3)) + rng.randint(-6, 6)
                shade = 20 + row * 10
                self.person(px_, yy, h, (shade, shade - 4, shade + 8))
                if mood == "angry" and rng.random() < .35:
                    pygame.draw.line(self.cv, (shade, shade, shade + 8), (px_ + 4, yy - h // 2), (px_ + 12, yy - h), 3)
                    if rng.random() < .6:
                        sw = 6 * 6 + 8
                        self.rectf((236, 226, 200), px_ + 6 - sw // 2, yy - h - 18, sw, 14)
                        self.T(signs[(i + row) % 4], px_ + 6, yy - h - 15, (60, 20, 20), 1, "center")
                elif mood == "happy" and rng.random() < .5:
                    self.rectf(rng.choice([(255, 215, 0), (230, 80, 90), (120, 200, 255)]), px_ + 5, yy - h - 6, 7, 5)

    def img_final(self, win):
        f = self.rectf
        if win:
            self.art_sky((10, 12, 40), (60, 40, 90), 250)
            rng = random.Random(3)
            for cx_, cy_, col in ((120, 90, (255, 215, 0)), (260, 60, (240, 90, 110)),
                                  (200, 130, (120, 200, 255)), (330, 100, (120, 255, 160)), (60, 150, (255, 160, 60))):
                for a in range(20):
                    ang = a * math.pi / 10
                    for r_ in range(8, 44, 6):
                        f(col, cx_ + math.cos(ang) * r_, cy_ + math.sin(ang) * r_, 2, 2)
            x = 0
            while x < CW:
                w = rng.randint(20, 40)
                f((16, 14, 28), x, 250 - rng.randint(20, 90), w, 120)
                x += w + 2
            f((16, 14, 28), 0, 290, CW, 70)
        else:
            self.art_sky((14, 16, 28), (50, 56, 76), 280)
            f((18, 18, 26), 0, 280, CW, 80)
            for i in range(6):
                f((40, 42, 56), 20 + i * 44, 130, 14, 150)
            self.polygon((40, 42, 56), [(10, 130), (150, 130), (80, 90)])
            f((255, 220, 140), 296, 200, 3, 80)
            self.circle(rgba(255, 220, 140, .18), 297, 200, 34)
            self.person(240, 280, 70, (10, 10, 16))
            f((10, 10, 16), 250, 262, 16, 12)
            ov = pygame.Surface((CW, CH), pygame.SRCALPHA)
            rng = random.Random(5)
            for _ in range(160):
                x, y = rng.randrange(CW), rng.randrange(CH)
                pygame.draw.line(ov, (170, 190, 220, 110), (x, y), (x - 4, y + 12), 1)
            self.cv.blit(ov, (0, 0))

    def img_placeholder(self, k):
        f = self.rectf
        f((52, 56, 66), 0, 0, CW, CH)
        for i in range(0, CW + CH, 32):
            pygame.draw.line(self.cv, (66, 70, 82), (i, 0), (i - CH, CH), 2)
        self.frame((130, 136, 150), (24, 24, CW - 48, CH - 48), 3)
        pygame.draw.line(self.cv, (110, 116, 130), (24, 24), (CW - 24, CH - 24), 2)
        pygame.draw.line(self.cv, (110, 116, 130), (CW - 24, 24), (24, CH - 24), 2)
        f((26, 28, 34), CW // 2 - 140, CH // 2 - 34, 280, 68)
        self.frame(GOLD2, (CW // 2 - 140, CH // 2 - 34, 280, 68), 2)
        self.T("IMAGE PLACEHOLDER", CW // 2, CH // 2 - 22, GOLD, 2, "center")
        self.T("%02d  -  640 x 360 px" % k, CW // 2, CH // 2 + 4, CREAMT, 2, "center")

    def build_recap(self):
        """Gambar rekap yang dipilih berdasarkan kondisi permainan, lalu image placeholder."""
        s, e = self.s, self.s["end"]
        alive = [r for r in REGIONS if r not in s["seceded"]]
        best = max(alive, key=lambda r: s["welfare"][r]) if alive else REGIONS[0]
        worst = min(REGIONS, key=lambda r: s["welfare"][r])
        gone = worst in s["seceded"]
        sl = []

        def add(fn, title, sub):
            sl.append({"img": self.render_to(fn), "title": title, "sub": sub})

        add(self.img_inaug, "HARI 1 - PELANTIKAN", "Seorang warga biasa mendadak menjadi Presiden Indonesia.")
        pv = self.credits_preview
        if pv:
            add(self.img_map, "PETA NUSANTARA", "Lima pulau menunggu kepemimpinanmu.")
            add(lambda: self.img_island(best, False), "PULAU %s" % best.upper(),
                "Kesejahteraan awal %d - %s." % (s["welfare"][best], TIER_NAMES[tier_of(s["welfare"][best])]))
            add(lambda: self.img_island(worst, False), "PULAU %s" % worst.upper(),
                "Kesejahteraan awal %d. Butuh perhatianmu." % s["welfare"][worst])
            add(self.img_clean, "INTEGRITAS", "Setiap keputusan ada di tanganmu.")
            add(lambda: self.img_crowd("calm"), "RAKYAT NUSANTARA", "Ketidakpuasan awal: %d%%." % s["dissat"])
            add(lambda: self.img_final(True), "MASA DEPAN INDONESIA", "Semuanya bergantung pada keputusanmu.")
            for k in range(1, 4):
                add(lambda k=k: self.img_placeholder(k), "IMAGE PLACEHOLDER %02d" % k, "Ganti dengan ilustrasi Anda.")
            return sl
        add(self.img_map, "PETA AKHIR NUSANTARA",
            "%d dari 5 pulau melampaui ambang makmur %d%%." % (len(e["pros"]), e["thr"]))
        add(lambda: self.img_island(best, False), "PULAU TERBAIK: %s" % best.upper(),
            "Kesejahteraan %d - %s." % (s["welfare"][best], TIER_NAMES[tier_of(s["welfare"][best])]))
        if gone:
            add(lambda: self.img_island(worst, True), "%s MEMILIH BERPISAH" % worst.upper(),
                "Rakyatnya kehilangan kepercayaan dan mengibarkan bendera sendiri.")
        else:
            add(lambda: self.img_island(worst, False), "PULAU TERTINGGAL: %s" % worst.upper(),
                "Kesejahteraan hanya %d. Masih banyak pekerjaan rumah." % s["welfare"][worst])
        if s["corrupt"] > 0:
            add(self.img_money, "AMPLOP MISTERIUS",
                "Suap diterima %d kali. Rp%d juta masuk kantong pribadi." % (s["corrupt"], s["personal"]))
        else:
            add(self.img_clean, "TANGAN YANG BERSIH", "Semua tawaran suap ditolak demi rakyat.")
        if s["export_total"] > 0:
            add(self.img_port, "PELABUHAN JAWA", "Total ekspor Rp%.0f juta selama sepuluh hari." % s["export_total"])
        mood = "angry" if s["dissat"] > 60 else "happy" if s["dissat"] <= 30 else "calm"
        add(lambda: self.img_crowd(mood), {"angry": "AMARAH RAKYAT", "happy": "SENYUM RAKYAT",
                                           "calm": "SUARA DARI JALANAN"}[mood],
            "Ketidakpuasan akhir: %d%%." % s["dissat"])
        add(lambda: self.img_final(e["win"]), "PESTA KEMAKMURAN" if e["win"] else "HARI PERPISAHAN",
            "Indonesia merayakan kepemimpinanmu." if e["win"] else "Presiden meninggalkan istana dengan kepala tertunduk.")
        for k in range(1, 4):
            add(lambda k=k: self.img_placeholder(k), "IMAGE PLACEHOLDER %02d" % k, "Ganti dengan ilustrasi Anda.")
        return sl

    def start_credits(self):
        self.slides = self.build_recap()
        self.cred_total = len(self.slides) * self.SLIDE_T
        dist = CH + 20 + self.credits_h + 24
        self.cred_speed = dist / (self.cred_total - self.HOLD)

    def draw_slide(self, idx, prog, alpha):
        img = self.slides[idx]["img"]
        z = 1.0 + 0.12 * prog
        cw, ch = int(CW / z), int(CH / z)
        dirx = 1 if idx % 2 == 0 else -1
        fx = max(0.0, min(1.0, 0.5 + dirx * (prog - 0.5) * 0.9))
        fy = max(0.0, min(1.0, 0.5 + (0.5 - prog) * 0.3))
        tmp = pygame.Surface((cw, ch))
        tmp.blit(img, (-int((CW - cw) * fx), -int((CH - ch) * fy)))
        out = pygame.transform.smoothscale(tmp, (CW, CH))
        if alpha < 255:
            out.set_alpha(alpha)
        self.cv.blit(out, (0, 0))

    def draw_credits(self):
        t = self.end_t
        N = len(self.slides)
        ST, XF = self.SLIDE_T, self.XFADE
        off = max(0.0, t - self.HOLD) * self.cred_speed
        k = min(N - 1, int(t / ST))
        u = t - k * ST
        self.draw_slide(k, max(0.0, min(1.0, (t - (k * ST - XF)) / (ST + XF))), 255)
        if k + 1 < N and u > ST - XF:
            nk = k + 1
            self.draw_slide(nk, max(0.0, min(1.0, (t - (nk * ST - XF)) / (ST + XF))),
                            int(255 * (u - (ST - XF)) / XF))
        cx = CW - 130
        self.cv.blit(self.get_cgrad(), (CW - self.get_cgrad().get_width(), 0))
        self.cv.blit(self.get_cvig(), (0, 0))
        dim = 150 if t < self.HOLD else max(0.0, 150 * (1 - (t - self.HOLD) / 1.5))
        self.fade(dim)
        base = CH + 10 - off
        for text, sc, col, dy in self.credits:
            yy = base + dy
            if -24 < yy < CH:
                self.T(text, cx, yy, col, sc, "center", (0, 0, 0))
        ty = CH // 2 - 18 - off
        if ty > -40 and not self.credits_preview:
            self.T("THE END", CW // 2 + 4, ty + 4, SHADOW, 5, "center")
            self.T("THE END", CW // 2, ty, GOLD, 5, "center")
            e = self.s.get("end") or {}
            rate = e.get("rating")
            if rate:
                vtxt, vcol = {"berhasil": ("KAMU BERHASIL!", GREEN), "biasa": ("KAMU B AJA", YELLOW),
                              "gagal": ("KAMU GAGAL", RED2)}[rate]
                self.T(vtxt, CW // 2 + 2, ty + 50 + 2, SHADOW, 2, "center")
                self.T(vtxt, CW // 2, ty + 50, vcol, 2, "center")
                self.T("Rata-rata kemakmuran %.0f  (berhasil > 65, b aja 40-65, gagal < 40)" % e["avg"],
                       CW // 2, ty + 72, CREAMT, 1, "center", (0, 0, 0))
        # teks keterangan gambar rekap (kiri bawah)
        if t >= self.HOLD:
            alpha = min(1.0, u / 0.7)
            if k < N - 1:
                alpha = min(alpha, (ST - u) / 0.7)
            alpha = max(0.0, alpha)
            if alpha > 0:
                cap = pygame.Surface((340, 54), pygame.SRCALPHA)
                self.rectf(GOLD, 0, 2, 54, 2, cap)
                self.T(self.slides[k]["title"], 0, 8, WHITE, 1, "left", (0, 0, 0), cap)
                for j, ln in enumerate(self.font.wrap(self.slides[k]["sub"], 1, 330)[:2]):
                    self.T(ln, 0, 20 + j * 10, CREAMT, 1, "left", (0, 0, 0), cap)
                cap.set_alpha(int(255 * alpha))
                self.cv.blit(cap, (22, CH - 64))
        self.T("SUDDENLY A PRESIDENT", 22, 24, (200, 190, 160), 1, "left", (0, 0, 0))
        self.rectf((0, 0, 0), 0, 0, CW, 16)           # letterbox sinematik
        self.rectf((0, 0, 0), 0, CH - 16, CW, 16)
        rng = random.Random(int(t * 24))               # film grain
        for _ in range(70):
            self.rectf((255, 255, 255, 22), rng.randrange(CW), rng.randrange(CH), 1, 1)
        self.fade(255 * (1 - t / 1.2))
        self.T("ESC: lewati", CW - 6, CH - 14, (110, 100, 70), 1, "right")

    # ------------------------------------------------------------------
    # LATAR LAYAR AKHIR: kota sesuai rating
    #   berhasil -> rakyat mengangkat presiden | biasa -> kota normal | gagal -> gedung terbakar
    # ------------------------------------------------------------------
    END_HZ = 276
    END_CAPTION = {
        "berhasil": ("KAMU BERHASIL!", GREEN, "Rakyat mengangkatmu di pundak mereka. Terima kasih, Presiden!"),
        "biasa": ("KAMU B AJA", YELLOW, "Kota berjalan seperti biasa. Tidak buruk, tetapi masih bisa lebih baik."),
        "gagal": ("KAMU GAGAL", RED2, "Gedung-gedung terbakar dan rakyat murka. Indonesia butuh pemimpin lain."),
    }

    @staticmethod
    def _ecl(c0, c1, k):
        k = max(0.0, min(1.0, k))
        return tuple(int(c0[i] + (c1[i] - c0[i]) * k) for i in range(3))

    def _end_layer(self, rng, base, hmin, hmax, wmin, wmax, gap, pal, p_lit, damage=False, flames=None, fscale=1.0,
                   tops=None):
        col, shade, won, woff = pal
        R, lay = self._R, pygame.Surface((CW, CH), pygame.SRCALPHA)
        x = -8
        while x < CW:
            w, h = rng.randint(wmin, wmax), rng.randint(hmin, hmax)
            top = base - h
            R(lay, col, x, top, w, h)
            R(lay, shade, x + w - 3, top, 3, h)
            R(lay, self._ecl(col, (255, 255, 255), .14), x, top, w, 1)
            r_ = rng.random()
            if r_ < .35:
                R(lay, col, x + w // 2 - 1, top - 8, 2, 8)
            elif r_ < .6:
                R(lay, shade, x + 3, top - 5, 8, 5)
            wlist = []
            for wy in range(top + 6, base - 6, 8):
                for wx in range(x + 4, x + w - 6, 7):
                    lit = rng.random() < p_lit
                    R(lay, won if lit else woff, wx, wy, 3, 4)
                    wlist.append((wx, wy))
            if damage and rng.random() < .8:
                d1, d2, d3, d4 = rng.randint(6, 22), rng.randint(2, 12), rng.randint(10, 28), rng.randint(4, 14)
                pygame.draw.polygon(lay, (0, 0, 0, 0), [
                    (x - 1, top - 12), (x + w + 1, top - 12), (x + w + 1, top + d1), (x + int(w * .72), top + d2),
                    (x + int(w * .48), top + d3), (x + int(w * .26), top + d4), (x - 1, top + d2 + 4)])
                for _ in range(3):
                    R(lay, (10, 8, 12), x + rng.randint(0, max(0, w - 8)), top + rng.randint(min(d3, h - 12), max(d3, h - 12)), rng.randint(5, 10),
                      rng.randint(6, 14))
                if flames is not None:
                    flames.append((x + int(w * rng.uniform(.25, .75)), top + rng.randint(min(d2, d3), max(d2, d3)) + 4, fscale,
                                   rng.random() * 6.3))
                    for wx, wy in rng.sample(wlist, min(2, len(wlist))):
                        flames.append((wx + 1, wy + 4, fscale * .6, rng.random() * 6.3))
            if tops is not None:
                tops.append((x + w // 2, top, w))
            x += w + rng.randint(*gap)
        return lay

    def _end_scene(self, rating):
        cache = self.__dict__.setdefault("_endscene", {})
        if rating in cache:
            return cache[rating]
        R, mix = self._R, self._ecl
        rng = random.Random({"berhasil": 11, "biasa": 22, "gagal": 33}[rating])
        HZ = self.END_HZ
        pal = {
            "berhasil": dict(sky=[(0, (70, 120, 205)), (.45, (190, 150, 200)), (.75, (255, 176, 120)), (1, (255, 226, 150))],
                             far=((158, 150, 206), (132, 124, 184), (255, 226, 170), (120, 114, 170)),
                             mid=((112, 112, 176), (88, 88, 150), (255, 214, 140), (80, 80, 140)),
                             near=((72, 78, 138), (52, 56, 110), (255, 206, 120), (56, 58, 112)),
                             lit=(.3, .5, .6), road=(76, 70, 92), side=(196, 174, 160)),
            "biasa": dict(sky=[(0, (96, 160, 225)), (.6, (160, 206, 238)), (1, (226, 238, 244))],
                          far=((172, 196, 222), (150, 176, 206), (212, 232, 248), (144, 170, 204)),
                          mid=((128, 154, 194), (104, 130, 172), (200, 226, 246), (96, 122, 166)),
                          near=((96, 118, 160), (74, 96, 140), (190, 220, 244), (66, 88, 130)),
                          lit=(.4, .4, .4), road=(84, 88, 100), side=(190, 190, 196)),
            "gagal": dict(sky=[(0, (16, 10, 20)), (.4, (60, 24, 30)), (.75, (150, 50, 34)), (1, (236, 110, 44))],
                          far=((52, 30, 40), (40, 22, 32), (255, 150, 60), (30, 18, 28)),
                          mid=((36, 24, 34), (28, 18, 28), (255, 130, 50), (22, 14, 22)),
                          near=((24, 17, 25), (18, 12, 20), (255, 120, 40), (14, 9, 16)),
                          lit=(.04, .10, .12), road=(30, 26, 32), side=(70, 60, 66)),
        }[rating]
        bad = rating == "gagal"

        # ---------------- langit ----------------
        sky = pygame.Surface((CW, CH)).convert()
        stops = pal["sky"]
        N = 30
        for i in range(N):
            y0, y1 = round(i * HZ / N), round((i + 1) * HZ / N)
            t_ = (i + .5) / N
            for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
                if t_ <= t1:
                    col = mix(c0, c1, (t_ - t0) / (t1 - t0))
                    break
            sky.fill(col, (0, y0, CW, y1 - y0))
        sky.fill(stops[-1][1], (0, HZ, CW, CH - HZ))
        if rating == "berhasil":
            sky.blit(self._glow(170, (255, 220, 150), 170), (440 - 170, 236 - 170))
            for k in range(-5, 6):                                   # berkas cahaya matahari terbit
                a0 = -math.pi / 2 + k * 0.17
                pts = [(440, 236), (440 + math.cos(a0 - .04) * 420, 236 + math.sin(a0 - .04) * 420),
                       (440 + math.cos(a0 + .04) * 420, 236 + math.sin(a0 + .04) * 420)]
                lay = pygame.Surface((CW, CH), pygame.SRCALPHA)
                pygame.draw.polygon(lay, (255, 240, 190, 20), pts)
                sky.blit(lay, (0, 0))
        elif rating == "biasa":
            sky.blit(self._glow(60, (255, 250, 220), 150), (540 - 60, 66 - 60))
            pygame.draw.circle(sky, (255, 252, 230), (540, 66), 12)
        else:
            sky.blit(self._glow(150, (255, 110, 40), 160), (300 - 150, 262 - 150))
            pygame.draw.circle(sky, (120, 36, 28), (400, 216), 22)

        # ---------------- kota ----------------
        city = pygame.Surface((CW, CH), pygame.SRCALPHA)
        flames, tops = [], []
        far = self._end_layer(rng, HZ - 24, 30, 95, 14, 30, (0, 3), pal["far"], pal["lit"][0], bad, flames, .7)
        mid = self._end_layer(rng, HZ - 8, 48, 125, 22, 42, (0, 3), pal["mid"], pal["lit"][1], bad, flames, 1.0)
        # Monas
        mx = 598
        mc = pal["mid"][0]
        R(mid, mc, mx - 14, 258, 28, 10)
        R(mid, mc, mx - 10, 252, 20, 6)
        pygame.draw.polygon(mid, mc + (255,), [(mx - 3, 252), (mx + 3, 252), (mx + 1, 160), (mx - 1, 160)])
        R(mid, mc, mx - 8, 188, 16, 5)
        R(mid, mc, mx - 3, 154, 6, 6)
        R(mid, (255, 214, 90) if not bad else (255, 130, 40), mx - 2, 146, 4, 8)
        near_tops = []
        near = self._end_layer(rng, 286, 36, 92, 30, 54, (1, 5), pal["near"], pal["lit"][2], bad, flames, 1.5,
                               near_tops)
        for lay in (far, mid, near):
            city.blit(lay, (0, 0))
        flags = []
        if rating != "gagal":
            for tx, ty, tw in rng.sample(near_tops, min(6 if rating == "berhasil" else 2, len(near_tops))):
                R(city, (70, 70, 80), tx, ty - 22, 2, 22)
                flags.append((tx + 2, ty - 22))
        # jalan & trotoar
        R(city, pal["side"], 0, 284, CW, 10)
        R(city, mix(pal["side"], (255, 255, 255), .25), 0, 284, CW, 1)
        R(city, pal["road"], 0, 294, CW, CH - 294)
        R(city, mix(pal["road"], (0, 0, 0), .3), 0, 294, CW, 2)
        lane = (255, 230, 150) if rating != "biasa" else (240, 240, 240)
        for x in range(0, CW, 44):
            R(city, lane if not bad else (80, 70, 60), x, 326, 20, 2)
        if rating == "biasa":
            for yy in range(298, 356, 6):
                R(city, (240, 240, 240), 300, yy, 44, 3)
        if bad:
            for _ in range(30):
                x, y = rng.randint(0, CW), rng.randint(298, CH - 4)
                pygame.draw.line(city, (60, 50, 56), (x, y), (x + rng.randint(-14, 14), y + rng.randint(2, 8)), 1)
            for _ in range(26):
                R(city, rng.choice(((54, 48, 54), (76, 66, 70), (40, 34, 40))), rng.randint(0, CW),
                  rng.randint(296, CH - 8), rng.randint(3, 9), rng.randint(2, 5))
        # pohon / lampu jalan
        lamps = []
        for x in (30, 150, 250, 380, 520, 612):
            if not bad:
                R(city, (92, 62, 40), x - 1, 266, 3, 18)
                for dx, dy, r in ((0, -6, 9), (-5, -2, 7), (5, -2, 7)):
                    pygame.draw.circle(city, (40, 112, 64) if rating == "biasa" else (52, 100, 80), (x + dx, 262 + dy), r)
                pygame.draw.circle(city, (84, 168, 96) if rating == "biasa" else (96, 150, 110), (x - 3, 255), 4)
            else:
                R(city, (18, 14, 16), x - 1, 262, 3, 22)
                pygame.draw.line(city, (18, 14, 16), (x, 266), (x + 8, 258), 2)
                pygame.draw.line(city, (18, 14, 16), (x, 270), (x - 7, 262), 2)
        for x in (90, 210, 345, 560):
            R(city, (46, 46, 58) if not bad else (20, 16, 20), x, 250, 2, 36)
            R(city, (46, 46, 58) if not bad else (20, 16, 20), x - 5, 250, 8, 2)
            if not bad:
                R(city, (255, 226, 150), x - 5, 252, 4, 3)
                lamps.append((x - 3, 253))
        if rating == "biasa":                                    # lampu lalu lintas
            R(city, (46, 46, 58), 330, 252, 2, 34)
            R(city, (30, 30, 38), 326, 244, 10, 22)
        if rating == "berhasil":                                 # rangkaian bendera hias
            for (x0, y0, x1, y1) in ((290, 40, 640, 76), (310, 122, 640, 104)):
                prev = None
                for i in range(0, 41):
                    u = i / 40
                    px, py = x0 + (x1 - x0) * u, y0 + (y1 - y0) * u + 12 * 4 * u * (1 - u)
                    if prev:
                        pygame.draw.line(city, (50, 36, 40), prev, (px, py), 1)
                    prev = (px, py)
                    if i % 2 == 0 and 0 < i < 40:
                        c = ((214, 34, 46), (248, 244, 238), (255, 214, 64), (60, 150, 230))[(i // 2) % 4]
                        pygame.draw.polygon(city, c, [(px - 4, py), (px + 4, py), (px, py + 9)])
        if bad:                                                  # mobil terbakar + truk pemadam
            R(city, (22, 20, 24), 456, 320, 30, 10)
            R(city, (34, 30, 34), 462, 314, 16, 7)
            R(city, (10, 8, 12), 458, 328, 6, 5)
            R(city, (10, 8, 12), 478, 328, 6, 5)
            flames.append((471, 318, 1.3, 1.0))
            R(city, (150, 28, 30), 520, 312, 56, 18)
            R(city, (196, 40, 40), 520, 312, 56, 4)
            R(city, (230, 230, 236), 524, 322, 40, 2)
            R(city, (120, 20, 24), 562, 304, 14, 10)
            R(city, (150, 160, 176), 524, 306, 36, 3)
            R(city, (10, 8, 12), 526, 328, 8, 7)
            R(city, (10, 8, 12), 562, 328, 8, 7)

        vig = pygame.Surface((CW, CH), pygame.SRCALPHA)
        k_ = 1.6 if bad else 1.0
        for y in range(0, 90, 2):
            vig.fill((4, 2, 14, int(min(255, 70 * k_ * (1 - y / 90) ** 1.5))), (0, y, CW, 2))
        for y in range(CH - 50, CH, 2):
            vig.fill((4, 2, 10, int(min(255, 100 * k_ * ((y - (CH - 50)) / 50) ** 1.5))), (0, y, CW, 2))

        sc = dict(sky=sky, city=city, vig=vig, flames=flames, flags=flags, lamps=lamps)

        def cloud(w, h, hi, lo):
            c = pygame.Surface((w, h), pygame.SRCALPHA)
            for ex, ey, ew, eh in ((0, h * .38, w * .6, h * .62), (w * .22, 0, w * .5, h * .85), (w * .48, h * .3, w * .52, h * .7)):
                pygame.draw.ellipse(c, lo + (235,), (int(ex), int(ey + 3), int(ew), int(eh)))
            for ex, ey, ew, eh in ((0, h * .38, w * .6, h * .62), (w * .22, 0, w * .5, h * .85), (w * .48, h * .3, w * .52, h * .7)):
                pygame.draw.ellipse(c, hi + (235,), (int(ex), int(ey), int(ew), int(eh - 3)))
            return c
        if rating == "biasa":
            sc["clouds"] = [(cloud(90, 30, (255, 255, 255), (206, 220, 240)), 30, 28, 6.0),
                            (cloud(120, 36, (255, 255, 255), (206, 220, 240)), 260, 60, 4.0),
                            (cloud(80, 26, (255, 255, 255), (206, 220, 240)), 470, 22, 7.0),
                            (cloud(100, 30, (255, 255, 255), (206, 220, 240)), 130, 100, 5.0)]
            sc["cars"] = [(308, 40, 32, 1, (214, 60, 52)), (308, 360, 26, 1, (60, 120, 200)),
                          (340, 100, 30, -1, (240, 200, 60)), (340, 420, 36, -1, (80, 170, 110)),
                          (340, 250, 24, -1, (230, 230, 236))]
            sc["walkers"] = [(rng.randint(0, CW), rng.uniform(8, 16), rng.choice((1, -1)),
                              rng.choice(((200, 80, 70), (70, 120, 190), (230, 190, 80), (90, 160, 110)))) for _ in range(8)]
        elif bad:
            sc["smokes"] = [pygame.transform.scale(self._smoke_blob(rng), (330, 120)) for _ in range(3)]
            sc["plumes"] = [f for f in flames if f[2] >= 1.0][:8]
            sc["embers"] = [(rng.uniform(0, CW), rng.uniform(20, 60), rng.uniform(0, 6.3)) for _ in range(46)]
            sc["ash"] = [(rng.uniform(0, CW), rng.uniform(10, 26), rng.uniform(0, 6.3)) for _ in range(60)]
            sc["protest"] = [(rng.randint(310, 620), rng.choice((344, 352)), rng.uniform(0, 6.3),
                              rng.choice(("TURUN!", "GAGAL!", "ADIL!", None, None))) for _ in range(9)]
        else:
            clothes = [(214, 60, 60), (60, 120, 200), (240, 200, 70), (70, 170, 110), (170, 100, 200), (240, 240, 240),
                       (230, 130, 60)]
            crowd = []
            for yy, h, n in ((298, 40, 16), (326, 52, 12), (356, 66, 9)):
                for i in range(n):
                    x = int((i + .5) * CW / n + rng.uniform(-14, 14))
                    if 410 < x < 545 and yy >= 300:
                        continue
                    crowd.append((x, yy, h, rng.choice(clothes), rng.random() * 6.3))
            sc["crowd"] = crowd
            sc["signs"] = [(330, 326, "TERIMA KASIH!"), (598, 356, "MERDEKA!"), (236, 298, "HIDUP PRESIDEN!")]
            sc["confetti"] = [(rng.uniform(0, CW), rng.uniform(26, 70), rng.randint(1, 3), rng.random() * 6.3,
                               rng.choice(((255, 215, 0), (230, 80, 90), (120, 200, 255), (120, 255, 160), (255, 160, 60))))
                              for _ in range(90)]
        cache[rating] = sc
        return sc

    @staticmethod
    def _smoke_blob(rng):
        s = pygame.Surface((110, 40), pygame.SRCALPHA)
        for _ in range(9):
            pygame.draw.ellipse(s, (20, 14, 18, 140), (rng.randint(0, 60), rng.randint(2, 18), rng.randint(30, 50),
                                                        rng.randint(14, 22)))
        return s

    # ---- bagian dinamis ----
    def _flag_wave(self, x, y, w, h, t):
        for col in range(w):
            ph = t * 5 - col * 0.5
            off = int(round(math.sin(ph) * (col / w) * 2.5))
            dark = math.cos(ph) < -0.3
            self._R(self.cv, (150, 20, 32) if dark else (206, 32, 44), x + col, y + off, 1, h // 2)
            self._R(self.cv, (200, 198, 210) if dark else (248, 244, 238), x + col, y + h // 2 + off, 1, h - h // 2)

    def _flame(self, x, y, k, ph, t):
        cv = self.cv
        fl = 0.78 + 0.22 * math.sin(t * 9 + ph) + 0.1 * math.sin(t * 17 + ph * 2)
        cv.blit(self._glow(int(26 * k) + 6, (255, 120, 40), int(120 * fl)), (int(x - 26 * k - 6), int(y - 10 * k - 26 * k - 6)))
        for off, hh, c1, c2 in ((-3, 1.0, (255, 120, 30), (255, 200, 70)), (0, 1.35, (255, 96, 24), (255, 226, 110)),
                                (3, 0.85, (255, 140, 36), (255, 214, 90))):
            h_ = int(15 * k * hh * fl)
            sway = int(math.sin(t * 7 + ph + off) * 2 * k)
            bx = x + off * k
            pygame.draw.polygon(cv, c1, [(bx - 3 * k, y), (bx + sway, y - h_), (bx + 3 * k, y)])
            pygame.draw.polygon(cv, c2, [(bx - 1.5 * k, y), (bx + sway, y - h_ * .62), (bx + 1.5 * k, y)])

    def _cheer(self, x, y, h, col, ph, t):
        cv = self.cv
        b = abs(math.sin(t * 6 + ph)) * 3
        y -= b
        tw, th = max(4, h // 3), h * 2 // 3
        self._R(cv, col, x - tw // 2, y - th, tw, th)
        pygame.draw.circle(cv, (226, 176, 132), (int(x), int(y - th - h // 7)), max(2, h // 7))
        self._R(cv, (36, 26, 24), x - max(2, h // 7), y - th - h // 7 - max(2, h // 7), max(2, h // 7) * 2, max(1, h // 14))
        aw = max(1, h // 18)
        up = math.sin(t * 6 + ph + 1) * 3
        pygame.draw.line(cv, col, (x - tw // 2, y - th + 3), (x - tw // 2 - 4, y - th - h // 3 + up), aw)
        pygame.draw.line(cv, col, (x + tw // 2, y - th + 3), (x + tw // 2 + 4, y - th - h // 3 - up), aw)

    def _lifted_president(self, px, t):
        cv, R = self.cv, self._R
        lift = math.sin(t * 2.6) * 4
        fy = 246 - lift
        cv.blit(self._glow(38, (255, 236, 170), 130), (int(px - 38), int(fy - 24 - 38)))
        holders = [(455, 303, 50, (60, 120, 200)), (473, 303, 50, (214, 60, 60)), (491, 303, 50, (240, 200, 70)),
                   (446, 318, 58, (70, 170, 110)), (464, 318, 58, (230, 130, 60)), (482, 318, 58, (170, 100, 200)),
                   (500, 318, 58, (240, 240, 240))]
        for i, (x, y, h, col) in enumerate(holders):
            yb = y - abs(math.sin(t * 2.6 + i)) * 1.5
            th = h * 2 // 3
            R(cv, col, x - h // 6, yb - th, h // 3, th)
            pygame.draw.circle(cv, (226, 176, 132), (x, int(yb - th - h // 7)), max(2, h // 7))
            R(cv, (36, 26, 24), x - h // 7, yb - th - h // 7 - h // 7, h // 7 * 2, max(1, h // 14))
            tx, ty = px + (x - px) * .35, fy + 1
            pygame.draw.line(cv, col, (x - h // 6, yb - th + 3), (tx, ty), 2)
            pygame.draw.line(cv, col, (x + h // 6, yb - th + 3), (tx, ty), 2)
        suit = (28, 32, 58)
        R(cv, (20, 22, 40), px - 5, fy - 12, 4, 12)
        R(cv, (20, 22, 40), px + 1, fy - 12, 4, 12)
        R(cv, suit, px - 7, fy - 30, 14, 19)
        pygame.draw.line(cv, (214, 34, 46), (px - 6, fy - 29), (px + 6, fy - 12), 3)
        pygame.draw.line(cv, (245, 245, 245), (px - 6, fy - 26), (px + 6, fy - 9), 1)
        wv = math.sin(t * 5) * 3
        for sg in (-1, 1):
            pygame.draw.line(cv, suit, (px + sg * 7, fy - 28), (px + sg * 15, fy - 42 + sg * wv), 3)
            pygame.draw.circle(cv, (226, 176, 132), (int(px + sg * 15), int(fy - 43 + sg * wv)), 2)
        pygame.draw.circle(cv, (226, 176, 132), (px, int(fy - 36)), 5)
        R(cv, (18, 18, 22), px - 5, fy - 42, 10, 4)

    def _end_fx_berhasil(self, sc, t):
        cv = self.cv
        for lx, ly in sc["lamps"]:
            cv.blit(self._glow(20, (255, 214, 140), 120), (lx - 20, ly - 20))
        for fx, fy in sc["flags"]:
            self._flag_wave(fx, fy, 24, 14, t)
        for x, y, h, col, ph in sc["crowd"]:
            self._cheer(x, y, h, col, ph, t)
        for x, y, txt in sc["signs"]:
            bob = abs(math.sin(t * 6 + x)) * 3
            w = len(txt) * 6 + 8
            pygame.draw.line(cv, (110, 80, 50), (x, y - 40 - bob), (x, y - 62 - bob), 2)
            self._R(cv, (240, 232, 206), x - w // 2, y - 76 - bob, w, 14)
            self._R(cv, (180, 140, 60), x - w // 2, y - 76 - bob, w, 1)
            self.T(txt, x, y - 72 - bob, (150, 30, 30), 1, "center")
        self._lifted_president(473, t)
        for x0, spd, sz, ph, col in sc["confetti"]:
            x = (x0 + math.sin(t * 1.5 + ph) * 16) % CW
            y = (t * (22 + sz * 14) + ph * 40) % (CH + 20) - 10
            if int(t * 6 + ph) % 2:
                self._R(cv, col, x, y, sz + 1, 1)
            else:
                self._R(cv, col, x, y, 1, sz + 1)

    def _end_sky_berhasil(self, sc, t):
        cv = self.cv
        for bx, by, off, col in ((350, 70, 0.0, (255, 214, 64)), (520, 48, 1.1, (240, 90, 110)),
                                 (600, 120, 2.0, (120, 220, 255)), (430, 124, 2.6, (130, 255, 160))):
            p = ((t + off) % 3.2) / 3.2
            if p > 0.8:
                continue
            u = p / 0.8
            rad = 4 + 46 * (1 - (1 - u) ** 2)
            fall = 16 * u * u
            c = (255, 255, 255) if u < 0.12 else self._ecl((0, 0, 0), col, 1 - 0.55 * u)
            for ring, rk in ((18, 1.0), (10, .55)):
                for a in range(ring):
                    ang = a * 2 * math.pi / ring + (0.2 if ring == 10 else 0)
                    self._R(cv, c, bx + math.cos(ang) * rad * rk, by + math.sin(ang) * rad * rk + fall,
                            2 if u < .5 else 1, 2 if u < .5 else 1)

    def _end_sky_biasa(self, sc, t):
        cv = self.cv
        for img, x0, y, spd in sc["clouds"]:
            x = (x0 + t * spd) % (CW + 140) - 120
            cv.blit(img, (int(x), y))
        for i in range(3):
            bx = (t * (18 + i * 4) + i * 150) % (CW + 40) - 20
            by = 90 + i * 20 + math.sin(t * 1.3 + i) * 4
            pts = ((-3, -1), (-2, 0), (-1, 1), (0, 1), (1, 1), (2, 0), (3, -1)) if int(t * 6 + i * 2) % 2 else \
                  ((-3, 1), (-2, 0), (-1, 0), (0, 1), (1, 0), (2, 0), (3, 1))
            for dx, dy in pts:
                cv.fill((50, 56, 72), (int(bx) + dx, int(by) + dy, 1, 1))

    def _end_fx_biasa(self, sc, t):
        cv, R = self.cv, self._R
        for fx, fy in sc["flags"]:
            self._flag_wave(fx, fy, 22, 12, t)
        for lx, ly in sc["lamps"]:
            cv.blit(self._glow(14, (255, 226, 150), 70), (lx - 14, ly - 14))
        for wx0, spd, d, col in sc["walkers"]:
            x = (wx0 + d * spd * t) % (CW + 40) - 20
            step = int(t * 6 + wx0) % 2
            R(cv, col, x - 2, 276, 4, 8)
            R(cv, (36, 30, 40), x - 2 + step, 284, 1, 3)
            R(cv, (36, 30, 40), x + 1 - step, 284, 1, 3)
            pygame.draw.circle(cv, (226, 176, 132), (int(x), 273), 2)
        ph = t % 9
        for i, (cy, on) in enumerate(((247, ph >= 5), (253, 4 <= ph < 5), (259, ph < 4))):
            c = ((230, 60, 50), (240, 200, 60), (70, 220, 110))[i]
            R(cv, c if on else self._ecl(c, (0, 0, 0), .75), 329, cy - 1, 4, 4)
        for ly, x0, spd, d, col in sc["cars"]:
            x = (x0 + d * spd * t) % (CW + 80) - 40
            R(cv, col, x - 12, ly - 9, 24, 8)
            R(cv, self._ecl(col, (255, 255, 255), .25), x - 6, ly - 14, 12, 6)
            R(cv, (196, 226, 244), x - 4, ly - 13, 8, 4)
            R(cv, (18, 18, 24), x - 9, ly - 2, 5, 4)
            R(cv, (18, 18, 24), x + 5, ly - 2, 5, 4)
            R(cv, (255, 236, 160), x + (10 if d > 0 else -12), ly - 7, 2, 2)

    def _end_sky_gagal(self, sc, t):
        cv = self.cv
        for i, img in enumerate(sc["smokes"]):
            x = (i * 240 - t * (7 + i * 3)) % (CW + 330) - 330
            cv.blit(img, (int(x), 20 + i * 52))

    def _end_fx_gagal(self, sc, t):
        cv = self.cv
        pul = 0.5 + 0.5 * math.sin(t * 2.2)
        for x, y, k, ph in sc["flames"]:
            self._flame(x, y, k, ph, t)
        for i, (x, y, k, ph) in enumerate(sc["plumes"]):          # kepulan asap
            for j in range(10):
                p = (t * 0.2 + j / 10 + i * 0.31) % 1.0
                px = x + math.sin(p * 4 + i) * 8 + p * 34
                py = y - 8 - p * 150
                r = int(4 + p * 18 + k * 2)
                self.circle((22, 16, 20, int(150 * (1 - p) ** 1.2)), px, py, r)
        for x0, spd, ph in sc["embers"]:                          # bara api naik
            y = CH - ((t * (26 + spd) + ph * 30) % (CH + 20)) + 10
            x = x0 + math.sin(t * 1.8 + ph) * 12
            if y > 30:
                self._R(cv, (255, 150 + int(70 * abs(math.sin(ph + t * 3))), 50), x, y, 1, 2 if int(ph * 3) % 2 else 1)
        for x0, spd, ph in sc["ash"]:                             # abu jatuh
            y = (t * (10 + spd * .4) + ph * 40) % CH
            x = (x0 + math.sin(t * .8 + ph) * 14) % CW
            self._R(cv, (150, 140, 140), x, y, 1, 1)
        for x, y, ph, txt in sc["protest"]:                       # siluet demonstran
            b = abs(math.sin(t * 5 + ph)) * 2
            self._R(cv, (10, 8, 12), x - 3, y - 18 - b, 6, 18)
            pygame.draw.circle(cv, (10, 8, 12), (int(x), int(y - 22 - b)), 3)
            pygame.draw.line(cv, (10, 8, 12), (x + 3, y - 16 - b), (x + 9, y - 30 - b), 2)
            if txt:
                w = len(txt) * 6 + 6
                pygame.draw.line(cv, (10, 8, 12), (x + 9, y - 30 - b), (x + 9, y - 40 - b), 1)
                self._R(cv, (226, 214, 186), x + 9 - w // 2, y - 52 - b, w, 12)
                self.T(txt, x + 9, y - 49 - b, (140, 24, 24), 1, "center")
        blink = int(t * 4) % 2                                    # lampu truk pemadam
        lc = (230, 40, 40) if blink else (60, 120, 255)
        cv.blit(self._glow(18, lc, 150), (540 - 18, 303 - 18))
        self._R(cv, lc, 538, 301, 5, 3)
        self._R(cv, (255, 70, 30, int(26 + 20 * pul)), 0, 0, CW, CH)   # semburat merah

    def draw_end_city(self, rating):
        sc = self._end_scene(rating)
        cv = self.cv
        cv.blit(sc["sky"], (0, 0))
        getattr(self, "_end_sky_" + rating)(sc, self.t)
        cv.blit(sc["city"], (0, 0))
        getattr(self, "_end_fx_" + rating)(sc, self.t)
        cv.blit(sc["vig"], (0, 0))

    def draw_final(self):
        e = self.s.get("end") or {}
        rating = e.get("rating", "biasa")
        self.draw_end_city(rating)
        cap = self.END_CAPTION[rating]
        pr = pygame.Rect(12, 12, 276, 334)
        self.draw_panel_frame(pr, alpha=178)
        cx = pr.centerx
        self._title_word("SUDDENLY", cx, 24, 3)
        self._title_word("A PRESIDENT", cx, 50, 3)
        self._ornament(cx, 88, 100)
        self.T("TERIMA KASIH SUDAH BERMAIN", cx, 98, CREAMT, 1, "center", (0, 0, 0))
        self.T(cap[0], cx, 116, cap[1], 2, "center", SHADOW)
        y = 140
        for ln in self.font.wrap(cap[2], 1, 250)[:3]:
            self.T(ln, cx, y, CREAMT, 1, "center", (0, 0, 0))
            y += 10
        self.menu_button("again", (cx - 100, 178, 200, 28), "MAIN LAGI", True, 2, "go")
        self.menu_button("endmenu", (cx - 100, 212, 200, 28), "MENU UTAMA", True, 2)
        if self.last_trophy and not self.credits_preview:
            tid = self.last_trophy
            box = pygame.Rect(pr.x + 12, 256, pr.w - 24, 78)
            self.rectf(GOLD_D, box.x - 1, box.y - 1, box.w + 2, box.h + 2)
            self.rectf((24, 16, 22), *box)
            self.draw_trophy(box.x + 30, box.y + 40, tid, True)
            self.T("PIALA DIRAIH" + (" - BARU!" if self.last_trophy_new else ""), box.x + 62, box.y + 14, AMBER)
            self.T(TROPHY_BY_ID[tid][1].upper(), box.x + 62, box.y + 28, GOLD)
            self.T("Di RAK PIALA. Diraih %dx." % self.trophies.get(tid, 1), box.x + 62, box.y + 44, CREAMT)

    def draw_ending(self):
        st, t = self.end_stage, self.end_t
        if st == "room":
            self.draw_room()
            if t > self.ZOOM_AT:
                z = 1 + self._ease((t - self.ZOOM_AT) / self.ZOOM_DUR) * 2.6
                snap = self.cv.copy()
                cw, ch = int(CW / z), int(CH / z)
                x0 = max(0, min(CW - cw, int(self.NEWS[0] - cw / 2)))
                y0 = max(0, min(CH - ch, int(self.NEWS[1] - ch / 2)))
                tmp = pygame.Surface((cw, ch))
                tmp.blit(snap, (-x0, -y0))
                self.cv.blit(pygame.transform.scale(tmp, (CW, CH)), (0, 0))
            if t > self.ROOM_T - 0.8:
                if self._front_view is None:
                    self._front_view = self.render_to(lambda: self.draw_desk_paper(self.page_front))
                self._front_view.set_alpha(int(255 * (t - (self.ROOM_T - 0.8)) / 0.8))
                self.cv.blit(self._front_view, (0, 0))
            self.fade(255 * (1 - t / 0.8))
            self.T("KLIK / SPASI: LEWATI", CW - 6, CH - 12, (140, 120, 80), 1, "right")
        elif st == "front":
            self.draw_desk_paper(self.page_front)
            self.T("KLIK / SPASI: BALIK HALAMAN", CW - 6, CH - 14, (150, 130, 90), 1, "right")
        elif st == "flip":
            self.draw_flip(self._ease(t / self.FLIP_T))
        elif st == "stats":
            self.draw_desk_paper(self.page_stats)
            self.button("end_next", (CW // 2 - 80, 334, 160, 22), "LANJUT >>", True, 2, "primary")
        elif st == "credits":
            self.draw_credits()
        else:
            self.draw_final()

    # ------------------------------------------------------------------
    # MINIGAME
    # ------------------------------------------------------------------
    MINI_HELP = {
        "snake": ["Kemudikan perahu dengan tombol panah atau WASD.",
                  "Tangkap ikan agar jaring memanjang. Ikan emas = 3 poin.",
                  "Jangan tabrak tepi laut atau jaringmu. Waktu: 45 detik."],
        "memory": ["Klik kartu untuk membukanya.",
                   "Cocokkan nama kayu dengan nama latinnya. Contoh: Cendana = Santalum album.",
                   "Tiap pasangan = 2 Kayu. Semua cocok = bonus +4. Waktu: 60 detik."],
        "mines": ["Klik kiri untuk menggali bijih besi.",
                  "Angka = jumlah gas beracun di 8 petak sekitarnya.",
                  "Klik kanan atau tombol F untuk pasang bendera. Kena gas = hasil dipotong."],
        "whack": ["Klik tikus dan wereng yang muncul dari sawah.",
                  "Tikus emas = 3 poin. Jangan pukul bebek (-2)!",
                  "Waktu: 30 detik. Tiap poin = 1 Padi."],
        "quiz": ["Jawab 5 soal tentang Nusantara untuk menawar harga ekspor.",
                 "Tiap jawaban benar = harga jual +10%.",
                 "Klik jawaban atau tekan 1-4. Waktu 15 detik per soal."],
    }

    def start_mini(self, region):
        kind = MINI_OF[region]
        game = {"snake": SnakeGame, "memory": MemoryGame, "mines": MineGame,
                "whack": WhackGame, "quiz": QuizGame}[kind]()
        self.mini = {"kind": kind, "region": region, "com": ROLE[region][0], "phase": "ready",
                     "game": game, "reward": 0, "mult": 1.0, "lines": [], "fb": ""}
        self.state = "mini"
        self.say("%s: baca petunjuk, lalu tekan MULAI." % MINI_TITLE[kind].title())

    def begin_mini(self):
        self.mini["phase"] = "play"
        self.say({"snake": "Tangkap ikan sebanyak mungkin!", "memory": "Cocokkan nama kayu dengan nama latinnya!",
                  "mines": "Hati-hati dengan kantong gas!", "whack": "Usir hama, selamatkan bebek!",
                  "quiz": "Pilih jawaban yang paling tepat!"}[self.mini["kind"]])

    def mini_back(self):
        self.mini = None
        self.state = "main"
        self.say("Kembali ke peta nusantara.")

    def end_mini(self):
        m = self.mini
        g, k = m["game"], m["kind"]
        s = self.s
        tier = tier_of(s["welfare"][m["region"]])
        m["phase"] = "done"
        lines = []
        good = True
        if k == "quiz":
            m["mult"] = 1 + 0.1 * g.correct
            lines.append(("Jawaban benar: %d dari %d" % (g.correct, g.N), 2, CREAMT))
            lines.append(("BONUS HARGA EKSPOR: +%d%%" % (g.correct * 10), 2, GOLD))
            good = g.correct >= 3
        else:
            com = m["com"]
            if k == "snake":
                raw = g.score
                lines.append(("Perahu menabrak!" if g.time_left > 0 else "Waktu habis!", 2, CREAMT))
                lines.append(("Ikan tertangkap: %d (poin %d)" % (g.eaten, g.score), 1, CREAMT))
            elif k == "memory":
                raw = g.pairs * 2 + (4 if g.pairs == g.N else 0)
                lines.append(("Semua cocok!" if g.pairs == g.N else "Waktu habis!", 2, CREAMT))
                lines.append(("Pasangan: %d/%d  Langkah: %d" % (g.pairs, g.N, g.moves), 1, CREAMT))
            elif k == "mines":
                raw = g.reward()
                lines.append(("TAMBANG BERSIH!" if g.state == "won" else
                              "Kena gas beracun!" if g.boom else "Waktu habis!", 2, CREAMT))
                lines.append(("Petak aman terbuka: %d/%d" % (g.n_open(), g.N * g.N - g.M), 1, CREAMT))
            else:
                raw = max(0, g.score)
                lines.append(("Waktu habis!", 2, CREAMT))
                lines.append(("Hama diusir: %d  (poin %d)" % (g.hits, g.score), 1, CREAMT))
            final = round(raw * (1 + 0.1 * tier))
            m["reward"] = final
            lines.append(("Hasil dasar: %d %s" % (raw, com), 1, CREAMT))
            lines.append(("Bonus kesejahteraan: +%d%%" % (10 * tier), 1, CREAMT))
            lines.append(("TOTAL: %d %s" % (final, com), 2, GOLD))
            good = final >= 6
        m["lines"] = lines
        self.audio.play("fanfare" if good else "coin")

    def finish_mini(self):
        m = self.mini
        s = self.s
        self.state = "main"
        r = m["region"]
        # eksploitasi: setiap minigame yang diselesaikan di sebuah pulau (termasuk kuis Jawa)
        s["played"].add(r)
        n = s["exploit"][r] + 1
        mult = exploit_mult(n)
        warn = ""
        if mult > 1.0:
            warn = " PERINGATAN: eksploitasi hari ke-%d, kemakmuran %s menyusut x%.1f malam ini!" % (n, r, mult)
            s["banner"] = ["Eksploitasi %s hari ke-%d: susut x%.1f" % (r, n, mult), 3.5]
        if m["kind"] == "quiz":
            self.mini = None
            self.export_goods(m["mult"], warn)
            return
        s["stock"][m["com"]] += m["reward"]
        s["mini_done"] = True
        self.say("%s menghasilkan %d %s. Jual lewat Jawa untuk menambah kas!%s" %
                 (r, m["reward"], m["com"], warn))
        self.mini = None

    def update_mini(self, dt):
        m = self.mini
        if m is None or m["phase"] != "play":
            return
        g, k = m["game"], m["kind"]
        if k == "snake":
            before = g.eaten
            g.update(dt)
            if g.eaten != before:
                self.audio.play("eat")
            if not g.alive:
                self.audio.play("bad")
                self.end_mini()
        elif k == "memory":
            g.update(dt)
            if g.over:
                self.end_mini()
        elif k == "mines":
            g.update(dt)
            if g.state != "play":
                self.shake = 1.2 if g.state == "lost" and g.boom else 0.0
                self.end_mini()
        elif k == "whack":
            g.update(dt)
            if g.over:
                self.end_mini()
        elif k == "quiz":
            if g.update(dt):
                self.audio.play("bad")
                m["fb"] = "Waktu habis! " + g.items[g.i][3]

    def quiz_answer(self, k):
        m = self.mini
        if m is None or m["kind"] != "quiz" or m["phase"] != "play":
            return
        g = m["game"]
        ok = g.answer(k)
        if ok is None:
            return
        self.audio.play("good" if ok else "bad")
        m["fb"] = ("Benar! " if ok else "Kurang tepat. ") + g.items[g.i][3]

    def quiz_next(self):
        m = self.mini
        g = m["game"]
        if g.answered is None:
            return
        g.next()
        m["fb"] = ""
        if g.over:
            self.end_mini()

    def mini_bg(self, c1, c2):
        self.rectf(c1, 0, 0, CW, CH)
        for x in range(0, CW, 60):
            self.rectf(c2, x, 0, 30, CH)

    def mini_header(self, title, right=""):
        self.bands(0, 0, CW, 30, (22, 30, 70), (8, 11, 32), 5)
        self.rectf(GOLD2, 0, 30, CW, 1)
        self.rectf(WIN_EDGE, 0, 31, CW, 1)
        self.OT(title, 10, 8, TXT_GOLD, 2)
        if right:
            self.OT(right, CW - 10, 12, TXT, 1, "right")

    def mini_ready(self, m):
        self.rectf((0, 0, 0, 160), 0, 31, CW, CH - 31)
        box = pygame.Rect(90, 44, 460, 274)
        cx = CW / 2
        self.rwin(box, MINI_TITLE[m["kind"]])
        self.OT("Wilayah %s  -  %s" % (m["region"], MINI_GENRE[m["kind"]]), cx, box.y + 22, TXT_DIM, 1, "center")
        self.rectf(GOLD_D, box.x + 24, box.y + 38, box.w - 48, 1)
        self.OT("CARA MAIN", box.x + 24, box.y + 48, TXT_GOLD)
        y = box.y + 66
        for n, line in enumerate(self.MINI_HELP[m["kind"]], 1):
            self.circle(WIN_EDGE, box.x + 34, y + 5, 8)
            self.circle(GOLD2, box.x + 34, y + 5, 7)
            self.T(str(n), box.x + 34, y + 2, (60, 30, 6), 1, "center")
            ty = y
            for ln in self.font.wrap(line, 1, box.w - 92):
                self.OT(ln, box.x + 52, ty + 1, TXT)
                ty += 12
            y = max(ty, y + 12) + 12
        self.button("mini_start", (box.x + 60, box.bottom - 42, 150, 28), "MULAI", True, 2, "go")
        self.button("mini_back", (box.right - 210, box.bottom - 42, 150, 28), "KEMBALI", True, 2)

    def mini_done_panel(self, m):
        self.rectf((0, 0, 0, 170), 0, 31, CW, CH - 31)
        box = pygame.Rect(120, 66, 400, 230)
        cx = CW / 2
        self.rwin(box, "HASIL")
        y = box.y + 30
        for text, sc, col in m["lines"]:
            col = TXT_GOLD if col == GOLD else TXT if col == CREAMT else col
            self.OT(text, cx, y, col, sc, "center")
            y += 14 if sc == 1 else 24
        label = "EKSPOR >>" if m["kind"] == "quiz" else "LANJUT >>"
        self.button("mini_done", (cx - 80, box.bottom - 42, 160, 28), label, True, 2, "primary")

    # ---- Snake -------------------------------------------------------
    SN_X, SN_Y, SN_C = 128, 66, 12

    def draw_snake(self, m):
        g = m["game"]
        ox, oy, cs = self.SN_X, self.SN_Y, self.SN_C
        self.mini_bg((10, 20, 36), (13, 26, 44))
        self.mini_header("PERAHU JARING", "WAKTU %4.1f    POIN %d    PANJANG %d" % (g.time_left, g.score, len(g.body)))
        self.rectf(GOLD2, ox - 3, oy - 3, g.GW * cs + 6, g.GH * cs + 6)
        for gy in range(g.GH):
            for gx in range(g.GW):
                col = (18, 46, 70) if (gx + gy) % 2 == 0 else (21, 52, 78)
                self.rectf(col, ox + gx * cs, oy + gy * cs, cs, cs)
        for f in g.fish:
            cx, cy = ox + f[0] * cs + 6, oy + f[1] * cs + 6
            gold = f[2] == 3
            if gold and (f[3] > 2 or int(self.t * 6) % 2 == 0):
                self.circle(rgba(255, 215, 0, .25), cx, cy, 8)
            body = (255, 205, 40) if gold else (120, 210, 235)
            pygame.draw.ellipse(self.cv, body, (cx - 5, cy - 3, 10, 6))
            self.polygon(body, [(cx + 4, cy), (cx + 8, cy - 3), (cx + 8, cy + 3)])
            self.rectf((20, 20, 30), cx - 3, cy - 1, 1, 1)
        pts = [(ox + x * cs + 6, oy + y * cs + 6) for x, y in g.body]
        for i in range(len(pts) - 1, 0, -1):
            pygame.draw.line(self.cv, (110, 170, 200), pts[i], pts[i - 1], 1)
            self.circle((236, 236, 240) if i % 2 else (232, 120, 40), pts[i][0], pts[i][1], 3)
        hx, hy = g.body[0]
        px, py = ox + hx * cs, oy + hy * cs
        dx, dy = g.dir
        if dx == 1:
            poly = [(px, py + 1), (px + 11, py + 6), (px, py + 10)]
        elif dx == -1:
            poly = [(px + 11, py + 1), (px, py + 6), (px + 11, py + 10)]
        elif dy == 1:
            poly = [(px + 1, py), (px + 6, py + 11), (px + 10, py)]
        else:
            poly = [(px + 1, py + 11), (px + 6, py), (px + 10, py + 11)]
        self.polygon((176, 56, 48), poly)
        self.rectf((240, 232, 210), px + 4, py + 4, 3, 3)
        for p in g.pops:
            self.T(p[0], ox + p[1] * cs + 6, oy + p[2] * cs - 6 - p[3] * 14, GOLD, 1, "center", (0, 0, 0))
        self.rectf((60, 56, 50), ox, oy + g.GH * cs + 8, g.GW * cs, 4)
        self.rectf(AMBER, ox, oy + g.GH * cs + 8, g.GW * cs * g.time_left / g.TIME, 4)

    # ---- Memory ------------------------------------------------------
    @staticmethod
    def mem_rect(i):
        return pygame.Rect(100 + (i % 4) * 112, 44 + (i // 4) * 66, 104, 58)

    def wood_icon(self, k, cx, cy):
        use_target(self.cv)
        if k == 0:
            R((140, 92, 52), cx - 15, cy - 9, 24, 18)
            R((110, 72, 40), cx - 15, cy + 3, 24, 4)
            CI((206, 164, 104), cx + 9, cy, 9)
            CI((150, 104, 60), cx + 9, cy, 6)
            CI((206, 164, 104), cx + 9, cy, 3)
        elif k == 1:
            P((30, 100, 56), [(cx, cy - 16), (cx - 10, cy - 4), (cx + 10, cy - 4)])
            P((38, 122, 66), [(cx, cy - 8), (cx - 13, cy + 6), (cx + 13, cy + 6)])
            R((100, 66, 38), cx - 2, cy + 6, 4, 9)
        elif k == 2:
            P((70, 170, 90), [(cx - 12, cy + 10), (cx - 8, cy - 6), (cx + 4, cy - 14),
                              (cx + 14, cy - 12), (cx + 12, cy), (cx + 2, cy + 10)])
            LN((30, 100, 56), (cx - 12, cy + 12), (cx + 10, cy - 10), 1)
        elif k == 3:
            LN((150, 100, 56), (cx - 10, cy + 14), (cx + 8, cy - 12), 3)
            P((190, 196, 206), [(cx + 2, cy - 14), (cx + 14, cy - 10), (cx + 12, cy + 2), (cx + 4, cy - 4)])
        elif k == 4:
            for j, yy in enumerate((-12, -4, 4)):
                R((200, 158, 98) if j % 2 == 0 else (176, 132, 76), cx - 14, cy + yy, 28, 7)
                R((110, 72, 40), cx - 11, cy + yy + 3, 1, 1)
                R((110, 72, 40), cx + 10, cy + yy + 3, 1, 1)
        elif k == 5:
            R((140, 92, 52), cx - 11, cy - 2, 22, 13)
            pygame.draw.ellipse(self.cv, (206, 164, 104), (cx - 11, cy - 8, 22, 12))
            pygame.draw.ellipse(self.cv, (150, 104, 60), (cx - 7, cy - 6, 14, 8), 1)
            pygame.draw.ellipse(self.cv, (150, 104, 60), (cx - 3, cy - 4, 6, 4), 1)
        elif k == 6:
            CI((200, 206, 216), cx, cy, 13)
            for a in range(8):
                ang = a * math.pi / 4
                CI((60, 62, 74), cx + int(math.cos(ang) * 12), cy + int(math.sin(ang) * 12), 2)
            CI((60, 62, 74), cx, cy, 4)
        else:
            P((30, 30, 36), [(cx - 13, cy + 8), (cx - 8, cy - 6), (cx + 4, cy - 6), (cx + 8, cy + 4)])
            CI((30, 30, 36), cx + 6, cy - 8, 6)
            P((240, 170, 40), [(cx + 10, cy - 10), (cx + 22, cy - 6), (cx + 10, cy - 3)])
            R((230, 100, 40), cx + 7, cy - 16, 8, 4)
            R((236, 236, 240), cx - 14, cy + 3, 6, 3)
        use_target(None)

    def draw_memory(self, m):
        g = m["game"]
        self.mini_bg((22, 38, 24), (26, 44, 28))
        self.mini_header("COCOK KAYU", "WAKTU %4.1f    PASANGAN %d/%d    LANGKAH %d" %
                         (g.time_left, g.pairs, g.N, g.moves))
        for i in range(16):
            r = self.mem_rect(i)
            st = g.state[i]
            if st == 0:
                self.rectf(GOLD_D, r.x - 1, r.y - 1, r.w + 2, r.h + 2)
                self.rectf((48, 36, 18), *r)
                self.rectf((70, 52, 24), r.x + 3, r.y + 3, r.w - 6, r.h - 6)
                self.T("?", r.centerx, r.y + 18, GOLD2, 3, "center")
            else:
                done = st == 2
                latin = g.kind[i] == 1
                self.rectf(GOLD if done else BRONZE, r.x - 1, r.y - 1, r.w + 2, r.h + 2)
                self.rectf(PARCH2 if done else PARCH, *r)
                self.T("NAMA LATIN" if latin else "NAMA KAYU", r.centerx, r.y + 5, (120, 90, 50), 1, "center")
                name = WOODS[g.icon[i]][1 if latin else 0]
                if latin:
                    lines = self.font.wrap(name, 1, r.w - 10)
                    y0 = r.y + 24 if len(lines) > 1 else r.y + 29
                    for k, ln in enumerate(lines):
                        self.T(ln, r.centerx, y0 + k * 11, (36, 84, 56), 1, "center")
                else:
                    self.T(name, r.centerx, r.y + 26, (74, 40, 18), 2, "center")
        self.T("Cocokkan nama kayu dengan nama biologinya (nama latin)", CW / 2, 336,
               (140, 150, 120), 1, "center")

    # ---- Minesweeper -------------------------------------------------
    MN_X, MN_Y, MN_C = 212, 62, 24
    NUM_COL = {1: (90, 150, 255), 2: (90, 200, 110), 3: (240, 90, 80), 4: (170, 110, 230),
               5: (230, 150, 60), 6: (80, 210, 210), 7: (230, 230, 230), 8: (160, 160, 160)}

    def draw_mines(self, m):
        g = m["game"]
        ox, oy, cs = self.MN_X, self.MN_Y, self.MN_C
        self.mini_bg((34, 26, 24), (38, 29, 27))
        self.mini_header("TAMBANG BESI", "WAKTU %4.1f    GAS %d    TERBUKA %d/%d" %
                         (g.time_left, g.M - g.n_flags(), g.n_open(), g.N * g.N - g.M))
        self.rectf(GOLD2, ox - 3, oy - 3, g.N * cs + 6, g.N * cs + 6)
        for x in range(g.N):
            for y in range(g.N):
                r = pygame.Rect(ox + x * cs, oy + y * cs, cs, cs)
                if g.opened[x][y]:
                    self.rectf((58, 46, 42), r.x, r.y, cs, cs)
                    self.rectf((48, 38, 34), r.x, r.y, cs, 1)
                    n = g.count(x, y)
                    if n:
                        self.T(str(n), r.centerx, r.y + 5, self.NUM_COL[n], 2, "center")
                else:
                    self.rectf((122, 106, 90), r.x, r.y, cs, cs)
                    self.rectf((156, 138, 118), r.x, r.y, cs - 1, 2)
                    self.rectf((156, 138, 118), r.x, r.y, 2, cs - 1)
                    self.rectf((78, 66, 56), r.x + 1, r.bottom - 2, cs - 1, 2)
                    self.rectf((78, 66, 56), r.right - 2, r.y + 1, 2, cs - 1)
                    if g.flag[x][y]:
                        self.rectf((50, 40, 30), r.x + 11, r.y + 5, 2, 13)
                        self.polygon((220, 60, 50), [(r.x + 12, r.y + 4), (r.x + 12, r.y + 11), (r.x + 4, r.y + 8)])
                if g.state == "lost" and g.mines and (x, y) in g.mines and not g.flag[x][y]:
                    if g.boom == (x, y):
                        self.rectf((200, 50, 40), r.x, r.y, cs, cs)
                    self.circle((70, 210, 100), r.centerx, r.centery, 7)
                    self.circle((30, 90, 50), r.centerx - 2, r.centery - 2, 2)
                    self.circle((30, 90, 50), r.centerx + 3, r.centery + 2, 2)
        px = 470
        self.T("MODE KLIK", px, 70, AMBER, 1)
        self.button("flagmode", (px, 82, 130, 22), "BENDERA" if g.flag_mode else "GALI", m["phase"] == "play", 2,
                    "danger" if g.flag_mode else "go")
        self.T("Klik kanan / F:", px, 114, CREAMT, 1)
        self.T("pasang bendera", px, 125, CREAMT, 1)
        self.T("Angka = jumlah gas", px, 145, BRONZE, 1)
        self.T("di 8 petak sekitar.", px, 156, BRONZE, 1)
        self.T("Bersih total = bonus!", px, 176, GOLD2, 1)
        self.rectf((60, 56, 50), ox, oy + g.N * cs + 10, g.N * cs, 4)
        self.rectf(AMBER, ox, oy + g.N * cs + 10, g.N * cs * g.time_left / g.TIME, 4)

    def mine_cell(self, c):
        x = int((c[0] - self.MN_X) // self.MN_C)
        y = int((c[1] - self.MN_Y) // self.MN_C)
        n = MineGame.N
        if 0 <= x < n and 0 <= y < n and c[0] >= self.MN_X and c[1] >= self.MN_Y:
            return x, y
        return None

    # ---- Whack-a-mole -----------------------------------------------
    @staticmethod
    def hole_pos(i):
        return 170 + (i % 3) * 150, 118 + (i // 3) * 82

    def draw_creature(self, h, cx, cy):
        k = h["kind"]
        rise = 26 * min(1.0, h["age"] / 0.12)
        if h["hit"]:
            rise = 14
        by = cy - rise
        if k == "duck":
            body, beak = (250, 220, 70), (240, 150, 40)
            pygame.draw.ellipse(self.cv, body, (cx - 14, by - 4, 28, 24))
            self.circle(body, cx, by - 6, 10)
            self.polygon(beak, [(cx + 6, by - 8), (cx + 16, by - 5), (cx + 6, by - 2)])
            self.rectf((20, 20, 30), cx + 2, by - 10, 2, 2)
        else:
            gold = k == "gold"
            body = (255, 205, 40) if gold else (130, 104, 92)
            ear = (255, 240, 150) if gold else (230, 150, 160)
            pygame.draw.ellipse(self.cv, body, (cx - 14, by - 6, 28, 26))
            self.circle(body, cx - 8, by - 8, 5)
            self.circle(body, cx + 8, by - 8, 5)
            self.circle(ear, cx - 8, by - 8, 3)
            self.circle(ear, cx + 8, by - 8, 3)
            self.rectf((255, 60, 50), cx - 6, by + 2, 3, 3)
            self.rectf((255, 60, 50), cx + 4, by + 2, 3, 3)
            self.rectf((60, 30, 30), cx - 2, by + 8, 4, 3)
        if h["hit"]:
            self.T("X", cx, by - 4, WHITE, 3, "center", (0, 0, 0))

    def draw_whack(self, m):
        g = m["game"]
        self.mini_bg((72, 116, 54), (80, 126, 60))
        self.mini_header("USIR HAMA SAWAH", "WAKTU %4.1f    POIN %d" % (g.time_left, g.score))
        for i in range(9):
            cx, cy = self.hole_pos(i)
            pygame.draw.ellipse(self.cv, (92, 62, 40), (cx - 42, cy + 2, 84, 30))
            pygame.draw.ellipse(self.cv, (38, 24, 16), (cx - 34, cy + 6, 68, 20))
            h = g.holes[i]
            if h is not None:
                self.draw_creature(h, cx, cy + 14)
            pygame.draw.ellipse(self.cv, (110, 76, 48), (cx - 42, cy + 14, 84, 20))
            pygame.draw.ellipse(self.cv, (92, 62, 40), (cx - 42, cy + 16, 84, 18), 0)
        for p in g.pops:
            cx, cy = self.hole_pos(p[1])
            col = GOLD if p[0][0] == "+" else RED2
            self.T(p[0], cx, cy - 30 - p[3] * 24, col, 2, "center", (0, 0, 0))
        self.T("Klik tikus & wereng. Jangan pukul bebek!", CW / 2, 340, (230, 240, 200), 1, "center")

    def whack_hole_at(self, c):
        for i in range(9):
            cx, cy = self.hole_pos(i)
            if abs(c[0] - cx) <= 40 and cy - 28 <= c[1] <= cy + 30:
                return i
        return None

    # ---- Quiz ---------------------------------------------------------
    def draw_quiz(self, m):
        g = m["game"]
        self.mini_bg((26, 18, 30), (30, 21, 34))
        self.mini_header("NEGOSIASI EKSPOR", "SOAL %d/%d    BENAR %d" % (min(g.i + 1, g.N), g.N, g.correct))
        if m["phase"] == "ready" or g.over:
            return
        q, opts, ans, exp = g.items[g.i]
        box = pygame.Rect(40, 40, 560, 66)
        self.rectf(GOLD2, box.x - 2, box.y - 2, box.w + 4, box.h + 4)
        self.rectf(DKPANEL, *box)
        y = box.y + 8
        for ln in self.font.wrap(q, 2, 540)[:3]:
            self.T(ln, CW / 2, y, CREAMT, 2, "center")
            y += 18
        frac = g.t / g.PER_Q
        self.rectf((60, 56, 50), box.x, box.bottom + 5, box.w, 4)
        self.rectf(RED2 if g.t <= 4 else AMBER, box.x, box.bottom + 5, box.w * frac, 4)
        for k in range(4):
            style = "normal"
            enabled = m["phase"] == "play"
            if g.answered is not None:
                if k == ans:
                    style = "go"
                elif k == g.answered:
                    style = "danger"
                else:
                    enabled = False
            self.button("q%d" % k, (40, 122 + k * 36, 560, 30), "%s. %s" % ("ABCD"[k], opts[k]), enabled, 2, style)
        if g.answered is not None:
            y = 270
            for ln in self.font.wrap(m["fb"], 1, 520)[:3]:
                self.T(ln, 44, y, AMBER_200, 1)
                y += 11
            self.button("qnext", (CW - 190, 312, 150, 28), "LANJUT >>" if g.i + 1 < g.N else "SELESAI", True, 2, "primary")
        else:
            self.T("Tekan 1-4 atau klik jawaban.", CW / 2, 330, (130, 120, 140), 1, "center")

    def draw_mini(self):
        m = self.mini
        getattr(self, "draw_" + m["kind"])(m)
        if m["phase"] == "ready":
            self.mini_ready(m)
        elif m["phase"] == "done":
            self.mini_done_panel(m)

    def mini_key(self, k):
        m = self.mini
        if m is None:
            return
        ph, kind, g = m["phase"], m["kind"], m["game"]
        if ph == "ready":
            if k in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.begin_mini()
            elif k == pygame.K_ESCAPE:
                self.mini_back()
            return
        if ph == "done":
            if k in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.finish_mini()
            return
        if k == pygame.K_ESCAPE:                  # sedang bermain: buka menu jeda (termasuk Pengaturan)
            self.pause_from = "mini"
            self.state = "pause"
            return
        if kind == "snake":
            keys = {pygame.K_UP: (0, -1), pygame.K_w: (0, -1), pygame.K_DOWN: (0, 1), pygame.K_s: (0, 1),
                    pygame.K_LEFT: (-1, 0), pygame.K_a: (-1, 0), pygame.K_RIGHT: (1, 0), pygame.K_d: (1, 0)}
            if k in keys:
                g.turn(keys[k])
        elif kind == "mines" and k == pygame.K_f:
            g.flag_mode = not g.flag_mode
        elif kind == "quiz":
            nums = {pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2, pygame.K_4: 3,
                    pygame.K_a: 0, pygame.K_b: 1, pygame.K_c: 2, pygame.K_d: 3}
            if k in nums:
                self.quiz_answer(nums[k])
            elif k in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.quiz_next()

    def click_mini(self, c, btn):
        m = self.mini
        if m is None or m["phase"] != "play":
            return
        g, kind = m["game"], m["kind"]
        if kind == "memory" and btn == 1:
            for i in range(16):
                if self.mem_rect(i).collidepoint(c):
                    ev = g.click(i)
                    if ev:
                        self.audio.play({"flip": "flip", "match": "match", "miss": "flip"}[ev])
                    break
        elif kind == "mines":
            cell = self.mine_cell(c)
            if cell:
                if btn == 3 or g.flag_mode:
                    g.toggle_flag(*cell)
                    self.audio.play("click")
                else:
                    ev = g.reveal(*cell)
                    if ev == "boom":
                        self.audio.play("boom")
                    elif ev == "dig":
                        self.audio.play("dig")
        elif kind == "whack" and btn == 1:
            i = self.whack_hole_at(c)
            if i is not None:
                ev = g.click(i)
                if ev:
                    self.audio.play(ev)

    # ------------------------------------------------------------------
    # INPUT
    # ------------------------------------------------------------------
    def toggle_fullscreen(self):
        try:
            pygame.display.toggle_fullscreen()
        except Exception:
            pass

    def on_button(self, bid):
        s = self.s
        if bid == "start":
            self.press_start()
        elif bid == "again":
            self.start_game()
        elif bid == "settings":
            self.settings_from = "pause" if self.state == "pause" else "menu"
            self.state = "settings"
            self.say("Atur pengalaman bermainmu.")
        elif bid == "exit":
            self.running = False
        elif bid == "replay":
            self.set_scene(0)
        elif bid == "credits":
            self.preview_credits()
        elif bid == "tutorial":
            self.begin_tutorial("menu")
        elif bid == "tut_prev":
            self.tut_step(-1)
        elif bid == "tut_next":
            self.tut_step(1)
        elif bid == "trophies":
            self.state = "trophies"
            self.say("Koleksi piala dari semua masa jabatanmu.")
        elif bid == "event_ok":
            self.close_event()
        elif bid == "back" and self.state == "settings" and self.settings_from == "pause":
            self.state = "pause"
        elif bid in ("skip", "back", "tomenu", "endmenu"):
            self.go_menu()
        elif bid == "sound":
            self.audio.muted = not self.audio.muted
        elif bid == "music":
            self.music.on = not self.music.on
        elif bid == "crt":
            self.crt = not self.crt
        elif bid == "fullscreen":
            self.toggle_fullscreen()
        elif bid == "resume":
            self.state = self.pause_from or "main"
        elif bid in ("a5", "a10"):
            self.give(5 if bid == "a5" else 10)
        elif bid == "prod":
            r = REGIONS[s["sel"]]
            self.open_secede(r) if r in s["seceded"] else self.start_mini(r)
        elif bid == "export":
            self.open_secede("Jawa") if "Jawa" in s["seceded"] else self.export_goods(1.0)
        elif bid == "nego":
            self.open_secede("Jawa") if "Jawa" in s["seceded"] else self.start_mini("Jawa")
        elif bid == "secede_ok":
            self.state = "main"
        elif bid == "end_next":
            self.end_goto("credits")
        elif bid == "next":
            self.advance_day()
        elif bid == "skipobs":
            self.finish_obs()
        elif bid == "mini_start":
            self.begin_mini()
        elif bid == "mini_back":
            self.mini_back()
        elif bid == "mini_done":
            self.finish_mini()
        elif bid == "flagmode":
            self.mini["game"].flag_mode = not self.mini["game"].flag_mode
        elif bid == "qnext":
            self.quiz_next()
        elif bid[0] == "q" and bid[1:].isdigit():
            self.quiz_answer(int(bid[1:]))
        elif bid == "accept":
            amt = s["offer"][1]
            s["personal"] += amt
            s["corrupt"] += 1
            s["dissat"] = min(100, s["dissat"] + 12)
            r = random.choice(REGIONS)
            s["welfare"][r] = max(0, s["welfare"][r] - 8)
            self.check_secession()
            self.state = "main"
            self.shake = 1.0
            self.audio.play("bad")
            self.say("Kamu menerima Rp%d juta. Ada proyek di %s yang terbengkalai..." % (amt, r))
        elif bid == "refuse":
            s["dissat"] = max(0, s["dissat"] - 4)
            self.state = "main"
            self.audio.play("good")
            self.say("Kamu menolak suap. Kepercayaan rakyat bertambah!")

    def click_main(self, c):
        s = self.s
        if s["observing"] or not MAP.collidepoint(c):
            return
        lp = (c[0] - MAP.x, c[1] - MAP.y)
        for i, r in enumerate(REGIONS):
            bx, by = LABEL_POS[r]
            if (abs(lp[0] - bx) <= 50 and abs(lp[1] - by) <= 12) or point_in_poly(lp, POLY[r]):
                if s["sel"] != i:
                    self.audio.play("click")
                s["sel"] = i
                if r in s["seceded"]:
                    self.open_secede(r)
                return

    def on_click(self, pos, btn):
        c = self.to_canvas(pos)
        if c is None:
            return
        if btn == 1:
            for bid, rect, en in reversed(self.ui):
                if rect.collidepoint(c):
                    if en:
                        self.audio.play("click")
                        self.on_button(bid)
                    return
        st = self.state
        if st == "intro" and btn == 1:
            if not self.finish_typing():
                self.next_scene()
        elif st == "enter" and btn == 1:
            self.shake = 0.0
            self.finish_enter()
        elif st == "transition":
            self.start_day()
        elif st == "main" and btn == 1:
            self.click_main(c)
        elif st == "ending" and btn == 1 and self.end_stage in ("room", "front", "flip"):
            self.end_goto({"room": "front", "front": "flip", "flip": "stats"}[self.end_stage])
        elif st == "mini":
            self.click_mini(c, btn)

    def on_key(self, k):
        st = self.state
        enter = (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER)
        if k == pygame.K_F11:
            self.toggle_fullscreen()
        elif st == "intro":
            if k == pygame.K_ESCAPE:
                self.go_menu()
            elif k in enter:
                if not self.finish_typing():
                    self.next_scene()
        elif st == "menu":
            if k == pygame.K_ESCAPE:
                self.running = False
            elif k in enter:
                self.press_start()
        elif st == "enter":
            if k in enter or k == pygame.K_ESCAPE:
                self.shake = 0.0
                self.finish_enter()
        elif st == "tutorial":
            if k == pygame.K_ESCAPE:
                self.end_tutorial()
            elif k in enter or k in (pygame.K_RIGHT, pygame.K_d):
                self.tut_step(1)
            elif k in (pygame.K_LEFT, pygame.K_a):
                self.tut_step(-1)
        elif st == "settings":
            if k == pygame.K_ESCAPE:
                if self.settings_from == "pause":
                    self.state = "pause"
                else:
                    self.go_menu()
        elif st == "transition":
            self.start_day()
        elif st == "main":
            if k == pygame.K_ESCAPE:
                self.pause_from = "main"
                self.state = "pause"
            elif k in enter and self.s["observing"]:
                self.finish_obs()
        elif st == "pause":
            if k == pygame.K_ESCAPE:
                self.state = self.pause_from or "main"
        elif st == "mini":
            self.mini_key(k)
        elif st == "secede":
            if k in enter or k == pygame.K_ESCAPE:
                self.state = "main"
        elif st == "disaster":
            if k in enter or k == pygame.K_ESCAPE:
                self.close_event()
        elif st == "trophies":
            if k == pygame.K_ESCAPE:
                self.go_menu()
        elif st == "ending":
            nxt = {"room": "front", "front": "flip", "flip": "stats", "stats": "credits"}
            skip = {"room": "stats", "front": "stats", "flip": "stats", "stats": "credits",
                    "credits": "final"}
            if k == pygame.K_ESCAPE and self.end_stage == "credits" and self.credits_preview:
                self.go_menu()
            elif k == pygame.K_ESCAPE and self.end_stage in skip:
                self.end_goto(skip[self.end_stage])
            elif k in enter and self.end_stage in nxt:
                self.end_goto(nxt[self.end_stage])

    def handle_events(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                self.running = False
            elif e.type == pygame.KEYDOWN:
                self.on_key(e.key)
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button in (1, 3):
                self.on_click(e.pos, e.button)

    # ------------------------------------------------------------------
    # UPDATE
    # ------------------------------------------------------------------
    def update_caption(self, dt):
        full = self.msg_full
        if self.msg_idx < len(full):
            if not hasattr(self.audio, "typing_snd"):
                self.audio.load_typing_sound()
            self.msg_timer += dt
            rate = TYPING_SPEED_INTRO if self.state in ("intro", "menu") else TYPING_SPEED_OTHER
            while self.msg_timer > rate and self.msg_idx < len(full):
                self.msg_idx += 1
                self.msg_timer -= rate
                ch = full[self.msg_idx - 1]
                if (self.state in TYPING_SOUND_STATES and ch != " "
                        and self.msg_idx % max(1, TYPING_SOUND_EVERY) == 0):
                    self.audio.play_typing()

    def finish_typing(self):
        """Tampilkan seluruh teks sekaligus. True bila tadi memang masih mengetik."""
        if TYPING_SKIP_FIRST and self.msg_idx < len(self.msg_full):
            self.msg_idx = len(self.msg_full)
            return True
        return False

    def update(self, dt):
        self.t += dt
        st = self.state
        if st == "intro":
            self.scene_time += dt
            if self.scene_time >= SCENES[self.scene][1]:
                self.next_scene()
        elif st == "enter":
            self.enter_t += dt
            if not self._enter_sfx and self.enter_t >= 1.2:
                self._enter_sfx = True
                self.audio.play("dramatic")
            if self.enter_t >= self.ENTER_TOTAL:
                self.shake = 0.0
                self.finish_enter()
        elif st == "tutorial":
            self.tut["t"] += dt
        elif st == "transition":
            self.trans["t"] += dt
            if self.trans["t"] >= self.TRANS_TOTAL:
                self.start_day()
        elif st == "main":
            s = self.s
            if s["observing"]:
                s["obs_left"] -= dt
                if s["obs_left"] <= 0:
                    self.finish_obs()
            if s["banner"][1] > 0:
                s["banner"][1] -= dt
        elif st == "mini":
            self.update_mini(dt)
        elif st == "ending":
            self.end_t += dt
            self.update_ending()
        if self.shake > 0:
            self.shake = max(0.0, self.shake - dt * 10)
        self.update_particles(dt)
        self.update_caption(dt)
        self.audio.update()
        self.music.set_track(self.music_track())
        self.music.update()

    def music_track(self):
        st = self.state
        if st == "settings" and self.settings_from == "pause":
            return "game"
        if st in ("intro", "menu", "settings", "enter", "trophies", "tutorial"):
            return "menu"
        if st == "ending":
            return "ending"
        return "game"

    # ------------------------------------------------------------------
    # RENDER
    # ------------------------------------------------------------------
    def compute_layout(self):
        self.screen = pygame.display.get_surface()
        w, h = self.screen.get_size()
        self.bs = max(1, min(4, w // 560))
        pad, gap = 10, 8
        bh = 22 * self.bs + 10
        avail_h = max(90, h - 2 * pad - bh - gap)
        avail_w = max(160, w - 2 * pad)
        vw = min(avail_w, int(avail_h * 16 / 9))
        vh = vw * 9 // 16
        top = max(0, (h - (vh + gap + bh)) // 2)
        self.view = pygame.Rect((w - vw) // 2, top, vw, vh)
        self.banner = pygame.Rect(self.view.x, self.view.bottom + gap, vw, bh)

    def to_canvas(self, pos):
        if not self.view.collidepoint(pos):
            return None
        return ((pos[0] - self.view.x) * CW / self.view.w, (pos[1] - self.view.y) * CH / self.view.h)

    def build_overlay(self, w, h):
        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        for x in range(0, w, 6):
            ov.fill((255, 0, 0, 5), (x, 0, 2, h))
            ov.fill((0, 255, 0, 2), (x + 2, 0, 2, h))
            ov.fill((0, 0, 255, 5), (x + 4, 0, 2, h))
        for y in range(2, h, 4):
            ov.fill((0, 0, 0, 30), (0, y, w, 2))
        spread = max(8, round(100 * w / 896))
        for d in range(0, spread, 2):
            alpha = round(80 * (1 - d / spread) ** 1.5)
            pygame.draw.rect(ov, (0, 0, 0, alpha), (d, d, w - 2 * d, h - 2 * d), 2)
        pygame.draw.rect(ov, (245, 158, 11, 60), (0, 0, w, h), 2)
        return ov

    def draw_banner(self):
        """Kotak dialog di bawah layar (gaya RPG): potret penasihat + teks yang diketik."""
        b = self.banner
        scr = self.screen
        bs = self.bs
        t = max(1, bs)
        scr.fill(WIN_EDGE, b)
        scr.fill(GOLD2, b.inflate(-2 * t, -2 * t))
        body = b.inflate(-4 * t, -4 * t)
        n = 6
        for i in range(n):
            ya = body.y + body.h * i // n
            yb = body.y + body.h * (i + 1) // n
            scr.fill(self._mix(WIN_TOP, WIN_BOT, i / (n - 1)), (body.x, ya, body.w, yb - ya))
        scr.fill((120, 140, 220), (body.x + t, body.y + 1, body.w - 2 * t, max(1, t // 2)))
        for qx, qy in ((b.x, b.y), (b.right - 2 * t, b.y), (b.x, b.bottom - 2 * t), (b.right - 2 * t, b.bottom - 2 * t)):
            scr.fill(GOLD, (qx, qy, 2 * t, 2 * t))
        # potret penasihat
        ps = body.h - 2 * bs
        px, py = body.x + 2 * bs, body.y + bs
        scr.fill(WIN_EDGE, (px - bs, py - bs, ps + 2 * bs, ps + 2 * bs))
        scr.fill(GOLD2, (px, py, ps, ps))
        scr.fill((40, 56, 120), (px + bs, py + bs, ps - 2 * bs, ps - 2 * bs))
        sc = max(1, (ps - 4 * bs) // 12)
        self.pic("adviser", px + (ps - 12 * sc) // 2, py + (ps - 12 * sc) // 2, sc, scr)
        # teks
        tx = px + ps + 4 * bs
        maxw = body.right - tx - 10 * bs
        full = self.msg_full
        st = bs
        lines = self.font.wrap(full, st, maxw)
        if len(lines) > 2 and st > 1:
            st -= 1
            lines = self.font.wrap(full, st, maxw)
        lh = 11 * st
        lines = lines[:max(2, body.h // lh)]
        y = body.centery - (len(lines) * lh - 2 * st) // 2
        remaining = self.msg_idx
        for ln in lines:
            part = ln[:max(0, remaining)]
            remaining -= len(ln) + 1
            if part:
                scr.blit(self.font.render(part, st, (24, 16, 44)), (tx + st, y + st))
                scr.blit(self.font.render(part, st, TXT), (tx, y))
            y += lh
        if self.msg_idx >= len(full) and int(self.t * 2.5) % 2 == 0:
            self.pic("down", body.right - 12 * bs, body.bottom - 8 * bs, max(1, bs), scr)

    def draw_state(self):
        st = self.state
        if st == "intro":
            (self.draw_scene1, self.draw_scene2, self.draw_scene3, self.draw_scene4)[self.scene]()
            self.button("skip", (CW - 90, 8, 82, 16), "LEWATI >>", True, 1)
        elif st == "menu":
            self.draw_menu()
        elif st == "settings":
            self.draw_settings()
        elif st == "enter":
            self.draw_enter()
        elif st == "transition":
            self.draw_transition()
        elif st == "main":
            self.draw_game()
        elif st == "pause":
            self.draw_pause_backdrop()
            self.draw_pause()
        elif st == "mini":
            self.draw_mini()
        elif st == "corrupt":
            self.draw_corrupt()
        elif st == "secede":
            self.draw_underlay()
            self.draw_secede()
        elif st == "disaster":
            self.draw_disaster()
        elif st == "trophies":
            self.draw_trophies()
        elif st == "tutorial":
            self.draw_tutorial()
        elif st == "ending":
            self.draw_ending()
        if st in ("menu", "settings", "main", "pause", "corrupt", "secede", "disaster"):
            self.draw_particles((255, 215, 0))

    def render(self):
        self.compute_layout()
        c = self.to_canvas(pygame.mouse.get_pos())
        self.mpos = c if c else (-999, -999)
        self.ui = []
        self._hov_now = None
        self.draw_state()
        if self._hov_now != self._hov_prev and self._hov_now:
            self.audio.play("hover")
        self._hov_prev = self._hov_now

        scr = self.screen
        scr.fill(PAGE_BG)
        vw, vh = self.view.size
        k = max(1, math.ceil(vw / CW))
        big = self.cv if k == 1 else pygame.transform.scale(self.cv, (CW * k, CH * k))
        out = big if big.get_size() == (vw, vh) else pygame.transform.smoothscale(big, (vw, vh))
        ox = oy = 0
        if self.shake > 0:
            ox = round((random.random() - .5) * self.shake * 6 * vw / CW)
            oy = round((random.random() - .5) * self.shake * 6 * vw / CW)
        scr.set_clip(self.view)
        scr.blit(out, (self.view.x + ox, self.view.y + oy))
        scr.set_clip(None)
        if self.crt:
            key = (vw, vh)
            if self._overlay is None or self._overlay_key != key:
                self._overlay = self.build_overlay(vw, vh)
                self._overlay_key = key
            scr.blit(self._overlay, self.view)
        self.draw_banner()

        want = self._hov_now is not None
        if want != self._cursor_hand:
            self._cursor_hand = want
            try:
                pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_HAND if want else pygame.SYSTEM_CURSOR_ARROW)
            except (pygame.error, AttributeError):
                pass
        pygame.display.flip()

    def run(self):
        self.init_particles()
        self._mn = self._build_menu_scene()   # siapkan latar menu di awal agar tidak patah
        self.set_scene(0)
        while self.running:
            dt = min(self.clock.tick(60) / 1000, 0.1)
            self.handle_events()
            self.update(dt)
            self.render()
        pygame.quit()


def main():
    Game().run()
    sys.exit()


if __name__ == "__main__":
    main()