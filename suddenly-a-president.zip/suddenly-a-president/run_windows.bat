@echo off
cd /d "%~dp0"
set PY=python
where python >nul 2>nul || set PY=py
%PY% -c "import pygame" >nul 2>nul || %PY% -m pip install -r requirements.txt
%PY% beta.py
if errorlevel 1 pause
