#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
PY=python3
command -v python3 >/dev/null 2>&1 || PY=python
"$PY" -c "import pygame" 2>/dev/null || "$PY" -m pip install -r requirements.txt
exec "$PY" beta.py
