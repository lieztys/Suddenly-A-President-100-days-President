# Suddenly a President

Game strategi **pixel-art** bergaya RPG: Anda mendadak menjadi presiden sebuah negara
kepulauan dan harus memimpin selama **10 hari**. Bagikan anggaran antar pulau, jalankan
produksi lewat minigame klasik, jual hasil bumi, dan hadapi bencana alam serta godaan
kekuasaan. Semua keputusan Anda dinilai di akhir masa jabatan.

Ditulis dengan **Python + pygame** dalam **satu file** (`beta.py`). Semua gambar, font pixel,
efek suara, dan musik latar dibuat langsung dari kode, jadi **tidak ada aset yang wajib diunduh**.

| Menu utama | Peta nusantara |
|:---:|:---:|
| ![Menu utama](docs/screenshots/01-menu.png) | ![Peta](docs/screenshots/02-peta.png) |
| **Minigame produksi** | **Rak Piala** |
| ![Minigame](docs/screenshots/03-minigame.png) | ![Rak piala](docs/screenshots/04-rak-piala.png) |

> Screenshot dibuat otomatis dari kanvas game (tanpa efek layar CRT). Tampilan asli di jendela game
> sedikit berbeda.

## Fitur

- Intro sinematik, menu utama, dan tutorial singkat yang hanya muncul sekali (pada START pertama).
- Lima pulau dengan peran berbeda, dengan jalur produksi dan ekspor sendiri.
- Lima minigame klasik: **Snake**, **Match Tiles**, **Minesweeper**, **Whack-a-Mole**, dan **kuis**.
- 9 jenis bencana alam yang bisa terjadi selama masa jabatan.
- **Rak Piala**: 12 piala (3 rating akhir jabatan + 1 piala untuk tiap jenis bencana yang pernah Anda alami).
- Ending sinematik dan kredit.
- Musik latar chiptune bawaan yang bisa diganti dengan lagu sendiri (lihat bagian di bawah).
- Pengaturan: musik, typing SFX (suara ketik, klik, dan efek lain), efek CRT, layar penuh.
- Layar bisa diubah ukurannya; resolusi logis 640x360 diskalakan otomatis.

## Menjalankan

Butuh **Python 3.8+** (disarankan 3.10 atau lebih baru) dan **pygame 2.x**.

```bash
git clone https://github.com/<username>/suddenly-a-president.git
cd suddenly-a-president
pip install -r requirements.txt
python beta.py
```

Atau tanpa terminal:

- **Windows**: klik dua kali `run_windows.bat` (memasang pygame otomatis bila belum ada).
- **macOS / Linux**: `./run.sh` (jalankan `chmod +x run.sh` dulu bila perlu).

Jika mengunduh ZIP dari GitHub, ekstrak dulu lalu jalankan dengan cara di atas.

## Kontrol

| Aksi | Kontrol |
|---|---|
| Tombol, pulau, petak minigame | Klik mouse |
| Lanjut (intro, transisi hari, lewati fase pengamatan) | `SPASI` / `ENTER` |
| Jeda dan Pengaturan / kembali | `ESC` |
| Layar penuh | `F11` |
| Snake | Panah atau `WASD` |
| Minesweeper | Klik kiri = gali, klik kanan atau `F` = bendera |
| Kuis | Klik jawaban atau tombol `1`-`4` / `A`-`D` |

## Menyimpan progres: `piala.json`

Game menyimpan dua hal di `piala.json` (di folder yang sama dengan `beta.py`):

```json
{
 "start_count": 0,
 "piala": {}
}
```

- `start_count`: berapa kali tombol START diklik (tutorial hanya tampil pada klik pertama).
- `piala`: daftar piala yang pernah diraih beserta jumlahnya, misalnya `"banjir": 2`.

File ini **ditulis ulang otomatis** saat Anda bermain, dan dibuat sendiri bila hilang. Untuk mengulang dari
awal, kembalikan isinya seperti contoh di atas atau hapus filenya.

Versi yang ada di repositori ini adalah **kondisi bersih (pemain baru)**. Jika Anda ikut mengembangkan game
dan tidak ingin progres lokal ikut ter-commit, jalankan:

```bash
git update-index --assume-unchanged piala.json
```

## Mengganti musik dan suara dengan file sendiri

Taruh file di folder `asset/audio/` (format `.ogg`, `.mp3`, atau `.wav`). File akan **otomatis menggantikan**
suara bawaan tanpa mengubah kode:

| File | Diputar di |
|---|---|
| `menu.ogg` | intro, menu, pengaturan, rak piala, tutorial |
| `game.ogg` | permainan dan minigame |
| `ending.ogg` | ending dan kredit |
| `bgm.ogg` | cadangan untuk semua lagu yang file khususnya tidak ada |
| `ketik.wav` | suara ketik pada teks cutscene |

Logo jendela (opsional): `asset/image/logo.png`.

Pengaturan efek ketik (kecepatan, volume, di state mana suaranya aktif) ada di blok
`PENGATURAN EFEK KETIK` di bagian atas `beta.py`: `TYPING_SOUND_FILE`, `TYPING_VOLUME`,
`TYPING_SPEED_INTRO`, `TYPING_SOUND_EVERY`, dan seterusnya.

## Struktur folder

```
suddenly-a-president/
├── beta.py              # seluruh game (versi 1.0.18)
├── piala.json           # file simpanan (piala & penghitung START)
├── requirements.txt     # pygame
├── run_windows.bat      # peluncur Windows
├── run.sh               # peluncur macOS / Linux
├── asset/
│   ├── audio/           # (opsional) musik & suara sendiri
│   └── image/           # (opsional) logo.png
└── docs/screenshots/    # gambar untuk README ini
```

## Pemecahan masalah

- **`ModuleNotFoundError: No module named 'pygame'`**: jalankan `pip install -r requirements.txt`
  (atau `python -m pip install pygame`).
- **Tidak ada suara**: bila perangkat audio tidak tersedia, game tetap berjalan tanpa suara.
  Cek juga tombol *Musik* dan *Typing SFX* di Pengaturan.
- **Jendela terlalu besar/kecil**: ubah ukuran jendela dengan mouse, atau tekan `F11` untuk layar penuh.
- **Tampilan agak lambat**: matikan *Efek CRT* di Pengaturan.

## Lisensi

Belum ditentukan. Tambahkan berkas `LICENSE` sebelum repositori dibuka untuk umum agar orang lain tahu
apa yang boleh mereka lakukan dengan kode ini.
